package com.kidtimeguard.app.data.local.dao

import androidx.room.*
import com.kidtimeguard.app.data.local.entity.*
import kotlinx.coroutines.flow.Flow

// ─────────────────────────────────────────────────────────────────
// ChildProfileDao
// ─────────────────────────────────────────────────────────────────
@Dao
interface ChildProfileDao {

    @Query("SELECT * FROM child_profiles LIMIT 1")
    fun observeProfile(): Flow<ChildProfileEntity?>

    @Query("SELECT * FROM child_profiles LIMIT 1")
    suspend fun getProfile(): ChildProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProfile(profile: ChildProfileEntity): Long

    @Query("UPDATE child_profiles SET total_stars = total_stars + :stars, total_xp = total_xp + :xp WHERE id = :id")
    suspend fun addStarsAndXp(id: Long, stars: Int, xp: Int)

    @Query("UPDATE child_profiles SET level = :level WHERE id = :id")
    suspend fun updateLevel(id: Long, level: Int)
}

// ─────────────────────────────────────────────────────────────────
// MonitoredAppDao
// ─────────────────────────────────────────────────────────────────
@Dao
interface MonitoredAppDao {

    @Query("SELECT * FROM monitored_apps WHERE is_active = 1 ORDER BY app_name ASC")
    fun observeActiveApps(): Flow<List<MonitoredAppEntity>>

    @Query("SELECT * FROM monitored_apps ORDER BY app_name ASC")
    suspend fun getAllApps(): List<MonitoredAppEntity>

    @Query("SELECT * FROM monitored_apps WHERE package_name = :packageName LIMIT 1")
    suspend fun getAppByPackage(packageName: String): MonitoredAppEntity?

    @Query("SELECT * FROM monitored_apps WHERE package_name = :packageName LIMIT 1")
    fun observeAppByPackage(packageName: String): Flow<MonitoredAppEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertApp(app: MonitoredAppEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertApps(apps: List<MonitoredAppEntity>)

    @Query("UPDATE monitored_apps SET is_active = :active WHERE package_name = :packageName")
    suspend fun setActive(packageName: String, active: Boolean)

    @Query("UPDATE monitored_apps SET limit_weekday_minutes = :weekday, limit_weekend_minutes = :weekend WHERE package_name = :packageName")
    suspend fun updateLimits(packageName: String, weekday: Int, weekend: Int)

    @Delete
    suspend fun deleteApp(app: MonitoredAppEntity)
}

// ─────────────────────────────────────────────────────────────────
// UsageRecordDao
// ─────────────────────────────────────────────────────────────────
@Dao
interface UsageRecordDao {

    /** Get today's record for a specific app (returns null if no usage yet) */
    @Query("SELECT * FROM usage_records WHERE package_name = :packageName AND date_epoch = :dateEpoch LIMIT 1")
    suspend fun getRecord(packageName: String, dateEpoch: Long): UsageRecordEntity?

    /** Observe today's record — used by the lock service to react to changes */
    @Query("SELECT * FROM usage_records WHERE package_name = :packageName AND date_epoch = :dateEpoch LIMIT 1")
    fun observeRecord(packageName: String, dateEpoch: Long): Flow<UsageRecordEntity?>

    /** All records for the last N days — used for analytics */
    @Query("""
        SELECT * FROM usage_records
        WHERE date_epoch >= :fromEpoch
        ORDER BY date_epoch DESC
    """)
    fun observeRecordsSince(fromEpoch: Long): Flow<List<UsageRecordEntity>>

    @Query("SELECT * FROM usage_records WHERE date_epoch = :dateEpoch")
    suspend fun getRecordsForDate(dateEpoch: Long): List<UsageRecordEntity>

    /** Observe all records for a specific date — used for live dashboard updates */
    @Query("SELECT * FROM usage_records WHERE date_epoch = :dateEpoch")
    fun observeRecordsForDate(dateEpoch: Long): Flow<List<UsageRecordEntity>>

    /** Weekly summary per app — used for the bar/pie charts */
    @Query("""
        SELECT package_name, SUM(usage_ms) as total_usage_ms
        FROM usage_records
        WHERE date_epoch >= :fromEpoch AND date_epoch <= :toEpoch
        GROUP BY package_name
        ORDER BY total_usage_ms DESC
    """)
    suspend fun getWeeklySummary(fromEpoch: Long, toEpoch: Long): List<AppUsageSummary>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertRecord(record: UsageRecordEntity)

    /** Atomic increment — safe to call from the polling loop */
    @Query("""
        UPDATE usage_records
        SET usage_ms = :usageMs, updated_at = :now
        WHERE package_name = :packageName AND date_epoch = :dateEpoch
    """)
    suspend fun updateUsage(packageName: String, dateEpoch: Long, usageMs: Long, now: Long = System.currentTimeMillis())

    @Query("""
        UPDATE usage_records
        SET bonus_ms = bonus_ms + :additionalBonusMs, updated_at = :now
        WHERE package_name = :packageName AND date_epoch = :dateEpoch
    """)
    suspend fun addBonusTime(packageName: String, dateEpoch: Long, additionalBonusMs: Long, now: Long = System.currentTimeMillis())

    /**
     * Safely adds bonus time. If no record exists for today yet, it creates one.
     * This ensures parent/challenge unlocks work even before first app usage.
     */
    @Transaction
    suspend fun addBonusTimeSafe(packageName: String, dateEpoch: Long, additionalBonusMs: Long) {
        val existing = getRecord(packageName, dateEpoch)
        if (existing == null) {
            upsertRecord(
                UsageRecordEntity(
                    packageName = packageName,
                    dateEpoch   = dateEpoch,
                    bonusMs     = additionalBonusMs,
                    usageMs     = 0L,
                    updatedAt   = System.currentTimeMillis()
                )
            )
        } else {
            addBonusTime(packageName, dateEpoch, additionalBonusMs)
        }
    }

    @Insert
    suspend fun insertOverride(overrideEntity: ParentOverrideEntity): Long

    @Transaction
    suspend fun addBonusAndLogOverride(
        packageName: String,
        dateEpoch: Long,
        bonusMs: Long,
        bonusMinutes: Int,
        timestamp: Long
    ) {
        addBonusTimeSafe(packageName, dateEpoch, bonusMs)
        insertOverride(
            ParentOverrideEntity(
                packageName = packageName,
                bonusMinutes = bonusMinutes,
                overriddenAt = timestamp
            )
        )
    }

    /** Called by MidnightResetWorker — deletes records older than 30 days */
    @Query("DELETE FROM usage_records WHERE date_epoch < :cutoffEpoch")
    suspend fun deleteOldRecords(cutoffEpoch: Long)

    @Query("DELETE FROM usage_records WHERE date_epoch < :beforeEpoch")
    suspend fun deleteOldRecordsBefore(beforeEpoch: Long)
}

/** Lightweight projection used by weekly summary query */
data class AppUsageSummary(
    @ColumnInfo(name = "package_name") val packageName: String,
    @ColumnInfo(name = "total_usage_ms") val totalUsageMs: Long
)

// ─────────────────────────────────────────────────────────────────
// AppLockEventDao
// ─────────────────────────────────────────────────────────────────
@Dao
interface AppLockEventDao {

    @Insert
    suspend fun insertLockEvent(event: AppLockEventEntity): Long

    @Query("UPDATE app_lock_events SET unlocked_at = :now, unlock_reason = :reason, bonus_minutes_granted = :bonusMinutes WHERE id = :id")
    suspend fun resolveLockEvent(id: Long, now: Long = System.currentTimeMillis(), reason: String, bonusMinutes: Int)

    /** Most recent PENDING lock for a package (should be at most one at a time) */
    @Query("""
        SELECT * FROM app_lock_events
        WHERE package_name = :packageName AND unlock_reason = 'PENDING'
        ORDER BY locked_at DESC
        LIMIT 1
    """)
    suspend fun getPendingLock(packageName: String): AppLockEventEntity?

    @Query("""
        SELECT * FROM app_lock_events
        WHERE locked_at >= :fromEpoch
        ORDER BY locked_at DESC
    """)
    fun observeLockEventsSince(fromEpoch: Long): Flow<List<AppLockEventEntity>>

    @Query("SELECT COUNT(*) FROM app_lock_events WHERE package_name = :packageName AND locked_at >= :fromEpoch")
    suspend fun countLocksForPackage(packageName: String, fromEpoch: Long): Int
}

// ─────────────────────────────────────────────────────────────────
// ChallengeAttemptDao
// ─────────────────────────────────────────────────────────────────
@Dao
interface ChallengeAttemptDao {

    @Insert
    suspend fun insertAttempt(attempt: ChallengeAttemptEntity): Long

    /** How many challenges attempted today (across all sessions) */
    @Query("""
        SELECT COUNT(*) FROM challenge_attempts
        WHERE attempted_at >= :startOfDayMs
    """)
    suspend fun countAttemptsToday(startOfDayMs: Long): Int

    /** Attempts for a specific lock session */
    @Query("SELECT * FROM challenge_attempts WHERE lock_event_id = :lockEventId ORDER BY attempt_number ASC")
    suspend fun getAttemptsForSession(lockEventId: Long): List<ChallengeAttemptEntity>

    /** Aggregate success rate for analytics */
    @Query("""
        SELECT COUNT(*) as total,
               SUM(CASE WHEN is_correct = 1 THEN 1 ELSE 0 END) as correct,
               SUM(stars_earned) as total_stars
        FROM challenge_attempts
        WHERE attempted_at >= :fromMs
    """)
    suspend fun getSuccessStats(fromMs: Long): ChallengeStats

    /** IDs of challenges shown recently — used to avoid duplicates */
    @Query("""
        SELECT challenge_id FROM challenge_attempts
        WHERE attempted_at >= :sinceMs
        GROUP BY challenge_id
    """)
    suspend fun getRecentChallengeIds(sinceMs: Long): List<Long>

    /** ✅ ADDED: Observe all attempts since a timestamp for daily breakdown */
    @Query("SELECT * FROM challenge_attempts WHERE attempted_at >= :fromMs ORDER BY attempted_at ASC")
    fun observeAttemptsSince(fromMs: Long): Flow<List<ChallengeAttemptEntity>>
}

data class ChallengeStats(
    @ColumnInfo(name = "total") val total: Int,
    @ColumnInfo(name = "correct") val correct: Int,
    @ColumnInfo(name = "total_stars") val totalStars: Int
)

// ─────────────────────────────────────────────────────────────────
// ChallengeDao
// ─────────────────────────────────────────────────────────────────
@Dao
interface ChallengeDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(challenges: List<ChallengeEntity>)

    /** Pick a random age-appropriate challenge, excluding recently seen ones */
    @Query("""
        SELECT * FROM challenges
        WHERE min_age <= :age AND max_age >= :age
          AND (:excludeIds IS NULL OR id NOT IN (:excludeIds))
        ORDER BY RANDOM()
        LIMIT 1
    """)
    suspend fun getRandomChallenge(age: Int, excludeIds: List<Long> = emptyList()): ChallengeEntity?

    /** Pick by specific type (for weighted distribution) */
    @Query("""
        SELECT * FROM challenges
        WHERE min_age <= :age AND max_age >= :age
          AND type = :type
          AND (:excludeIds IS NULL OR id NOT IN (:excludeIds))
        ORDER BY RANDOM()
        LIMIT 1
    """)
    suspend fun getRandomChallengeByType(age: Int, type: String, excludeIds: List<Long> = emptyList()): ChallengeEntity?

    @Query("SELECT COUNT(*) FROM challenges")
    suspend fun count(): Int
}

// ─────────────────────────────────────────────────────────────────
// ParentOverrideDao
// ─────────────────────────────────────────────────────────────────
@Dao
interface ParentOverrideDao {

    @Insert
    suspend fun logOverride(override: ParentOverrideEntity): Long

    @Query("""
        SELECT * FROM parent_overrides
        WHERE overridden_at >= :fromMs
        ORDER BY overridden_at DESC
    """)
    fun observeOverridesSince(fromMs: Long): Flow<List<ParentOverrideEntity>>

    @Query("SELECT COUNT(*) FROM parent_overrides WHERE overridden_at >= :fromMs")
    suspend fun countOverridesSince(fromMs: Long): Int
}
