package com.kidtimeguard.app.service

import android.content.Context
import android.content.Intent
import android.util.Log
import com.kidtimeguard.app.data.repository.AppUsageRepository
import com.kidtimeguard.app.ui.lock.LockOverlayActivity
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.ZoneId
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Manages the high-priority triggering of the Lock UI.
 * Designed to be "Strong and Robust" to prevent bypasses.
 */
@Singleton
class AppLockManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val appUsageRepository: AppUsageRepository
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val TAG = "AppLockManager"

    private val activeLocks = mutableSetOf<String>()
    private val enforcedLocks = mutableMapOf<String, Long>()
    
    // ✅ Hardcoded IST for absolute consistency
    private val indianZone = ZoneId.of("Asia/Kolkata")

    /**
     * Aggressively triggers the LockOverlayActivity.
     * Uses high-priority intent flags to ensure the UI stays on top.
     */
    fun onLimitReached(packageName: String, appName: String) {
        val isFirstTrigger = synchronized(activeLocks) {
            activeLocks.add(packageName)
        }

        scope.launch {
            try {
                // If it's a fresh lock session, record it. 
                // If already locked, we still proceed to "force-to-front" the activity.
                val lockEventId = if (isFirstTrigger) {
                    appUsageRepository.recordLockEvent(packageName)
                } else {
                    appUsageRepository.getPendingLock(packageName)?.id ?: -1L
                }
                
                withContext(Dispatchers.Main) {
                    val intent = LockOverlayActivity.createIntent(
                        context      = context,
                        packageName  = packageName,
                        appName      = appName,
                        lockEventId  = lockEventId
                    )
                    
                    // 🛡️ ROBUST FLAGS:
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                    intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
                    
                    Log.d(TAG, "🚀 Robust Trigger: Launching Lock Screen for $packageName")
                    context.startActivity(intent)
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ Failed to trigger robust lock UI", e)
                if (isFirstTrigger) onLockResolved(packageName)
            }
        }
    }

    fun onLockResolved(packageName: String) {
        synchronized(activeLocks) { activeLocks.remove(packageName) }
        Log.d(TAG, "🔓 Lock session resolved for $packageName")
    }

    fun isLocked(packageName: String): Boolean =
        synchronized(activeLocks) { activeLocks.contains(packageName) }

    fun extendUsageTime(packageName: String, minutes: Int) {
        scope.launch {
            try {
                // ✅ Fix: Use IST for date calculation when adding bonus time
                val today = LocalDate.now(indianZone)
                val dateEpoch = today.toEpochDay()
                
                appUsageRepository.addBonusAndLogOverride(
                    packageName  = packageName,
                    dateEpoch    = dateEpoch,
                    bonusMs      = minutes * 60_000L,
                    bonusMinutes = minutes,
                    timestamp    = System.currentTimeMillis()
                )
                
                clearEnforcedLock(packageName)
                onLockResolved(packageName)
                Log.d(TAG, "✅ Time extended: +$minutes min for $packageName (IST)")
            } catch (e: Exception) {
                Log.e(TAG, "Error extending time", e)
            }
        }
    }

    fun startEnforcedLock(packageName: String, durationMs: Long = 60 * 60_000L) {
        synchronized(enforcedLocks) {
            enforcedLocks[packageName] = System.currentTimeMillis() + durationMs
        }
        onLockResolved(packageName)
    }

    fun isEnforcedLocked(packageName: String): Boolean {
        val expiry = synchronized(enforcedLocks) { enforcedLocks[packageName] } ?: return false
        if (System.currentTimeMillis() > expiry) {
            synchronized(enforcedLocks) { enforcedLocks.remove(packageName) }
            return false
        }
        return true
    }

    fun clearEnforcedLock(packageName: String) {
        synchronized(enforcedLocks) { enforcedLocks.remove(packageName) }
    }
}
