package com.kidtimeguard.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.kidtimeguard.app.service.UsageTrackingService
import com.kidtimeguard.app.worker.MidnightResetWorker

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED &&
            intent.action != Intent.ACTION_MY_PACKAGE_REPLACED) return

        // Start the usage tracking service
        UsageTrackingService.start(context)

        // ✅ FIX: Wrap in try-catch — WorkManager may not be initialized
        // yet if the app process was just started by the boot broadcast.
        // The service will schedule the worker once it starts up properly.
        try {
            MidnightResetWorker.schedule(context)
        } catch (e: IllegalStateException) {
            // WorkManager not ready yet — UsageTrackingService will
            // schedule MidnightResetWorker when it starts
            android.util.Log.w("BootReceiver",
                "WorkManager not ready at boot, worker will be scheduled by service")
        }
    }
}