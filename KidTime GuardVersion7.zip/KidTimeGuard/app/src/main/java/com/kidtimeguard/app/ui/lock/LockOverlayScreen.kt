package com.kidtimeguard.app.ui.lock

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.kidtimeguard.app.ui.components.ChallengeTimer
import com.kidtimeguard.app.ui.components.AnimatedStarRow
import com.kidtimeguard.app.ui.components.BonusTimeBadge
import com.kidtimeguard.app.ui.components.LevelUpDialog
import com.kidtimeguard.app.ui.theme.*
import org.json.JSONArray

enum class AnswerState { Default, Correct, Wrong, Dimmed }

@Composable
fun LockOverlayScreen(
    uiState: LockUiState,
    onEarnTime: () -> Unit,
    onTakeBreak: () -> Unit,
    onAskParent: () -> Unit,
    onPinSubmit: (String) -> Unit,
    onPinDismiss: () -> Unit,
    onParentBonusSelected: (Int) -> Unit, // ✅ Fixed: Added parameter
    onAnswerChallenge: (Int) -> Unit,
    onNextChallenge: () -> Unit,
    onChallengesDone: () -> Unit,
    onLevelUpDismiss: () -> Unit,
) {
    // 1️⃣ SYSTEM ENFORCEMENT: Disable Back Button
    BackHandler(enabled = true) { /* Blocked */ }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color    = MaterialTheme.colorScheme.background
    ) {
        Box {
            AnimatedContent(
                targetState = uiState.screen,
                transitionSpec = {
                    fadeIn(tween(400)) togetherWith fadeOut(tween(400))
                },
                label = "lock_screen_transition"
            ) { screen ->
                when (screen) {
                    LockScreen.Options         -> OptionsScreen(uiState, onEarnTime, onTakeBreak, onAskParent)
                    LockScreen.Challenge       -> ChallengeScreen(uiState, onAnswerChallenge)
                    LockScreen.ChallengeResult -> ChallengeResultScreen(uiState, onNextChallenge, onChallengesDone)
                    LockScreen.AllChallengesDone -> AllChallengesDoneScreen(uiState.sessionBonusMinutesTotal, onChallengesDone)
                    LockScreen.TakeBreakConfirmation -> TakeBreakConfirmationScreen()
                    LockScreen.ParentPin       -> OptionsScreen(uiState, onEarnTime, onTakeBreak, onAskParent)
                }
            }

            // 🎯 Global Loading Overlay
            if (uiState.isLoading) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.Black.copy(alpha = 0.4f)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(44.dp))
                                Spacer(Modifier.height(16.dp))
                                Text("Getting your challenge ready...", style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }
        }

        if (uiState.screen == LockScreen.ParentPin) {
            ParentPinDialog(
                error              = uiState.pinError,
                bonusMinutes       = uiState.parentBonusMinutesSelected,
                onBonusSelected    = onParentBonusSelected, // ✅ Fixed: Connected to parameter
                onSubmit           = onPinSubmit,
                onDismiss          = onPinDismiss
            )
        }

        if (uiState.showLevelUpDialog) {
            LevelUpDialog(
                newLevel  = uiState.rewardResult?.newLevel ?: 1,
                onDismiss = onLevelUpDismiss
            )
        }
    }
}

// ── Options Screen ────────────────────────────────────────────────

@Composable
private fun OptionsScreen(
    uiState: LockUiState,
    onEarnTime: () -> Unit,
    onTakeBreak: () -> Unit,
    onAskParent: () -> Unit
) {
    Column(
        modifier            = Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier.size(88.dp).clip(CircleShape).background(LimitReachedRed.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Lock, null, tint = LimitReachedRed, modifier = Modifier.size(44.dp))
        }

        Spacer(Modifier.height(24.dp))
        Text("Time's Up!", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("You've reached your daily limit for\n${uiState.appName}", style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f))
        
        Spacer(Modifier.height(32.dp))

        LockActionButton(
            icon       = Icons.Filled.School,
            title      = "Solve Challenges",
            subtitle   = "Answer questions to earn more time",
            color      = MaterialTheme.colorScheme.primary,
            onClick    = onEarnTime,
            enabled    = !uiState.isLoading
        )

        Spacer(Modifier.height(12.dp))

        LockActionButton(
            icon       = Icons.Filled.SelfImprovement,
            title      = "Take a Rest",
            subtitle   = "Step away and earn stars",
            color      = SuccessGreen,
            onClick    = onTakeBreak,
            enabled    = !uiState.isLoading
        )

        Spacer(Modifier.height(12.dp))

        LockActionButton(
            icon       = Icons.Filled.SupervisorAccount,
            title      = "Ask Parent",
            subtitle   = "Enter PIN for extra time",
            color      = MaterialTheme.colorScheme.secondary,
            onClick    = onAskParent,
            enabled    = !uiState.isLoading
        )
    }
}

@Composable
private fun LockActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    color: Color,
    onClick: () -> Unit,
    enabled: Boolean = true
) {
    Card(
        onClick  = { if (enabled) onClick() },
        modifier = Modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(16.dp),
        colors   = CardDefaults.cardColors(
            containerColor = color.copy(alpha = if (enabled) 0.08f else 0.04f)
        ),
        border   = BorderStroke(1.dp, color.copy(alpha = if (enabled) 0.3f else 0.1f))
    ) {
        Row(
            modifier = Modifier.padding(16.dp).alpha(if (enabled) 1f else 0.5f), 
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(modifier = Modifier.size(48.dp).clip(CircleShape).background(color.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = color, modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.width(16.dp))
            Column {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(0.6f))
            }
            Spacer(Modifier.weight(1f))
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = color)
        }
    }
}

// ── Challenge Screen ──────────────────────────────────────────────

@Composable
private fun ChallengeScreen(
    uiState: LockUiState,
    onAnswerSelected: (Int) -> Unit
) {
    val challenge = uiState.challenge 
    
    if (challenge == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    val options   = remember(challenge.optionsJson) {
        try {
            val arr = JSONArray(challenge.optionsJson)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (e: Exception) { emptyList<String>() }
    }

    Column(
        modifier            = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(16.dp))
        
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column(modifier = Modifier.weight(1f).padding(end = 16.dp)) {
                LinearProgressIndicator(
                    progress = { (uiState.sessionChallengesCompleted.toFloat()) / LockViewModel.MAX_CHALLENGES_PER_SESSION },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
                )
                Text("Question ${uiState.sessionChallengesCompleted + 1} of ${LockViewModel.MAX_CHALLENGES_PER_SESSION}", style = MaterialTheme.typography.labelSmall)
            }

            if (!uiState.answerSubmitted) {
                ChallengeTimer(totalSeconds = 30, onTimeExpired = { onAnswerSelected(-1) })
            }
        }

        Spacer(Modifier.height(24.dp))

        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Text(text = challenge.question, modifier = Modifier.padding(24.dp), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
        }

        Spacer(Modifier.height(24.dp))

        options.forEachIndexed { index, option ->
            AnswerOptionButton(
                label = ('A' + index).toString(),
                text = option,
                state = when {
                    !uiState.answerSubmitted -> AnswerState.Default
                    index == challenge.correctIndex -> AnswerState.Correct
                    index == uiState.selectedAnswerIndex -> AnswerState.Wrong
                    else -> AnswerState.Dimmed
                },
                onClick = { if (!uiState.answerSubmitted) onAnswerSelected(index) }
            )
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
private fun ParentPinDialog(
    error: String?,
    bonusMinutes: Int,
    onBonusSelected: (Int) -> Unit,
    onSubmit: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var pin by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(shape = RoundedCornerShape(24.dp)) {
            Column(modifier = Modifier.padding(24.dp)) {
                Text("Parent Approval", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(16.dp))
                
                Text("Grant extra time:", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(15, 30, 60).forEach { mins ->
                        FilterChip(
                            selected = bonusMinutes == mins, // ✅ Fixed: Use prop directly
                            onClick = { onBonusSelected(mins) }, // ✅ Fixed: Call prop
                            label    = { Text("${mins}m") }
                        )
                    }
                }

                Spacer(Modifier.height(16.dp))
                OutlinedTextField(
                    value = pin,
                    onValueChange = { if (it.length <= 6) pin = it },
                    label = { Text("Parent PIN") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    modifier = Modifier.fillMaxWidth(),
                    isError = error != null,
                    supportingText = error?.let { { Text(it) } }
                )

                Spacer(Modifier.height(24.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Button(onClick = { onSubmit(pin) }, enabled = pin.length >= 4) { Text("Unlock") }
                }
            }
        }
    }
}

@Composable
private fun TakeBreakConfirmationScreen() {
    Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Filled.SelfImprovement, null, tint = SuccessGreen, modifier = Modifier.size(80.dp))
        Spacer(Modifier.height(24.dp))
        Text("Great Job Resting!", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("You've earned +5 stars.", style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(24.dp))
        AnimatedStarRow(starsEarned = 5, totalStars = 5)
    }
}

@Composable
private fun AllChallengesDoneScreen(totalBonusMinutes: Int, onDone: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Filled.EmojiEvents, null, tint = StarGold, modifier = Modifier.size(100.dp))
        Spacer(Modifier.height(24.dp))
        Text("Session Complete!", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("You earned +$totalBonusMinutes bonus minutes today.", textAlign = TextAlign.Center)
        Spacer(Modifier.height(32.dp))
        Button(onClick = onDone, modifier = Modifier.fillMaxWidth()) { Text("Resume App") }
    }
}

@Composable
private fun AnswerOptionButton(label: String, text: String, state: AnswerState, onClick: () -> Unit) {
    val (bgColor, borderColor, textColor) = when (state) {
        AnswerState.Correct -> Triple(SuccessGreen.copy(0.1f), SuccessGreen, SuccessGreen)
        AnswerState.Wrong -> Triple(LimitReachedRed.copy(0.1f), LimitReachedRed, LimitReachedRed)
        AnswerState.Dimmed -> Triple(Color.Transparent, MaterialTheme.colorScheme.outline.copy(0.2f), MaterialTheme.colorScheme.onSurface.copy(0.4f))
        AnswerState.Default -> Triple(Color.Transparent, MaterialTheme.colorScheme.outline, MaterialTheme.colorScheme.onSurface)
    }

    Card(onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, borderColor), colors = CardDefaults.cardColors(containerColor = bgColor)) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = CircleShape, color = borderColor.copy(0.1f)) {
                Text(label, modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp), fontWeight = FontWeight.Bold, color = borderColor)
            }
            Spacer(Modifier.width(16.dp))
            Text(text, style = MaterialTheme.typography.bodyLarge, color = textColor)
        }
    }
}

@Composable
private fun ChallengeResultScreen(uiState: LockUiState, onNext: () -> Unit, onDone: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        val (icon, color, title) = if (uiState.isCorrect) Triple(Icons.Filled.CheckCircle, SuccessGreen, "Correct!") else Triple(Icons.Filled.Cancel, LimitReachedRed, "Try Again!")
        Icon(icon, null, tint = color, modifier = Modifier.size(80.dp))
        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = color)
        
        Spacer(Modifier.height(24.dp))
        AnimatedStarRow(starsEarned = uiState.starsEarned, totalStars = 3)
        BonusTimeBadge(minutes = uiState.bonusMinutesEarned, visible = true)
        
        Spacer(Modifier.height(32.dp))
        if (uiState.sessionChallengesCompleted + 1 < LockViewModel.MAX_CHALLENGES_PER_SESSION) {
            Button(onClick = onNext, modifier = Modifier.fillMaxWidth()) { Text("Next Question") }
        } else {
            Button(onClick = onDone, modifier = Modifier.fillMaxWidth()) { Text("Finish Session") }
        }
    }
}
