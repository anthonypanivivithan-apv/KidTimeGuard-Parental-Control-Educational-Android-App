package com.kidtimeguard.app.ui.setup

import android.graphics.drawable.Drawable
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap

// ── Icon helper — cached by packageName ──────────────────────────
@Composable
internal fun rememberIcon(packageName: String): ImageBitmap? {
    val context = LocalContext.current
    return remember(packageName) {
        try {
            val d: Drawable = context.packageManager.getApplicationIcon(packageName)
            d.toBitmap(96, 96).asImageBitmap()
        } catch (_: Exception) { null }
    }
}

// ─────────────────────────────────────────────────────────────────
// Screen 4 — Select Apps to Monitor
//
// KEY DESIGN:
//   viewModel is passed IN from MainActivity, scoped to SETUP_GRAPH.
//   This means every state change here persists when navigating to
//   SetTimeLimitsScreen because BOTH screens share the same instance.
//
// NAVIGATION CONTRACT:
//   "Continue" button calls viewModel.saveSelectedApps() to populate
//   selectedAppsForLimits, then calls onNext() to navigate.
//   onNext() does NOT call saveSelectedApps() again — that was the
//   double-call bug.
// ─────────────────────────────────────────────────────────────────
@Composable
fun SelectAppsScreen(
    viewModel : SetupViewModel,
    onNext    : () -> Unit
) {
    val uiState     by viewModel.uiState.collectAsState()
    var searchQuery by remember { mutableStateOf("") }

    val categoryMeta = mapOf(
        "SOCIAL_MEDIA" to Pair("Social Media",     Icons.Filled.People),
        "GAMES"        to Pair("Games",             Icons.Filled.SportsEsports),
        "VIDEO"        to Pair("Video & Streaming", Icons.Filled.PlayCircle),
        "EDUCATION"    to Pair("Education",         Icons.Filled.School),
        "OTHER"        to Pair("Other Apps",        Icons.Filled.Apps)
    )
    val categoryOrder = listOf("SOCIAL_MEDIA", "GAMES", "VIDEO", "EDUCATION", "OTHER")

    SetupScaffold(
        step     = 4,
        total    = 5,
        title    = "Select Apps to Monitor",
        subtitle = "Choose which apps to track. Social, games and video are pre-selected."
    ) {

        // ── Search bar ────────────────────────────────────────
        OutlinedTextField(
            value         = searchQuery,
            onValueChange = { searchQuery = it; viewModel.onSearchQueryChanged(it) },
            label         = { Text("Search any app…") },
            modifier      = Modifier.fillMaxWidth(),
            leadingIcon   = { Icon(Icons.Filled.Search, null) },
            trailingIcon  = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = {
                        searchQuery = ""
                        viewModel.onSearchQueryChanged("")
                    }) { Icon(Icons.Filled.Clear, null) }
                }
            },
            singleLine = true
        )

        Spacer(Modifier.height(8.dp))

        // ── Stats + bulk actions ──────────────────────────────
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text(
                if (uiState.isLoadingApps) "Loading…"
                else "${uiState.selectedPackages.size} of ${uiState.installedApps.size} selected",
                style      = MaterialTheme.typography.labelMedium,
                color      = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.SemiBold
            )
            Row {
                TextButton(onClick = { viewModel.selectAll() }) {
                    Text("All", style = MaterialTheme.typography.labelSmall)
                }
                TextButton(onClick = { viewModel.deselectAll() }) {
                    Text("None", style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        Spacer(Modifier.height(4.dp))

        // ── Loading state ─────────────────────────────────────
        if (uiState.isLoadingApps) {
            Box(Modifier.fillMaxWidth().weight(1f), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(Modifier.size(44.dp))
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Scanning all apps on your phone…",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface.copy(0.6f)
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Instagram, YouTube, Free Fire will appear shortly",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(0.4f)
                    )
                }
            }
        } else {
            val filtered = viewModel.getFilteredApps()

            if (filtered.isEmpty()) {
                // ── No results ────────────────────────────────
                Box(Modifier.fillMaxWidth().weight(1f), Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.SearchOff, null, Modifier.size(44.dp),
                            tint = MaterialTheme.colorScheme.onSurface.copy(0.3f))
                        Spacer(Modifier.height(8.dp))
                        Text("No apps match \"$searchQuery\"",
                            style     = MaterialTheme.typography.bodyMedium,
                            color     = MaterialTheme.colorScheme.onSurface.copy(0.5f),
                            textAlign = TextAlign.Center)
                    }
                }
            } else if (searchQuery.isNotEmpty()) {
                // ── Flat search results ───────────────────────
                LazyColumn(
                    modifier            = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    item {
                        Text("${filtered.size} result${if (filtered.size != 1) "s" else ""}",
                            style    = MaterialTheme.typography.labelSmall,
                            color    = MaterialTheme.colorScheme.onSurface.copy(0.5f),
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                    }
                    items(filtered, key = { it.packageName }) { app ->
                        AppSelectRow(
                            packageName = app.packageName,
                            appName     = app.appName,
                            isSelected  = uiState.selectedPackages.contains(app.packageName),
                            onToggle    = { viewModel.toggleAppSelection(app.packageName) }
                        )
                    }
                    item { Spacer(Modifier.height(8.dp)) }
                }
            } else {
                // ── Grouped by category ───────────────────────
                val grouped = filtered.groupBy { it.category }
                LazyColumn(
                    modifier            = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    categoryOrder.forEach { cat ->
                        val apps = grouped[cat]
                        if (apps.isNullOrEmpty()) return@forEach
                        val (catName, catIcon) = categoryMeta[cat] ?: return@forEach

                        item(key = "hdr_$cat") {
                            Spacer(Modifier.height(8.dp))
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(catIcon, null, Modifier.size(18.dp),
                                    tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(6.dp))
                                Text("$catName (${apps.size})",
                                    style      = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.SemiBold,
                                    color      = MaterialTheme.colorScheme.primary,
                                    modifier   = Modifier.weight(1f))
                                val allSel = apps.all {
                                    uiState.selectedPackages.contains(it.packageName)
                                }
                                TextButton(onClick = {
                                    if (allSel) viewModel.deselectAllInCategory(cat)
                                    else        viewModel.selectAllInCategory(cat)
                                }) {
                                    Text(if (allSel) "Deselect all" else "Select all",
                                        style = MaterialTheme.typography.labelSmall)
                                }
                            }
                            HorizontalDivider()
                        }

                        items(apps, key = { it.packageName }) { app ->
                            AppSelectRow(
                                packageName = app.packageName,
                                appName     = app.appName,
                                isSelected  = uiState.selectedPackages.contains(app.packageName),
                                onToggle    = { viewModel.toggleAppSelection(app.packageName) }
                            )
                        }
                    }
                    item { Spacer(Modifier.height(8.dp)) }
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // ── Validation warning ────────────────────────────────
        if (!uiState.isLoadingApps && uiState.selectedPackages.isEmpty()) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.errorContainer
            ) {
                Row(Modifier.fillMaxWidth().padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Warning, null,
                        tint     = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Select at least one app to continue.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onErrorContainer)
                }
            }
            Spacer(Modifier.height(8.dp))
        }

        // ── Continue button ───────────────────────────────────
        Button(
            onClick = {
                // ✅ saveSelectedApps() is called HERE — not in MainActivity.
                // It converts selectedPackages → selectedAppsForLimits and
                // ensures every selected app has a limit entry in timeLimits.
                // Then onNext() navigates to SetTimeLimitsScreen which will
                // read the now-populated selectedAppsForLimits from the SAME VM.
                viewModel.saveSelectedApps()
                onNext()
            },
            modifier = Modifier.fillMaxWidth(),
            enabled  = uiState.selectedPackages.isNotEmpty() && !uiState.isLoadingApps
        ) {
            Icon(Icons.Filled.ArrowForward, null)
            Spacer(Modifier.width(8.dp))
            Text("Continue (${uiState.selectedPackages.size} selected)")
        }
    }
}

// ── App row composable ────────────────────────────────────────────
@Composable
internal fun AppSelectRow(
    packageName : String,
    appName     : String,
    isSelected  : Boolean,
    onToggle    : () -> Unit
) {
    val icon = rememberIcon(packageName)

    Card(
        onClick   = onToggle,
        modifier  = Modifier.fillMaxWidth(),
        shape     = RoundedCornerShape(10.dp),
        colors    = CardDefaults.cardColors(
            containerColor = if (isSelected)
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
            else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Row(
            Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (icon != null) {
                Image(icon, appName, Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)))
            } else {
                Box(
                    Modifier.size(42.dp).background(
                        MaterialTheme.colorScheme.secondaryContainer,
                        RoundedCornerShape(10.dp)
                    ), Alignment.Center
                ) {
                    Text(
                        appName.firstOrNull()?.uppercaseChar()?.toString() ?: "?",
                        style      = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color      = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(appName, style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium, maxLines = 1)
                Text(packageName, style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(0.4f), maxLines = 1)
            }
            Checkbox(checked = isSelected, onCheckedChange = { onToggle() })
        }
    }
}