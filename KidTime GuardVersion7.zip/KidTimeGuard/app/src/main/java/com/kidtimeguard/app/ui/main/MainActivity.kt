package com.kidtimeguard.app.ui.main

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.WindowCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.navigation
import androidx.navigation.compose.rememberNavController
import com.kidtimeguard.app.security.PinLockScreen
import com.kidtimeguard.app.security.PinLockViewModel
import com.kidtimeguard.app.ui.navigation.NavGraph
import com.kidtimeguard.app.ui.navigation.Screen
import com.kidtimeguard.app.ui.parent.AnalyticsScreen
import com.kidtimeguard.app.ui.parent.AppManagementScreen
import com.kidtimeguard.app.ui.parent.ManageAppsFlowScreen
import com.kidtimeguard.app.ui.parent.OverrideLogScreen
import com.kidtimeguard.app.ui.parent.ParentDashboardScreen
import com.kidtimeguard.app.ui.parent.SettingsScreen
import com.kidtimeguard.app.ui.setup.SetupAppSelectionScreen
import com.kidtimeguard.app.ui.setup.SetupChildProfileScreen
import com.kidtimeguard.app.ui.setup.SetupPermissionsScreen
import com.kidtimeguard.app.ui.setup.SetupPinScreen
import com.kidtimeguard.app.ui.setup.SetupTimeLimitsScreen
import com.kidtimeguard.app.ui.setup.SetupViewModel
import com.kidtimeguard.app.ui.theme.KidTimeGuardTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        installSplashScreen().setKeepOnScreenCondition {
            viewModel.isLoadingStartDestination.value
        }

        WindowCompat.setDecorFitsSystemWindows(window, false)
        enableEdgeToEdge()

        setContent {
            // ✅ Global Theme Observation
            val isDarkTheme by viewModel.isDarkTheme.collectAsState()

            KidTimeGuardTheme(darkTheme = isDarkTheme) {
                val pinLockViewModel: PinLockViewModel = hiltViewModel()
                val pinLockState by pinLockViewModel.uiState.collectAsState()
                val startDestination by viewModel.startDestination.collectAsState()

                // 🔒 SECURE LOCK LOGIC: Detect when app comes to foreground
                LaunchedEffect(Unit) {
                    val observer = LifecycleEventObserver { _, event ->
                        if (event == Lifecycle.Event.ON_RESUME) {
                            pinLockViewModel.lock()
                        }
                    }
                    lifecycle.addObserver(observer)
                }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color    = MaterialTheme.colorScheme.background
                ) {
                    if (startDestination == null) {
                        Box(Modifier.fillMaxSize(), Alignment.Center) {
                            CircularProgressIndicator()
                        }
                    } else if (startDestination != NavGraph.SETUP_GRAPH && !pinLockState.isUnlocked) {
                        // 🔒 Show PIN Lock screen for all screens except initial setup
                        PinLockScreen(viewModel = pinLockViewModel)
                    } else {
                        val navController = rememberNavController()

                        NavHost(
                            navController    = navController,
                            startDestination = startDestination!!
                        ) {

                            // ── Setup graph ──────────────────────
                            navigation(
                                startDestination = Screen.SetupPin.route,
                                route            = NavGraph.SETUP_GRAPH
                            ) {
                                composable(Screen.SetupPin.route) {
                                    val setupVM: SetupViewModel = hiltViewModel(
                                        navController.getBackStackEntry(NavGraph.SETUP_GRAPH)
                                    )
                                    SetupPinScreen(
                                        viewModel    = setupVM,
                                        onPinCreated = {
                                            navController.navigate(Screen.SetupChildProfile.route)
                                        }
                                    )
                                }

                                composable(Screen.SetupChildProfile.route) {
                                    val setupVM: SetupViewModel = hiltViewModel(
                                        navController.getBackStackEntry(NavGraph.SETUP_GRAPH)
                                    )
                                    SetupChildProfileScreen(
                                        viewModel = setupVM,
                                        onNext    = {
                                            navController.navigate(Screen.SetupPermissions.route)
                                        }
                                    )
                                }

                                composable(Screen.SetupPermissions.route) {
                                    SetupPermissionsScreen(
                                        onPermissionsGranted = {
                                            navController.navigate(Screen.SetupAppSelection.route)
                                        }
                                    )
                                }

                                composable(Screen.SetupAppSelection.route) {
                                    val setupVM: SetupViewModel = hiltViewModel(
                                        navController.getBackStackEntry(NavGraph.SETUP_GRAPH)
                                    )
                                    SetupAppSelectionScreen(
                                        viewModel = setupVM,
                                        onNext    = {
                                            setupVM.saveSelectedApps()
                                            navController.navigate(Screen.SetupTimeLimits.route)
                                        }
                                    )
                                }

                                composable(Screen.SetupTimeLimits.route) {
                                    val setupVM: SetupViewModel = hiltViewModel(
                                        navController.getBackStackEntry(NavGraph.SETUP_GRAPH)
                                    )
                                    SetupTimeLimitsScreen(
                                        viewModel       = setupVM,
                                        onSetupComplete = {
                                            navController.navigate(Screen.ParentDashboard.route) {
                                                popUpTo(NavGraph.SETUP_GRAPH) { inclusive = true }
                                            }
                                        }
                                    )
                                }
                            }

                            // ── Parent flow ──────────────────────
                            composable(Screen.ParentDashboard.route) {
                                ParentDashboardScreen(
                                    onNavigateToAnalytics     = {
                                        navController.navigate(Screen.Analytics.route)
                                    },
                                    onNavigateToAppManagement = {
                                        navController.navigate(Screen.ManageAppsFlow.route)
                                    },
                                    onNavigateToSettings      = {
                                        navController.navigate(Screen.Settings.route)
                                    }
                                )
                            }

                            composable(Screen.Analytics.route) {
                                AnalyticsScreen(
                                    onBack                  = { navController.popBackStack() },
                                    onNavigateToOverrideLog = {
                                        navController.navigate(Screen.OverrideLog.route)
                                    }
                                )
                            }

                            composable(Screen.AppManagement.route) {
                                AppManagementScreen(onBack = { navController.popBackStack() })
                            }
                            
                            composable(Screen.ManageAppsFlow.route) {
                                ManageAppsFlowScreen(onBack = { navController.popBackStack() })
                            }

                            composable(Screen.Settings.route) {
                                SettingsScreen(onBack = { navController.popBackStack() })
                            }

                            composable(Screen.OverrideLog.route) {
                                OverrideLogScreen(onBack = { navController.popBackStack() })
                            }
                        }
                    }
                }
            }
        }
    }
}
