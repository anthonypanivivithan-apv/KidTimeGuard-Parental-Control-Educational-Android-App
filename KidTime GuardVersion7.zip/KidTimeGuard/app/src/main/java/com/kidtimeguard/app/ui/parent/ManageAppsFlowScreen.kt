package com.kidtimeguard.app.ui.parent

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.kidtimeguard.app.ui.setup.AppSelectRow

enum class ManageAppsStep {
    SELECT_APPS,
    SET_LIMITS,
    SUCCESS
}

/**
 * ManageAppsFlowScreen
 * 
 * A wrapper screen that manages the flow between selecting apps and setting time limits
 * for existing users (outside of the initial setup).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManageAppsFlowScreen(
    viewModel: ManageAppsViewModel = hiltViewModel(),
    onBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    var currentStep by remember { mutableStateOf(ManageAppsStep.SELECT_APPS) }

    LaunchedEffect(uiState.saveSuccess) {
        if (uiState.saveSuccess) {
            currentStep = ManageAppsStep.SUCCESS
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        when (currentStep) {
                            ManageAppsStep.SELECT_APPS -> "Select Apps"
                            ManageAppsStep.SET_LIMITS -> "Set Time Limits"
                            ManageAppsStep.SUCCESS -> "Success"
                        }
                    )
                },
                navigationIcon = {
                    if (currentStep != ManageAppsStep.SUCCESS) {
                        IconButton(onClick = {
                            if (currentStep == ManageAppsStep.SET_LIMITS) {
                                currentStep = ManageAppsStep.SELECT_APPS
                            } else {
                                onBack()
                            }
                        }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                }
            )
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            AnimatedContent(
                targetState = currentStep,
                transitionSpec = {
                    fadeIn().togetherWith(fadeOut())
                },
                label = "ManageAppsFlow"
            ) { step ->
                when (step) {
                    ManageAppsStep.SELECT_APPS -> {
                        ManageAppsSelectionContent(
                            viewModel = viewModel,
                            onNext = {
                                viewModel.prepareLimits()
                                currentStep = ManageAppsStep.SET_LIMITS
                            }
                        )
                    }
                    ManageAppsStep.SET_LIMITS -> {
                        ManageAppsLimitsContent(
                            viewModel = viewModel,
                            onSave = {
                                viewModel.saveChanges()
                            }
                        )
                    }
                    ManageAppsStep.SUCCESS -> {
                        ManageAppsSuccessContent(onDone = onBack)
                    }
                }
            }

            if (uiState.isSaving) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.7f)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
            }
        }
    }
}

@Composable
private fun ManageAppsSelectionContent(
    viewModel: ManageAppsViewModel,
    onNext: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(
            value = uiState.searchQuery,
            onValueChange = { viewModel.onSearchQueryChanged(it) },
            label = { Text("Search apps") },
            modifier = Modifier.fillMaxWidth(),
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            singleLine = true
        )
        
        Spacer(Modifier.height(16.dp))
        
        Text(
            "${uiState.selectedPackages.size} apps selected",
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary
        )
        
        Spacer(Modifier.height(8.dp))
        
        if (uiState.isLoading) {
            Box(Modifier.weight(1f).fillMaxWidth(), Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            val filtered = viewModel.getFilteredApps()
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filtered, key = { it.packageName }) { app ->
                    val isSelected = uiState.selectedPackages.contains(app.packageName)
                    AppSelectRow(
                        packageName = app.packageName,
                        appName = app.appName,
                        isSelected = isSelected,
                        onToggle = { viewModel.toggleAppSelection(app.packageName) }
                    )
                }
            }
        }
        
        Button(
            onClick = onNext,
            modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
            enabled = uiState.selectedPackages.isNotEmpty() && !uiState.isLoading
        ) {
            Text("Next: Set Limits")
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null)
        }
    }
}

@Composable
private fun ManageAppsLimitsContent(
    viewModel: ManageAppsViewModel,
    onSave: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(
            "Set daily limits for selected apps",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        
        Spacer(Modifier.height(16.dp))
        
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(uiState.selectedAppsForLimits, key = { it.packageName }) { app ->
                val limits = uiState.timeLimits[app.packageName] ?: Pair(30, 60)
                
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(app.appName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        
                        Text("Weekday: ${limits.first}m", style = MaterialTheme.typography.bodySmall)
                        Slider(
                            value = limits.first.toFloat(),
                            onValueChange = { viewModel.setTimeLimit(app.packageName, it.toInt(), limits.second) },
                            valueRange = 5f..180f,
                            steps = 34
                        )
                        
                        Text("Weekend: ${limits.second}m", style = MaterialTheme.typography.bodySmall)
                        Slider(
                            value = limits.second.toFloat(),
                            onValueChange = { viewModel.setTimeLimit(app.packageName, limits.first, it.toInt()) },
                            valueRange = 5f..180f,
                            steps = 34
                        )
                    }
                }
            }
        }
        
        Button(
            onClick = onSave,
            modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
            enabled = !uiState.isSaving
        ) {
            Text("Save All Limits")
            Icon(Icons.Filled.Save, null)
        }
    }
}

@Composable
private fun ManageAppsSuccessContent(onDone: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Filled.CheckCircle,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(100.dp)
        )
        Spacer(Modifier.height(24.dp))
        Text(
            "Limits Saved Successfully!",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(16.dp))
        Text(
            "Your child's app usage limits have been updated and the tracking service is refreshed.",
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(48.dp))
        Button(
            onClick = onDone,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Done")
        }
    }
}
