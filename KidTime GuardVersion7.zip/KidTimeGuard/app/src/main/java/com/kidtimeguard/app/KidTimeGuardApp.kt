package com.kidtimeguard.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class KidTimeGuardApp : Application(), Configuration.Provider {

    @Inject
    lateinit var workerFactory: HiltWorkerFactory

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .setMinimumLoggingLevel(android.util.Log.INFO)
            .build()

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java)

        NotificationChannel(
            CHANNEL_TRACKING,
            "Screen Time Monitoring",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Keeps KidTime Guard running in the background"
            setShowBadge(false)
        }.also { manager.createNotificationChannel(it) }

        NotificationChannel(
            CHANNEL_LIMIT_REACHED,
            "Time Limit Alerts",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Notifies when an app has reached its daily time limit"
        }.also { manager.createNotificationChannel(it) }

        NotificationChannel(
            CHANNEL_REPORTS,
            "Weekly Reports",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "Weekly screen time summary reports"
        }.also { manager.createNotificationChannel(it) }
    }

    companion object {
        // ✅ Real string constants — NOT TODO()
        const val CHANNEL_TRACKING      = "channel_tracking"
        const val CHANNEL_LIMIT_REACHED = "channel_limit_reached"
        const val CHANNEL_REPORTS       = "channel_reports"

        // ✅ Real integer constant — NOT TODO()
        const val NOTIF_ID_TRACKING     = 1001
    }
}
