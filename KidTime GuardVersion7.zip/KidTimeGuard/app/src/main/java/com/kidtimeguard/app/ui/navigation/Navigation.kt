package com.kidtimeguard.app.ui.navigation

sealed class Screen(val route: String) {
    // Setup screens — using underscore format matching your NavGraph.kt
    object SetupPin          : Screen("setup_pin")
    object SetupChildProfile : Screen("setup_child_profile")
    object SetupPermissions  : Screen("setup_permissions")
    object SetupAppSelection : Screen("setup_app_selection")
    object SetupTimeLimits   : Screen("setup_time_limits")

    // Parent screens
    object ParentDashboard   : Screen("parent_dashboard")
    object Analytics         : Screen("analytics")
    object AppManagement     : Screen("app_management")
    object Settings          : Screen("settings")
    object OverrideLog       : Screen("override_log")
    
    // New Combined Flow
    object ManageAppsFlow    : Screen("manage_apps_flow")
}

object NavGraph {
    // ✅ Must match exactly what MainActivity.kt uses in:
    //   navigation(startDestination = Screen.SetupPin.route, route = NavGraph.SETUP_GRAPH)
    // AND what MainViewModel.kt uses as startDestination.
    const val SETUP_GRAPH  = "setup_graph"
    const val PARENT_GRAPH = "parent_graph"
}
