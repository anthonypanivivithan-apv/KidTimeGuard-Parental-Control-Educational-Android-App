package com.kidtimeguard.app.ui.setup

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

// ─────────────────────────────────────────────────────────────────
// Screen 5 — Set Daily Time Limits
//
// KEY DESIGN:
//   Receives the SAME SetupViewModel instance as SelectAppsScreen.
//   Reads selectedAppsForLimits (populated by saveSelectedApps()) and
//   timeLimits (populated at load time and updated by user).
//
//   EVERY slider directly writes back to the shared StateFlow via
//   viewModel.setTimeLimit(). There are NO local mutable state vars
//   for the slider values — they come from uiState.timeLimits.
//   This is the only correct pattern; local state would get out of
//   sync on recomposition and on back navigation.
//
// NAVIGATION:
//   completeSetup() persists to Room then sets setupSaved = true.
//   LaunchedEffect observes setupSaved and calls onSetupComplete().
// ─────────────────────────────────────────────────────────────────
@Composable
fun SetTimeLimitsScreen(
    viewModel      : SetupViewModel,
    onSetupComplete: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    // ✅ Navigation trigger — fires only when completeSetup() finishes
    LaunchedEffect(uiState.setupSaved) {
        if (uiState.setupSaved) onSetupComplete()
    }

    SetupScaffold(
        step     = 5,
        total    = 5,
        title    = "Set Daily Time Limits",
        subtitle = "Different limits for each app. Weekday and weekend can differ."
    ) {

        // ── Apply same limit to all ───────────────────────────
        ApplyAllCard(onApply = { weekday, weekend ->
            viewModel.setTimeLimitForAll(weekday, weekend)
        })

        Spacer(Modifier.height(12.dp))

        // ── Guard: selectedAppsForLimits is empty ─────────────
        // This should never happen in normal flow because the "Continue"
        // button on Screen 4 is disabled when nothing is selected.
        // But if user somehow arrives here without selections, show a message.
        if (uiState.selectedAppsForLimits.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.Warning, null, Modifier.size(40.dp),
                        tint = MaterialTheme.colorScheme.error.copy(0.5f))
                    Spacer(Modifier.height(8.dp))
                    Text("No apps were selected.",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface.copy(0.5f))
                    Spacer(Modifier.height(4.dp))
                    Text("Go back and select at least one app to monitor.",
                        style     = MaterialTheme.typography.bodySmall,
                        color     = MaterialTheme.colorScheme.onSurface.copy(0.4f),
                        textAlign = TextAlign.Center,
                        modifier  = Modifier.padding(horizontal = 32.dp))
                }
            }
        } else {
            // ── Per-app limit cards ───────────────────────────
            // ✅ This LazyColumn shows EXACTLY the apps from Screen 4.
            // Each item reads weekday/weekend from uiState.timeLimits[pkg]
            // which was populated by saveSelectedApps() before navigation.
            LazyColumn(
                modifier            = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(uiState.selectedAppsForLimits, key = { it.packageName }) { app ->

                    // ✅ These values come from the SHARED StateFlow.
                    // No local remember{} for slider values — this is critical.
                    // Local state would desync from the VM on recomposition.
                    val weekday = uiState.timeLimits[app.packageName]?.first  ?: 30
                    val weekend = uiState.timeLimits[app.packageName]?.second ?: 60
                    val icon    = rememberIcon(app.packageName)

                    AppTimeLimitCard(
                        packageName     = app.packageName,
                        appName         = app.appName,
                        category        = app.category,
                        icon            = icon,
                        weekday         = weekday,
                        weekend         = weekend,
                        // ✅ Writes directly to StateFlow — no local state
                        onWeekdayChange = { v ->
                            viewModel.setTimeLimit(app.packageName, v, weekend)
                        },
                        onWeekendChange = { v ->
                            viewModel.setTimeLimit(app.packageName, weekday, v)
                        },
                        onPreset        = { mins ->
                            viewModel.setTimeLimit(app.packageName, mins, mins + 30)
                        }
                    )
                }
                item { Spacer(Modifier.height(8.dp)) }
            }
        }

        Spacer(Modifier.height(12.dp))

        // ── Validation: show warning if any app has 0-minute limit ──
        val hasZeroLimit = uiState.selectedAppsForLimits.any { app ->
            val (w, we) = uiState.timeLimits[app.packageName] ?: Pair(0, 0)
            w == 0 || we == 0
        }

        AnimatedVisibility(
            visible = hasZeroLimit,
            enter   = fadeIn() + expandVertically()
        ) {
            Column {
                Surface(shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.errorContainer) {
                    Row(Modifier.fillMaxWidth().padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Warning, null,
                            tint     = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Some apps have 0-minute limits. Adjust or use a preset.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer)
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }

        // ── Start Monitoring button ───────────────────────────
        Button(
            onClick  = { viewModel.completeSetup() },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            enabled  = uiState.selectedAppsForLimits.isNotEmpty()
                    && !uiState.isSaving
                    && !hasZeroLimit,
            shape    = RoundedCornerShape(14.dp)
        ) {
            if (uiState.isSaving) {
                CircularProgressIndicator(
                    modifier    = Modifier.size(18.dp),
                    strokeWidth = 2.dp,
                    color       = MaterialTheme.colorScheme.onPrimary
                )
                Spacer(Modifier.width(10.dp))
                Text("Saving…")
            } else {
                Icon(Icons.Filled.PlayArrow, null)
                Spacer(Modifier.width(8.dp))
                Text("Start Monitoring", fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────
// Per-app time limit card
//
// ✅ Slider values (weekday, weekend) come from parent as parameters
//    sourced from uiState.timeLimits[packageName].
//    onWeekdayChange / onWeekendChange write directly to the StateFlow.
//    NO local mutableStateOf for slider values in this composable.
// ─────────────────────────────────────────────────────────────────
@Composable
private fun AppTimeLimitCard(
    packageName     : String,
    appName         : String,
    category        : String,
    icon            : androidx.compose.ui.graphics.ImageBitmap?,
    weekday         : Int,
    weekend         : Int,
    onWeekdayChange : (Int) -> Unit,
    onWeekendChange : (Int) -> Unit,
    onPreset        : (Int) -> Unit
) {
    val weekdayColor = when {
        weekday <= 15 -> Color(0xFF4CAF50)
        weekday <= 60 -> Color(0xFFFF9800)
        else          -> Color(0xFFE53935)
    }
    val weekendColor = when {
        weekend <= 30  -> Color(0xFF4CAF50)
        weekend <= 90  -> Color(0xFFFF9800)
        else           -> Color(0xFFE53935)
    }

    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp)) {

            // ── App header row ────────────────────────────────
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (icon != null) {
                    Image(icon, appName,
                        Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)))
                } else {
                    Box(
                        Modifier.size(40.dp).background(
                            MaterialTheme.colorScheme.secondaryContainer,
                            RoundedCornerShape(10.dp)
                        ), Alignment.Center
                    ) {
                        Text(
                            appName.firstOrNull()?.uppercaseChar()?.toString() ?: "?",
                            style      = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color      = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(appName,
                        style      = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        maxLines   = 1)
                    Text(
                        category.replace("_", " ").lowercase()
                            .replaceFirstChar { it.uppercase() },
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(0.5f)
                    )
                }
                // Live limit badge — updates as slider moves
                Surface(shape = RoundedCornerShape(50), color = weekdayColor.copy(0.12f)) {
                    Text("${weekday}m / day",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        style    = MaterialTheme.typography.labelSmall,
                        color    = weekdayColor,
                        fontWeight = FontWeight.Bold)
                }
            }

            HorizontalDivider(Modifier.padding(vertical = 12.dp))

            // ── Weekday slider ────────────────────────────────
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("Weekday",
                    style      = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium)
                Text("${weekday} min",
                    style      = MaterialTheme.typography.bodySmall,
                    color      = weekdayColor,
                    fontWeight = FontWeight.Bold)
            }
            // ✅ Slider reads weekday from parent state — no local var
            Slider(
                value         = weekday.toFloat(),
                onValueChange = { onWeekdayChange(it.toInt()) },
                valueRange    = 5f..180f,
                steps         = 34,
                colors        = SliderDefaults.colors(
                    thumbColor       = weekdayColor,
                    activeTrackColor = weekdayColor
                )
            )

            Spacer(Modifier.height(4.dp))

            // ── Weekend slider ────────────────────────────────
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("Weekend",
                    style      = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium)
                Text("${weekend} min",
                    style      = MaterialTheme.typography.bodySmall,
                    color      = weekendColor,
                    fontWeight = FontWeight.Bold)
            }
            Slider(
                value         = weekend.toFloat(),
                onValueChange = { onWeekendChange(it.toInt()) },
                valueRange    = 5f..180f,
                steps         = 34,
                colors        = SliderDefaults.colors(
                    thumbColor       = weekendColor,
                    activeTrackColor = weekendColor
                )
            )

            Spacer(Modifier.height(8.dp))

            // ── Quick preset chips ────────────────────────────
            Text("Quick presets:",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurface.copy(0.5f))
            Spacer(Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(15, 30, 60, 90, 120).forEach { mins ->
                    val isActive = weekday == mins
                    AssistChip(
                        onClick = { onPreset(mins) },
                        label   = {
                            Text("${mins}m",
                                fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal)
                        },
                        colors  = AssistChipDefaults.assistChipColors(
                            containerColor = if (isActive)
                                MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surface
                        )
                    )
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────
// "Apply same limit to all apps" expandable card
// ─────────────────────────────────────────────────────────────────
@Composable
private fun ApplyAllCard(onApply: (weekday: Int, weekend: Int) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    // Local state here is fine — these are the "apply-to-all" inputs,
    // not the per-app limits. They don't need to persist across navigation.
    var weekday by remember { mutableIntStateOf(30) }
    var weekend by remember { mutableIntStateOf(60) }

    Card(
        onClick  = { expanded = !expanded },
        modifier = Modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(12.dp),
        colors   = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.FormatListBulleted, null,
                    tint     = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Apply same limit to ALL apps",
                    style      = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                    color      = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier   = Modifier.weight(1f))
                Icon(
                    if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                    null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }

            AnimatedVisibility(visible = expanded, enter = fadeIn() + expandVertically()) {
                Column(Modifier.padding(top = 12.dp)) {
                    Text("Weekday: ${weekday}min",
                        style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                    Slider(value = weekday.toFloat(),
                        onValueChange = { weekday = it.toInt() },
                        valueRange = 5f..180f, steps = 34)

                    Text("Weekend: ${weekend}min",
                        style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                    Slider(value = weekend.toFloat(),
                        onValueChange = { weekend = it.toInt() },
                        valueRange = 5f..180f, steps = 34)

                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(15, 30, 60, 90, 120).forEach { m ->
                            AssistChip(
                                onClick = { weekday = m; weekend = m + 30 },
                                label   = { Text("${m}m") }
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick  = { onApply(weekday, weekend); expanded = false },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Filled.DoneAll, null, Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Apply ${weekday}m weekday / ${weekend}m weekend to all")
                    }
                }
            }
        }
    }
}