package com.kidtimeguard.app.ui.parent

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.kidtimeguard.app.ui.components.*
import com.kidtimeguard.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ParentDashboardScreen(
    viewModel                : ParentDashboardViewModel = hiltViewModel(),
    onNavigateToAnalytics    : () -> Unit,
    onNavigateToAppManagement: () -> Unit,
    onNavigateToSettings     : () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("KidTime Guard", style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold)
                        Text("Parental Controls", style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(0.5f))
                    }
                },
                actions = {
                    IconButton(onClick = onNavigateToAnalytics) {
                        Icon(Icons.Filled.BarChart, contentDescription = "Analytics")
                    }
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(Icons.Filled.Settings, contentDescription = "Settings")
                    }
                }
            )
        }
    ) { padding ->
        if (uiState.isLoading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        LazyColumn(
            modifier            = Modifier.fillMaxSize().padding(padding),
            contentPadding      = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            // ── Child profile card ──
            item {
                EnhancedChildProfileCard(
                    childName      = uiState.childName,
                    level          = uiState.childLevel,
                    totalStars     = uiState.totalStars,
                    xpProgress     = uiState.totalXp % 100,
                    xpForNextLevel = uiState.xpForNextLevel
                )
            }

            // ── Stats chips ──
            item {
                StatsChipRow(
                    totalMinutes  = uiState.todayTotalUsageMinutes,
                    appsMonitored = uiState.activeAppsCount,
                    lockedCount   = uiState.appUsageItems.count { it.usageMinutes >= it.limitMinutes }
                )
            }

            // ── Quick actions ──
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    QuickActionCard(
                        modifier = Modifier.weight(1f),
                        icon     = Icons.Filled.Apps,
                        label    = "Manage Apps",
                        onClick  = onNavigateToAppManagement
                    )
                    QuickActionCard(
                        modifier = Modifier.weight(1f),
                        icon     = Icons.Filled.BarChart,
                        label    = "Analytics",
                        onClick  = onNavigateToAnalytics
                    )
                }
            }

            // ── Today's usage ──
            item {
                SectionHeader(
                    title    = "Today's Usage",
                    action   = "View all",
                    onAction = onNavigateToAnalytics
                )
            }

            if (uiState.appUsageItems.isEmpty()) {
                item {
                    EmptyStateCard(
                        icon     = Icons.Filled.AddCircleOutline,
                        title    = "No apps monitored yet",
                        message  = "Add apps to start tracking screen time",
                        action   = "Add Apps",
                        onAction = onNavigateToAppManagement
                    )
                }
            } else {
                items(uiState.appUsageItems, key = { it.packageName }) { item ->
                    AppUsageCard(
                        appName = item.appName,
                        packageName = item.packageName,
                        usageMinutes = item.usageMinutes,
                        limitMinutes = item.limitMinutes,
                        isLocked = item.isLocked
                    )
                }
            }
        }
    }
}

@Composable
private fun EnhancedChildProfileCard(
    childName      : String,
    level          : Int,
    totalStars     : Int,
    xpProgress     : Int,
    xpForNextLevel : Int
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(24.dp),
        colors   = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Avatar
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("😊", style = MaterialTheme.typography.headlineMedium)
                }
                Spacer(Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(childName,
                        style      = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color      = MaterialTheme.colorScheme.onPrimaryContainer)
                    Row(
                        verticalAlignment     = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = MaterialTheme.colorScheme.primary.copy(0.2f)
                        ) {
                            Text("Level $level",
                                modifier   = Modifier.padding(horizontal = 10.dp, vertical = 2.dp),
                                style      = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color      = MaterialTheme.colorScheme.primary)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Star, null,
                                tint     = StarGold,
                                modifier = Modifier.size(16.dp))
                            Text(" $totalStars",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(0.7f))
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            XpProgressBar(
                currentXp = xpProgress,
                xpForNext = xpForNextLevel,
                level     = level
            )
        }
    }
}

@Composable
private fun QuickActionCard(
    modifier : Modifier,
    icon     : androidx.compose.ui.graphics.vector.ImageVector,
    label    : String,
    onClick  : () -> Unit
) {
    Card(
        onClick  = onClick,
        modifier = modifier,
        shape    = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier            = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null,
                modifier = Modifier.size(28.dp),
                tint     = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp))
            Text(label, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Medium)
        }
    }
}

