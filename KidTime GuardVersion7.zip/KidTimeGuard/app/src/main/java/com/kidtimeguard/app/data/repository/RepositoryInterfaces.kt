package com.kidtimeguard.app.data.repository

import com.kidtimeguard.app.data.local.entity.*
import com.kidtimeguard.app.data.local.dao.AppUsageSummary
import com.kidtimeguard.app.data.local.dao.ChallengeStats
import kotlinx.coroutines.flow.Flow

// ─────────────────────────────────────────────────────────────────
// Repository interfaces (Domain layer contracts)
// ─────────────────────────────────────────────────────────────────

interface AppUsageRepository {
    fun observeUsageRecord(packageName: String, dateEpoch: Long): Flow<UsageRecordEntity?>
    suspend fun getUsageRecord(packageName: String, dateEpoch: Long): UsageRecordEntity?
    suspend fun getRecordsForDate(dateEpoch: Long): List<UsageRecordEntity>
    suspend fun getUsageRecordsForDate(dateEpoch: Long): List<UsageRecordEntity>
    fun observeUsageRecordsForDate(dateEpoch: Long): Flow<List<UsageRecordEntity>>
    suspend fun upsertUsageRecord(record: UsageRecordEntity)
    suspend fun updateUsageMs(packageName: String, dateEpoch: Long, usageMs: Long)
    suspend fun addBonusTime(packageName: String, dateEpoch: Long, bonusMs: Long)
    suspend fun addBonusAndLogOverride(packageName: String, dateEpoch: Long, bonusMs: Long, bonusMinutes: Int, timestamp: Long = System.currentTimeMillis())
    suspend fun deleteOldRecords(beforeEpoch: Long)
    suspend fun recordLockEvent(packageName: String): Long
    suspend fun resolveLockEvent(lockEventId: Long, reason: String, bonusMinutes: Int)
    suspend fun getPendingLock(packageName: String): AppLockEventEntity?
    fun observeLockEventsSince(fromMs: Long): Flow<List<AppLockEventEntity>>
    suspend fun logParentOverride(packageName: String, bonusMinutes: Int)
}

interface ChallengeRepository {
    suspend fun getNextChallenge(age: Int, recentIds: List<Long>): ChallengeEntity?
    suspend fun getWeightedChallenge(age: Int, recentIds: List<Long>): ChallengeEntity?
    suspend fun recordAttempt(attempt: ChallengeAttemptEntity): Long
    suspend fun countAttemptsToday(startOfDayMs: Long): Int
    suspend fun getAttemptsForSession(lockEventId: Long): List<ChallengeAttemptEntity>
    suspend fun getRecentChallengeIds(sinceMs: Long): List<Long>
    suspend fun getChallengeStats(fromMs: Long): ChallengeStats
    /** ✅ ADDED: Observe all attempts for granular daily breakdown */
    fun observeAttemptsSince(fromMs: Long): Flow<List<ChallengeAttemptEntity>>
}

interface ChildProfileRepository {
    fun observeProfile(): Flow<ChildProfileEntity?>
    suspend fun getProfile(): ChildProfileEntity?
    suspend fun upsertProfile(profile: ChildProfileEntity): Long
    suspend fun addReward(profileId: Long, stars: Int, xp: Int)
    suspend fun updateLevel(profileId: Long, level: Int)
}

interface MonitoredAppRepository {
    fun observeActiveApps(): Flow<List<MonitoredAppEntity>>
    suspend fun getAllApps(): List<MonitoredAppEntity>
    suspend fun getAppByPackage(packageName: String): MonitoredAppEntity?
    suspend fun upsertApp(app: MonitoredAppEntity): Long
    suspend fun upsertApps(apps: List<MonitoredAppEntity>)
    suspend fun updateLimits(packageName: String, weekdayMinutes: Int, weekendMinutes: Int)
    suspend fun setActive(packageName: String, active: Boolean)
    suspend fun deleteApp(app: MonitoredAppEntity)
}

interface AnalyticsRepository {
    fun observeRecordsSince(fromEpoch: Long): Flow<List<UsageRecordEntity>>
    suspend fun getWeeklySummary(fromEpoch: Long, toEpoch: Long): List<AppUsageSummary>
    fun observeOverridesSince(fromMs: Long): Flow<List<ParentOverrideEntity>>
    suspend fun getChallengeStats(fromMs: Long): ChallengeStats
    suspend fun countOverridesSince(fromMs: Long): Int
    /** ✅ ADDED: Observe all attempts for granular daily breakdown */
    fun observeAttemptsSince(fromMs: Long): Flow<List<ChallengeAttemptEntity>>
}
