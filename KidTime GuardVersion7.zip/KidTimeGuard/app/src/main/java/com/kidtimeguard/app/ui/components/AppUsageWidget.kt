package com.kidtimeguard.app.ui.components

import android.graphics.drawable.Drawable
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.hilt.navigation.compose.hiltViewModel
import com.kidtimeguard.app.ui.parent.AppUsageItem
import com.kidtimeguard.app.ui.parent.AppManagementViewModel
import com.kidtimeguard.app.ui.parent.ParentDashboardViewModel
import com.kidtimeguard.app.ui.theme.*

// ── Icon loader ───────────────────────────────────────────────────
@Composable
private fun rememberAppIcon(packageName: String?): ImageBitmap? {
    val context = LocalContext.current
    return remember(packageName) {
        if (packageName.isNullOrBlank()) return@remember null
        try {
            val d: Drawable = context.packageManager.getApplicationIcon(packageName)
            d.toBitmap(96, 96).asImageBitmap()
        } catch (_: Exception) { null }
    }
}

// ─────────────────────────────────────────────────────────────────
// ADD APPS WIDGET — Full in-app component
//
// Displays ALL monitored apps with:
//   • Real app icon
//   • App name
//   • Remaining time (live, auto-updates)
//   • Animated progress bar (green → amber → red)
//   • "Time exceeded" warning badge
//   • Edit limit dialog
//   • Remove app option
//   • Sort by remaining time (ascending — most at-risk first)
//
// Usage: drop this composable anywhere in your UI tree.
// It self-manages its own VM via hiltViewModel().
// ─────────────────────────────────────────────────────────────────
@Composable
fun AddAppsWidget(
    dashboardViewModel  : ParentDashboardViewModel  = hiltViewModel(),
    managementViewModel : AppManagementViewModel    = hiltViewModel(),
    onAddNewApp         : () -> Unit                               // navigate to app selection
) {
    val dashState by dashboardViewModel.uiState.collectAsState()
    val mgmtState by managementViewModel.uiState.collectAsState()

    // ✅ Sort by remaining time ascending (most at-risk app appears first)
    val sortedItems = remember(dashState.appUsageItems) {
        dashState.appUsageItems.sortedBy { item ->
            val remaining = item.limitMinutes - item.usageMinutes
            remaining
        }
    }

    // State for edit dialog
    var editingApp by remember { mutableStateOf<AppUsageItem?>(null) }

    Column(modifier = Modifier.fillMaxWidth()) {

        // ── Header ──────────────────────────────────────────────
        Row(
            modifier          = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Apps, null,
                tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(8.dp))
            Text("Monitored Apps",
                style      = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier   = Modifier.weight(1f))
            // Live indicator
            LiveDot()
            Spacer(Modifier.width(8.dp))
            // Add new app button
            FilledTonalButton(
                onClick      = onAddNewApp,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Icon(Icons.Filled.Add, null, Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Add App", style = MaterialTheme.typography.labelMedium)
            }
        }

        // ── Summary chips ────────────────────────────────────────
        if (!dashState.isLoading) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(bottom = 8.dp)) {
                SummaryChip("${dashState.todayTotalUsageMinutes}m", "used today",
                    MaterialTheme.colorScheme.primary)
                SummaryChip("${dashState.activeAppsCount}", "apps",
                    MaterialTheme.colorScheme.secondary)
  //              if (dashState.lockedAppsCount > 0) {
   //                 SummaryChip("${dashState.lockedAppsCount}", "locked", LimitReachedRed)
       //         }
            }
        }

        // ── App list ─────────────────────────────────────────────
        if (dashState.isLoading) {
            Box(Modifier.fillMaxWidth().height(120.dp), Alignment.Center) {
                CircularProgressIndicator(Modifier.size(36.dp))
            }
        } else if (sortedItems.isEmpty()) {
            EmptyAppsState(onAddNewApp = onAddNewApp)
        } else {
            // ✅ LazyColumn inside a Column: use fixed height or weight
            // Caller must ensure this is inside a scrollable parent OR
            // use a fixed height modifier. For flexibility we list all items.
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                sortedItems.forEach { app ->
                    MonitoredAppCard(
                        app      = app,
                        onEdit   = { editingApp = app },
                        onRemove = { managementViewModel.toggleApp(app.packageName, false) }
                    )
                }
            }
        }
    }

    // ── Edit limit dialog ────────────────────────────────────────
    editingApp?.let { app ->
        EditTimeLimitDialog(
            appName         = app.appName,
            currentWeekday  = app.limitMinutes,   // weekday used as current
            currentWeekend  = app.limitMinutes + 30,
            onDismiss       = { editingApp = null },
            onConfirm       = { weekday, weekend ->
                managementViewModel.updateLimits(app.packageName, weekday, weekend)
                editingApp = null
            }
        )
    }
}

// ─────────────────────────────────────────────────────────────────
// Individual monitored app card
// ─────────────────────────────────────────────────────────────────
@Composable
private fun MonitoredAppCard(
    app     : AppUsageItem,
    onEdit  : () -> Unit,
    onRemove: () -> Unit
) {
    val icon            = rememberAppIcon(app.packageName)
    val remaining       = (app.limitMinutes - app.usageMinutes).coerceAtLeast(0)
    val fraction        = if (app.limitMinutes > 0)
        (app.usageMinutes.toFloat() / app.limitMinutes.toFloat()).coerceIn(0f, 1f)
    else 1f
    val exceeded        = app.usageMinutes >= app.limitMinutes

    // Smooth animation on live updates
    val animFraction by animateFloatAsState(
        targetValue   = fraction,
        animationSpec = tween(700, easing = FastOutSlowInEasing),
        label         = "prog_${app.packageName}"
    )

    val barColor = when {
        fraction >= 1f    -> LimitReachedRed
        fraction >= 0.75f -> WarningAmber
        else              -> SuccessGreen
    }

    val statusText = when {
        exceeded          -> "Time exceeded!"
        fraction >= 0.75f -> "${remaining}m left — almost done"
        else              -> "${remaining}m remaining"
    }

    var showRemoveConfirm by remember { mutableStateOf(false) }

    Card(
        modifier  = Modifier.fillMaxWidth(),
        shape     = RoundedCornerShape(14.dp),
        colors    = CardDefaults.cardColors(
            containerColor = if (exceeded)
                LimitReachedRed.copy(alpha = 0.06f)
            else
                MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // App icon
                Box(
                    Modifier.size(46.dp).clip(RoundedCornerShape(11.dp))
                        .background(
                            if (exceeded) LimitReachedRed.copy(0.12f)
                            else MaterialTheme.colorScheme.primaryContainer
                        ),
                    Alignment.Center
                ) {
                    if (icon != null) {
                        Image(icon, app.appName,
                            Modifier.size(46.dp).clip(RoundedCornerShape(11.dp)))
                    } else {
                        Icon(
                            imageVector = if (exceeded) Icons.Filled.Lock else Icons.Filled.Android,
                            contentDescription = null,
                            tint     = if (exceeded) LimitReachedRed
                            else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Spacer(Modifier.width(12.dp))

                // Name + usage text
                Column(Modifier.weight(1f)) {
                    Text(app.appName,
                        style      = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                        maxLines   = 1)
                    Text("${app.usageMinutes}m used / ${app.limitMinutes}m limit",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(0.5f))
                }

                // Action buttons
                IconButton(onClick = onEdit, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Filled.Edit, "Edit limit",
                        tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = { showRemoveConfirm = true }, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Filled.RemoveCircleOutline, "Remove",
                        tint = MaterialTheme.colorScheme.error.copy(0.7f), modifier = Modifier.size(18.dp))
                }
            }

            Spacer(Modifier.height(10.dp))

            // Animated progress bar
            LinearProgressIndicator(
                progress   = { animFraction },
                modifier   = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                color      = barColor,
                trackColor = barColor.copy(alpha = 0.15f)
            )

            Spacer(Modifier.height(5.dp))

            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                // Status text
                Text(statusText,
                    style = MaterialTheme.typography.labelSmall,
                    color = barColor,
                    fontWeight = if (exceeded) FontWeight.Bold else FontWeight.Normal)

                // Time exceeded badge
                AnimatedVisibility(visible = exceeded, enter = fadeIn(), exit = fadeOut()) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = LimitReachedRed.copy(alpha = 0.12f)
                    ) {
                        Row(
                            Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Lock, null,
                                tint = LimitReachedRed, modifier = Modifier.size(12.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Locked",
                                style = MaterialTheme.typography.labelSmall,
                                color = LimitReachedRed, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Remove confirmation dialog
    if (showRemoveConfirm) {
        AlertDialog(
            onDismissRequest = { showRemoveConfirm = false },
            icon             = { Icon(Icons.Filled.RemoveCircle, null, tint = MaterialTheme.colorScheme.error) },
            title            = { Text("Stop Monitoring?") },
            text             = { Text("${app.appName} will no longer be monitored. You can re-add it anytime.") },
            confirmButton    = {
                TextButton(onClick = { onRemove(); showRemoveConfirm = false }) {
                    Text("Remove", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton    = {
                TextButton(onClick = { showRemoveConfirm = false }) { Text("Cancel") }
            }
        )
    }
}

// ─────────────────────────────────────────────────────────────────
// Edit time limit dialog
// ─────────────────────────────────────────────────────────────────
@Composable
private fun EditTimeLimitDialog(
    appName        : String,
    currentWeekday : Int,
    currentWeekend : Int,
    onDismiss      : () -> Unit,
    onConfirm      : (weekday: Int, weekend: Int) -> Unit
) {
    var weekday by remember { mutableIntStateOf(currentWeekday) }
    var weekend by remember { mutableIntStateOf(currentWeekend) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Timer, null, tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("Edit: $appName", maxLines = 1)
            }
        },
        text = {
            Column {
                Text("Weekday limit: ${weekday}min",
                    style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                Slider(
                    value         = weekday.toFloat(),
                    onValueChange = { weekday = it.toInt() },
                    valueRange    = 5f..180f, steps = 34
                )
                Spacer(Modifier.height(8.dp))
                Text("Weekend limit: ${weekend}min",
                    style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                Slider(
                    value         = weekend.toFloat(),
                    onValueChange = { weekend = it.toInt() },
                    valueRange    = 5f..180f, steps = 34
                )
                Spacer(Modifier.height(8.dp))
                // Quick preset row
                Text("Quick presets:", style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(0.5f))
                Spacer(Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(15, 30, 60, 120).forEach { p ->
                        AssistChip(onClick = { weekday = p; weekend = p + 30 },
                            label = { Text("${p}m") })
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { onConfirm(weekday, weekend) }) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// ─────────────────────────────────────────────────────────────────
// AppUsageCard — reusable card (used in dashboard too)
// ─────────────────────────────────────────────────────────────────
@Composable
fun AppUsageCard(
    appName      : String,
    packageName  : String?       = null,
    usageMinutes : Int,
    limitMinutes : Int,
    isLocked     : Boolean       = false,
    onCardClick  : (() -> Unit)? = null,
    modifier     : Modifier      = Modifier
) {
    val icon     = rememberAppIcon(packageName)
    val fraction = if (limitMinutes > 0)
        (usageMinutes.toFloat() / limitMinutes.toFloat()).coerceIn(0f, 1f)
    else 0f

    val animFraction by animateFloatAsState(
        targetValue   = fraction,
        animationSpec = tween(700, easing = FastOutSlowInEasing),
        label         = "prog_$appName"
    )

    val progressColor = when {
        fraction >= 1f    -> LimitReachedRed
        fraction >= 0.75f -> WarningAmber
        else              -> SuccessGreen
    }

    val remaining   = (limitMinutes - usageMinutes).coerceAtLeast(0)
    val statusLabel = when {
        isLocked          -> "Locked"
        fraction >= 1f    -> "Time exceeded!"
        fraction >= 0.75f -> "${remaining}m left — almost done"
        else              -> "${remaining}m remaining"
    }

    Card(
        onClick   = onCardClick ?: {},
        enabled   = onCardClick != null,
        modifier  = modifier.fillMaxWidth(),
        shape     = RoundedCornerShape(16.dp),
        colors    = CardDefaults.cardColors(
            containerColor = if (isLocked || fraction >= 1f)
                LimitReachedRed.copy(alpha = 0.05f)
            else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(
                    if (isLocked) LimitReachedRed.copy(0.12f)
                    else MaterialTheme.colorScheme.primaryContainer
                ), Alignment.Center
            ) {
                if (icon != null) {
                    Image(icon, appName, Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)))
                } else {
                    Icon(
                        if (isLocked) Icons.Filled.Lock else Icons.Filled.Android, null,
                        tint = if (isLocked) LimitReachedRed else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                    Text(appName, style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold, maxLines = 1, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(8.dp))
                    Text("${usageMinutes}m / ${limitMinutes}m",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(0.5f))
                }
                Spacer(Modifier.height(7.dp))
                LinearProgressIndicator(
                    progress   = { animFraction },
                    modifier   = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(4.dp)),
                    color      = progressColor,
                    trackColor = progressColor.copy(alpha = 0.15f)
                )
                Spacer(Modifier.height(4.dp))
                Text(statusLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = progressColor,
                    fontWeight = if (fraction >= 1f) FontWeight.Bold else FontWeight.Normal)
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────
// Supporting composables
// ─────────────────────────────────────────────────────────────────

@Composable
fun StatsChipRow(
    totalMinutes  : Int,
    appsMonitored : Int,
    lockedCount   : Int,
    modifier      : Modifier = Modifier
) {
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SummaryChip("${totalMinutes}m", "today", MaterialTheme.colorScheme.primary)
        SummaryChip("$appsMonitored", "apps", MaterialTheme.colorScheme.secondary)
        if (lockedCount > 0) SummaryChip("$lockedCount", "locked", LimitReachedRed)
    }
}

@Composable
private fun SummaryChip(label: String, sub: String, color: Color) {
    Surface(shape = RoundedCornerShape(50), color = color.copy(alpha = 0.1f)) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold, color = color)
            Text(sub, style = MaterialTheme.typography.labelSmall, color = color.copy(0.7f))
        }
    }
}

@Composable
fun EmptyStateCard(
    icon    : androidx.compose.ui.graphics.vector.ImageVector = Icons.Filled.AddCircleOutline,
    title   : String,
    message : String,
    action  : String?        = null,
    onAction: (() -> Unit)?  = null,
    modifier: Modifier       = Modifier
) {
    Card(modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, Modifier.size(52.dp), tint = MaterialTheme.colorScheme.primary.copy(0.5f))
            Spacer(Modifier.height(16.dp))
            Text(title, style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(6.dp))
            Text(message, style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(0.6f), textAlign = TextAlign.Center)
            if (action != null && onAction != null) {
                Spacer(Modifier.height(20.dp))
                Button(onClick = onAction) { Text(action) }
            }
        }
    }
}

@Composable
fun SectionHeader(
    title    : String,
    action   : String?       = null,
    onAction : (() -> Unit)? = null
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        if (action != null && onAction != null) {
            TextButton(onClick = onAction) { Text(action) }
        }
    }
}

// ── Pulsing live dot ──────────────────────────────────────────────
@Composable
private fun LiveDot() {
    val inf = rememberInfiniteTransition(label = "live")
    val alpha by inf.animateFloat(
        initialValue  = 0.3f, targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse
        ), label = "alpha"
    )
    Box(
        Modifier.size(8.dp).clip(RoundedCornerShape(50))
            .background(SuccessGreen.copy(alpha = alpha))
    )
}

// ── Empty state when no apps monitored ────────────────────────────
@Composable
private fun EmptyAppsState(onAddNewApp: () -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(0.5f)
        )
    ) {
        Column(Modifier.padding(32.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Filled.AppRegistration, null, Modifier.size(52.dp),
                tint = MaterialTheme.colorScheme.primary.copy(0.4f))
            Spacer(Modifier.height(12.dp))
            Text("No apps monitored yet",
                style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center)
            Spacer(Modifier.height(6.dp))
            Text("Tap the button above to add apps and set daily time limits.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(0.5f),
                textAlign = TextAlign.Center)
            Spacer(Modifier.height(20.dp))
            Button(onClick = onAddNewApp) {
                Icon(Icons.Filled.Add, null, Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Add Your First App")
            }
        }
    }
}