package com.kidtimeguard.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.RoomDatabase.JournalMode
import androidx.sqlite.db.SupportSQLiteDatabase
import com.kidtimeguard.app.data.local.dao.*
import com.kidtimeguard.app.data.local.entity.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray

@Database(
    entities = [
        ChildProfileEntity::class,
        MonitoredAppEntity::class,
        UsageRecordEntity::class,
        AppLockEventEntity::class,
        ChallengeAttemptEntity::class,
        ChallengeEntity::class,
        ParentOverrideEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class KidTimeGuardDatabase : RoomDatabase() {

    abstract fun childProfileDao(): ChildProfileDao
    abstract fun monitoredAppDao(): MonitoredAppDao
    abstract fun usageRecordDao(): UsageRecordDao
    abstract fun appLockEventDao(): AppLockEventDao
    abstract fun challengeAttemptDao(): ChallengeAttemptDao
    abstract fun challengeDao(): ChallengeDao
    abstract fun parentOverrideDao(): ParentOverrideDao

    companion object {
        private const val DATABASE_NAME = "kidtimeguard.db"

        @Volatile
        private var INSTANCE: KidTimeGuardDatabase? = null

        fun getInstance(context: Context): KidTimeGuardDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildDatabase(context).also { INSTANCE = it }
            }
        }

        private fun buildDatabase(context: Context): KidTimeGuardDatabase {
            return Room.databaseBuilder(
                context.applicationContext,
                KidTimeGuardDatabase::class.java,
                DATABASE_NAME
            )
                .setJournalMode(JournalMode.WRITE_AHEAD_LOGGING)
                .fallbackToDestructiveMigration()
                .addCallback(SeedCallback())
                // Future migrations registered here:
                // .addMigrations(MIGRATION_1_2)
                .build()
        }
    }

    /**
     * Seeds the challenge table on first database creation.
     * Runs on a background coroutine — safe to add 500+ rows.
     */
    private class SeedCallback : Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                CoroutineScope(Dispatchers.IO).launch {
                    seedChallenges(database.challengeDao())
                }
            }
        }

        private suspend fun seedChallenges(dao: ChallengeDao) {
            if (dao.count() > 0) return // already seeded

            val challenges = buildList {
                // ── MATH: Age 6-9 (Easy) ──────────────────────────────────────
                add(challenge("MATH","What is 7 + 5?",opts("10","12","13","11"),1,"7+5=12",6,9))
                add(challenge("MATH","What is 9 + 6?",opts("14","15","16","13"),1,"9+6=15",6,9))
                add(challenge("MATH","What is 8 - 3?",opts("4","5","6","7"),1,"8-3=5",6,9))
                add(challenge("MATH","What is 4 × 2?",opts("6","8","10","7"),1,"4×2=8",6,9))
                add(challenge("MATH","What is 15 - 7?",opts("8","9","7","6"),0,"15-7=8",6,9))
                add(challenge("MATH","What is 6 + 9?",opts("13","15","14","16"),1,"6+9=15",6,9))
                add(challenge("MATH","What is 3 × 3?",opts("6","8","9","12"),2,"3×3=9",6,9))
                add(challenge("MATH","What is 20 ÷ 4?",opts("4","5","6","3"),1,"20÷4=5",6,9))
                add(challenge("MATH","What is 5 + 7?",opts("11","12","13","10"),1,"5+7=12",6,9))
                add(challenge("MATH","What is 10 - 4?",opts("5","6","7","8"),1,"10-4=6",6,9))
                add(challenge("MATH","What is 2 × 6?",opts("10","11","12","13"),2,"2×6=12",6,9))
                add(challenge("MATH","What is 18 ÷ 3?",opts("4","5","6","7"),2,"18÷3=6",6,9))
                add(challenge("MATH","What is 11 + 8?",opts("17","18","19","20"),2,"11+8=19",6,9))
                add(challenge("MATH","What is 14 - 6?",opts("6","7","8","9"),2,"14-6=8",6,9))
                add(challenge("MATH","What is 5 × 4?",opts("16","18","20","22"),2,"5×4=20",6,9))
                add(challenge("MATH","What is 24 ÷ 6?",opts("3","4","5","6"),1,"24÷6=4",6,9))
                add(challenge("MATH","How many sides does a triangle have?",opts("2","3","4","5"),1,"A triangle has 3 sides.",6,9))
                add(challenge("MATH","What is 7 × 7?",opts("42","47","49","51"),2,"7×7=49",6,9))
                add(challenge("MATH","What is 100 - 37?",opts("53","63","67","73"),1,"100-37=63",6,9))
                add(challenge("MATH","What is half of 16?",opts("6","7","8","9"),2,"16÷2=8",6,9))

                // ── MATH: Age 10-13 (Medium) ─────────────────────────────────
                add(challenge("MATH","What is 47 + 38?",opts("75","85","95","65"),1,"47+38=85",10,13))
                add(challenge("MATH","What is 12 × 8?",opts("86","96","98","94"),1,"12×8=96",10,13))
                add(challenge("MATH","What is 144 ÷ 12?",opts("10","11","12","13"),2,"144÷12=12",10,13))
                add(challenge("MATH","What is 25% of 80?",opts("15","20","25","30"),1,"25% of 80=20",10,13))
                add(challenge("MATH","What is 63 - 28?",opts("33","35","37","39"),1,"63-28=35",10,13))
                add(challenge("MATH","What is 7 × 9?",opts("54","56","62","63"),3,"7×9=63",10,13))
                add(challenge("MATH","What is 15% of 60?",opts("6","7","8","9"),3,"15% of 60=9",10,13))
                add(challenge("MATH","What is 11 × 11?",opts("111","121","131","141"),1,"11×11=121",10,13))
                add(challenge("MATH","What is 50% of 130?",opts("55","60","65","70"),2,"50% of 130=65",10,13))
                add(challenge("MATH","What is 256 ÷ 8?",opts("28","30","32","34"),2,"256÷8=32",10,13))
                add(challenge("MATH","What is the area of a rectangle 6m × 9m?",opts("42","48","54","60"),2,"Area=6×9=54 sq m",10,13))
                add(challenge("MATH","What is 3/4 of 100?",opts("60","70","75","80"),2,"3/4×100=75",10,13))
                add(challenge("MATH","What is 13 × 7?",opts("81","89","91","97"),2,"13×7=91",10,13))
                add(challenge("MATH","If x = 5, what is 3x + 2?",opts("13","15","17","19"),2,"3×5+2=17",10,13))
                add(challenge("MATH","What is 10% of 350?",opts("30","35","40","45"),1,"10% of 350=35",10,13))
                add(challenge("MATH","What is 200 - 67?",opts("123","133","143","153"),1,"200-67=133",10,13))
                add(challenge("MATH","What is the perimeter of a square with side 8?",opts("24","28","32","36"),2,"4×8=32",10,13))
                add(challenge("MATH","What is 18 × 5?",opts("80","85","90","95"),2,"18×5=90",10,13))
                add(challenge("MATH","What is 1000 ÷ 25?",opts("35","40","45","50"),1,"1000÷25=40",10,13))
                add(challenge("MATH","What is 5² + 4²?",opts("37","39","41","43"),2,"25+16=41",10,13))

                // ── MATH: Age 14-16 (Hard) ───────────────────────────────────
                add(challenge("MATH","What is 3/4 + 1/2?",opts("1","1.25","5/4","Both B&C"),3,"3/4+1/2=5/4=1.25",14,16))
                add(challenge("MATH","Solve: 2x + 6 = 14. What is x?",opts("3","4","5","6"),1,"2x=8, x=4",14,16))
                add(challenge("MATH","What is 15% of 240?",opts("30","36","40","48"),1,"240×0.15=36",14,16))
                add(challenge("MATH","What is √169?",opts("11","12","13","14"),2,"13×13=169",14,16))
                add(challenge("MATH","What is 2³ + 3²?",opts("13","17","18","19"),1,"2³=8, 3²=9, 8+9=17",14,16))
                add(challenge("MATH","Solve: 5x - 3 = 22. What is x?",opts("4","5","6","7"),1,"5x=25, x=5",14,16))
                add(challenge("MATH","What is the area of a circle with radius 7? (π≈3.14)",opts("143.08","153.86","163.94","173.02"),1,"π×7²=3.14×49=153.86",14,16))
                add(challenge("MATH","What is 2/3 × 3/4?",opts("1/2","2/3","3/4","1"),0,"2/3×3/4=6/12=1/2",14,16))
                add(challenge("MATH","If y = 3x - 1 and x = 4, what is y?",opts("9","10","11","12"),2,"3×4-1=11",14,16))
                add(challenge("MATH","What is 30% of 450?",opts("120","125","130","135"),3,"450×0.30=135",14,16))
                add(challenge("MATH","Simplify: 4x + 2x - 3x",opts("2x","3x","4x","5x"),1,"(4+2-3)x=3x",14,16))
                add(challenge("MATH","What is the LCM of 4 and 6?",opts("8","10","12","14"),2,"LCM(4,6)=12",14,16))
                add(challenge("MATH","What is √(16 × 9)?",opts("10","11","12","13"),2,"√144=12",14,16))
                add(challenge("MATH","What is 7/8 - 1/4?",opts("1/2","5/8","3/4","7/8"),1,"7/8-2/8=5/8",14,16))
                add(challenge("MATH","A train travels 360 km in 4 hours. What is its speed?",opts("80","85","90","95"),2,"360÷4=90 km/h",14,16))

                // ── LOGIC: Age 6-9 ───────────────────────────────────────────
                add(challenge("LOGIC","What comes next: 2, 4, 6, 8, ___?",opts("9","10","11","12"),1,"Even numbers increase by 2.",6,9))
                add(challenge("LOGIC","Which is the odd one out: Cat, Dog, Rose, Bird?",opts("Cat","Dog","Rose","Bird"),2,"Rose is a plant; the others are animals.",6,9))
                add(challenge("LOGIC","If you have 3 apples and get 2 more, how many do you have?",opts("4","5","6","7"),1,"3+2=5",6,9))
                add(challenge("LOGIC","What comes next: 1, 2, 4, 8, ___?",opts("10","14","16","20"),2,"Each number doubles.",6,9))
                add(challenge("LOGIC","A is taller than B. B is taller than C. Who is tallest?",opts("A","B","C","Cannot tell"),0,"A is taller than B who is taller than C.",6,9))

                // ── LOGIC: Age 10-16 ─────────────────────────────────────────
                add(challenge("LOGIC","If all cats are animals and all animals need food, do cats need food?",opts("Yes","No","Maybe","Only some"),0,"Yes — logical syllogism.",6,16))
                add(challenge("LOGIC","What comes next: 1, 3, 6, 10, 15, ___?",opts("18","20","21","22"),2,"Differences: +2,+3,+4,+5,+6. Next is 15+6=21",10,16))
                add(challenge("LOGIC","If today is Wednesday, what day was it 5 days ago?",opts("Friday","Saturday","Sunday","Monday"),0,"Wed→Tue→Mon→Sun→Sat→Fri",10,16))
                add(challenge("LOGIC","All squares are rectangles. Is every rectangle a square?",opts("Yes","No","Sometimes","Always"),1,"Rectangles don't need equal sides — so not all are squares.",10,16))
                add(challenge("LOGIC","What comes next: 3, 9, 27, 81, ___?",opts("162","216","243","256"),2,"Each number multiplies by 3: 81×3=243",10,16))
                add(challenge("LOGIC","If A > B and B = C, which is true?",opts("A < C","A = C","A > C","Cannot tell"),2,"A > B = C, so A > C",10,16))
                add(challenge("LOGIC","Find the pattern: 2, 5, 10, 17, 26, ___?",opts("35","37","37","39"),1,"Differences: +3,+5,+7,+9,+11. 26+11=37",10,16))
                add(challenge("LOGIC","If APPLE = 1-16-16-12-5, what does B equal?",opts("1","2","3","4"),1,"A=1, B=2 in alphabetical order.",10,16))
                add(challenge("LOGIC","How many months have 28 days?",opts("1","2","4","12"),3,"All 12 months have at least 28 days.",10,16))
                add(challenge("LOGIC","Which number doesn't belong: 3, 5, 7, 9, 11?",opts("3","5","9","11"),2,"9 = 3² is not prime; the rest are prime numbers.",10,16))

                // ── TRIVIA: Age 6-9 ──────────────────────────────────────────
                add(challenge("TRIVIA","How many sides does a hexagon have?",opts("5","6","7","8"),1,"Hex=6 in Latin/Greek.",6,9))
                add(challenge("TRIVIA","What colour is the sun?",opts("Red","Orange","Yellow","White"),3,"The sun is actually white; it appears yellow from Earth.",6,9))
                add(challenge("TRIVIA","How many legs does a spider have?",opts("6","7","8","10"),2,"All spiders have 8 legs.",6,9))
                add(challenge("TRIVIA","What do bees make?",opts("Milk","Honey","Wax only","Jam"),1,"Bees produce honey from flower nectar.",6,9))
                add(challenge("TRIVIA","Which animal is the largest?",opts("Elephant","Blue Whale","Giraffe","Hippopotamus"),1,"The blue whale is the largest animal on Earth.",6,9))
                add(challenge("TRIVIA","How many colours are in a rainbow?",opts("5","6","7","8"),2,"A rainbow has 7 colours: ROYGBIV.",6,9))
                add(challenge("TRIVIA","What is the capital of India?",opts("Mumbai","New Delhi","Chennai","Kolkata"),1,"New Delhi is the capital of India.",6,16))
                add(challenge("TRIVIA","How many continents are on Earth?",opts("5","6","7","8"),2,"Earth has 7 continents.",6,16))
                add(challenge("TRIVIA","What is the largest planet?",opts("Saturn","Earth","Jupiter","Neptune"),2,"Jupiter is the largest planet.",6,16))
                add(challenge("TRIVIA","What gas do plants absorb?",opts("Oxygen","Nitrogen","Carbon Dioxide","Hydrogen"),2,"Plants absorb CO₂ for photosynthesis.",6,16))

                // ── TRIVIA: Age 10-16 ─────────────────────────────────────────
                add(challenge("TRIVIA","Which is the longest river in the world?",opts("Amazon","Congo","Mississippi","Nile"),3,"The Nile is ~6,650 km long.",10,16))
                add(challenge("TRIVIA","What is the chemical symbol for water?",opts("WO","H₂O","HO₂","W"),1,"Water is H₂O.",10,16))
                add(challenge("TRIVIA","Who wrote Romeo and Juliet?",opts("Dickens","Shakespeare","Tolstoy","Chaucer"),1,"William Shakespeare.",10,16))
                add(challenge("TRIVIA","What is the speed of light (approx)?",opts("100 km/s","300,000 km/s","150,000 km/s","1 million km/s"),1,"~300,000 km per second.",14,16))
                add(challenge("TRIVIA","What is the hardest natural substance?",opts("Iron","Gold","Diamond","Quartz"),2,"Diamond scores 10 on the Mohs scale.",10,16))
                add(challenge("TRIVIA","How many bones are in the adult human body?",opts("186","196","206","216"),2,"Adults have 206 bones.",10,16))
                add(challenge("TRIVIA","What is the powerhouse of the cell?",opts("Nucleus","Ribosome","Mitochondria","Golgi body"),2,"Mitochondria produce ATP energy.",10,16))
                add(challenge("TRIVIA","Which planet is known as the Red Planet?",opts("Venus","Mars","Mercury","Saturn"),1,"Mars appears red due to iron oxide.",6,16))
                add(challenge("TRIVIA","What is the chemical symbol for gold?",opts("Go","Gd","Au","Ag"),2,"Au comes from the Latin 'Aurum'.",10,16))
                add(challenge("TRIVIA","Who invented the telephone?",opts("Edison","Tesla","Bell","Marconi"),2,"Alexander Graham Bell in 1876.",10,16))
                add(challenge("TRIVIA","What is the largest ocean?",opts("Atlantic","Indian","Arctic","Pacific"),3,"The Pacific covers ~165 million km².",6,16))
                add(challenge("TRIVIA","How many players are in a cricket team?",opts("9","10","11","12"),2,"A cricket team has 11 players.",6,16))
                add(challenge("TRIVIA","What currency does Japan use?",opts("Yuan","Won","Yen","Ringgit"),2,"Japan uses the Yen.",10,16))
                add(challenge("TRIVIA","In which year did India gain independence?",opts("1945","1946","1947","1948"),2,"India gained independence on 15 August 1947.",10,16))
                add(challenge("TRIVIA","What is the smallest country in the world?",opts("Monaco","San Marino","Vatican City","Liechtenstein"),2,"Vatican City covers ~0.44 km².",10,16))
                add(challenge("TRIVIA","How many strings does a standard guitar have?",opts("4","5","6","7"),2,"A standard guitar has 6 strings.",6,16))
                add(challenge("TRIVIA","What is the national animal of India?",opts("Lion","Elephant","Tiger","Leopard"),2,"The Bengal Tiger is India's national animal.",6,16))
                add(challenge("TRIVIA","What gas makes up most of Earth's atmosphere?",opts("Oxygen","Carbon Dioxide","Nitrogen","Argon"),2,"Nitrogen makes up ~78% of the atmosphere.",10,16))
                add(challenge("TRIVIA","How many days are in a leap year?",opts("364","365","366","367"),2,"Leap years have 366 days.",6,16))
                add(challenge("TRIVIA","What does CPU stand for?",opts("Central Process Unit","Central Processing Unit","Computer Processing Unit","Core Processing Unit"),1,"CPU = Central Processing Unit.",10,16))

                // ── WORD: Age 6-9 ────────────────────────────────────────────
                add(challenge("WORD","Which word is a synonym for 'happy'?",opts("Sad","Angry","Joyful","Tired"),2,"Joyful and happy both mean pleasure.",6,16))
                add(challenge("WORD","What is the plural of 'child'?",opts("Childs","Childes","Children","Childrens"),2,"Irregular plural: children.",6,9))
                add(challenge("WORD","Which word is an antonym for 'ancient'?",opts("Old","Modern","Wise","Huge"),1,"Ancient=very old; modern=new.",6,16))
                add(challenge("WORD","What is the opposite of 'hot'?",opts("Warm","Cool","Cold","Icy"),2,"Cold is the direct antonym of hot.",6,9))
                add(challenge("WORD","Which word means 'very big'?",opts("Tiny","Small","Huge","Medium"),2,"Huge means very large.",6,9))
                add(challenge("WORD","What is the plural of 'mouse'?",opts("Mouses","Mices","Mice","Mouse"),2,"Irregular plural: mice.",6,9))
                add(challenge("WORD","Which word is a noun: run, blue, cat, quickly?",opts("Run","Blue","Cat","Quickly"),2,"Cat is a noun (a thing).",6,9))
                add(challenge("WORD","What does 'enormous' mean?",opts("Very small","Very fast","Very large","Very old"),2,"Enormous means extremely large.",6,9))

                // ── WORD: Age 10-16 ──────────────────────────────────────────
                add(challenge("WORD","Choose the correctly spelled word:",opts("Recieve","Receive","Receve","Recieeve"),1,"I before E except after C: Receive.",10,16))
                add(challenge("WORD","What does the prefix 'bi-' mean?",opts("One","Two","Three","Half"),1,"Bi- means two.",10,16))
                add(challenge("WORD","What does 'benevolent' mean?",opts("Cruel","Generous","Angry","Fearful"),1,"Benevolent means well-meaning and generous.",10,16))
                add(challenge("WORD","Which word is a synonym for 'abundant'?",opts("Scarce","Plentiful","Tiny","Weak"),1,"Abundant and plentiful both mean in large supply.",10,16))
                add(challenge("WORD","What does the suffix '-ology' mean?",opts("Fear of","Study of","Without","Before"),1,"-ology means the study of something.",10,16))
                add(challenge("WORD","What does 'ambiguous' mean?",opts("Very clear","Open to two meanings","Completely wrong","Very long"),1,"Ambiguous means having more than one possible meaning.",10,16))
                add(challenge("WORD","Which is the correct spelling?",opts("Accomodation","Accommodation","Acomodation","Accommodasion"),1,"Accommodation: double c, double m.",10,16))
                add(challenge("WORD","What does 'eloquent' mean?",opts("Silent","Clumsy","Well-spoken","Confused"),2,"Eloquent means fluent and persuasive in speaking.",10,16))
                add(challenge("WORD","What does the prefix 'mis-' mean?",opts("Good","Bad/Wrong","New","Again"),1,"Mis- means wrongly or badly.",10,16))
                add(challenge("WORD","What is the antonym of 'magnify'?",opts("Increase","Enlarge","Reduce","Expand"),2,"Magnify means to enlarge; reduce is the opposite.",10,16))
                add(challenge("WORD","Which word means to make something worse?",opts("Improve","Alleviate","Aggravate","Resolve"),2,"Aggravate means to make a problem worse.",10,16))
                add(challenge("WORD","What does 'nocturnal' mean?",opts("Active by day","Active at night","Very fast","Underground"),1,"Nocturnal animals are active at night.",10,16))

                // ── MEMORY: All ages ─────────────────────────────────────────
                add(challenge("MEMORY","Sequence: Red, Blue, Green, Red. What colour came 3rd?",opts("Red","Blue","Green","Yellow"),2,"Red(1), Blue(2), Green(3), Red(4).",6,16))
                add(challenge("MEMORY","In 'The quick brown fox', what was the second word?",opts("The","Quick","Brown","Fox"),1,"The(1), quick(2), brown(3), fox(4).",6,16))
                add(challenge("MEMORY","List: Apple, Mango, Orange, Banana. What was 2nd?",opts("Apple","Mango","Orange","Banana"),1,"Apple(1), Mango(2).",6,16))
                add(challenge("MEMORY","Sequence: 5, 3, 8, 1, 9. What was the middle number?",opts("3","8","1","9"),1,"5(1), 3(2), 8(3), 1(4), 9(5). Middle=8.",6,16))
                add(challenge("MEMORY","Colors: Yellow, Purple, Orange, Blue, Green. What was 4th?",opts("Orange","Purple","Blue","Green"),2,"Yellow(1), Purple(2), Orange(3), Blue(4), Green(5).",10,16))
                add(challenge("MEMORY","Words: Sun, Moon, Star, Cloud, Rain. What was last?",opts("Star","Cloud","Rain","Moon"),2,"Sun, Moon, Star, Cloud, Rain — last is Rain.",6,16))
                add(challenge("MEMORY","Numbers: 7, 14, 21, 28, 35. What was the 3rd number?",opts("14","21","28","35"),1,"7(1), 14(2), 21(3).",10,16))
                add(challenge("MEMORY","Animals: Lion, Tiger, Bear, Wolf. What was the 2nd animal?",opts("Lion","Tiger","Bear","Wolf"),1,"Lion(1), Tiger(2), Bear(3), Wolf(4).",6,16))
                // ── MEMORY: Extra questions ──────────────────────────────────
                add(challenge("MEMORY","Sequence: 10, 20, 30, 40, 50. What was the 4th number?",opts("30","40","50","60"),1,"10(1),20(2),30(3),40(4),50(5).",6,16))
                add(challenge("MEMORY","Days: Mon, Tue, Wed, Thu. What was the 2nd day?",opts("Mon","Tue","Wed","Thu"),1,"Mon(1), Tue(2).",6,16))
                add(challenge("MEMORY","Fruits: Mango, Apple, Grape, Banana, Orange. What was 3rd?",opts("Apple","Grape","Banana","Orange"),1,"Mango(1),Apple(2),Grape(3).",6,16))
                add(challenge("MEMORY","Numbers: 3, 7, 2, 8, 5. What was the first number?",opts("3","7","2","8"),0,"First number was 3.",6,16))
                add(challenge("MEMORY","Colors: Pink, Blue, Yellow, Green, Red. What was 2nd to last?",opts("Yellow","Green","Red","Blue"),1,"Pink,Blue,Yellow,Green(4th),Red(5th). 2nd to last=Green.",10,16))
                add(challenge("MEMORY","Shapes: Circle, Square, Triangle, Rectangle. What was 3rd?",opts("Circle","Square","Triangle","Rectangle"),2,"Circle(1),Square(2),Triangle(3).",6,16))
                add(challenge("MEMORY","Words: Sky, Cloud, Rain, Sun, Wind. What was the middle word?",opts("Cloud","Rain","Sun","Wind"),1,"Sky(1),Cloud(2),Rain(3),Sun(4),Wind(5). Middle=Rain.",10,16))
                add(challenge("MEMORY","Planets: Mars, Earth, Venus, Jupiter. What was the last?",opts("Mars","Earth","Venus","Jupiter"),3,"Mars(1),Earth(2),Venus(3),Jupiter(4).",10,16))
                add(challenge("MEMORY","Letters: A, E, I, O, U. What was the 4th letter?",opts("I","O","U","A"),1,"A(1),E(2),I(3),O(4),U(5).",6,16))
                add(challenge("MEMORY","Numbers: 15, 30, 45, 60, 75. What was the 2nd number?",opts("15","30","45","60"),1,"15(1),30(2).",6,16))
                add(challenge("MEMORY","Animals: Tiger, Lion, Bear, Wolf, Fox. What was 3rd?",opts("Lion","Bear","Wolf","Fox"),1,"Tiger(1),Lion(2),Bear(3).",6,16))
                add(challenge("MEMORY","Sentence: 'She sells sea shells.' What was the 3rd word?",opts("She","sells","sea","shells"),2,"She(1),sells(2),sea(3).",10,16))
                add(challenge("MEMORY","Numbers: 100, 200, 300, 400. What was the 3rd?",opts("200","300","400","100"),1,"100(1),200(2),300(3).",6,16))
                add(challenge("MEMORY","Colors: Red, Orange, Yellow, Green, Blue, Indigo, Violet. What was 5th?",opts("Green","Blue","Indigo","Yellow"),1,"ROYGBIV — Blue is 5th.",10,16))
                add(challenge("MEMORY","Months: Jan, Feb, Mar, Apr, May. What was the 4th?",opts("Mar","Apr","May","Feb"),1,"Jan(1),Feb(2),Mar(3),Apr(4).",10,16))
                add(challenge("MEMORY","Sentence: 'The cat sat on the mat.' What was the 4th word?",opts("cat","sat","on","the"),2,"The(1),cat(2),sat(3),on(4).",10,16))
                add(challenge("MEMORY","Scores: 10, 25, 15, 30, 20. Which was highest?",opts("25","15","30","20"),2,"30 is the highest score.",10,16))
                add(challenge("MEMORY","Sequence: A, B, D, G, K. What letter comes after G?",opts("H","I","J","K"),3,"Pattern skips increasing letters: +1,+2,+3,+4. G+4=K.",14,16))
                add(challenge("MEMORY","Numbers: 2, 4, 8, 16, 32. What was the 4th number?",opts("8","16","32","4"),1,"2(1),4(2),8(3),16(4).",10,16))
                add(challenge("MEMORY","Words: Book, Pen, Ruler, Eraser, Bag. What was 2nd?",opts("Book","Pen","Ruler","Eraser"),1,"Book(1),Pen(2).",6,16))
            }

            dao.insertAll(challenges)
        }

        private fun challenge(
            type: String,
            question: String,
            optionsJson: String,
            correctIndex: Int,
            explanation: String,
            minAge: Int,
            maxAge: Int,
            fastThresholdMs: Long = 10_000L
        ): ChallengeEntity = ChallengeEntity(
            type = type,
            question = question,
            optionsJson = optionsJson,
            correctIndex = correctIndex,
            explanation = explanation,
            minAge = minAge,
            maxAge = maxAge,
            fastThresholdMs = fastThresholdMs
        )

        private fun opts(vararg options: String): String =
            JSONArray(options.toList()).toString()
    }
}
