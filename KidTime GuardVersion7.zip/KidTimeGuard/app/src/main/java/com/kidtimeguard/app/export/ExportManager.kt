package com.kidtimeguard.app.export

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.util.Log
import androidx.core.content.FileProvider
import com.kidtimeguard.app.data.repository.AnalyticsRepository
import com.kidtimeguard.app.data.repository.ChildProfileRepository
import com.kidtimeguard.app.data.repository.MonitoredAppRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Generates professional, brand-aligned weekly usage reports in PDF format.
 * Features:
 * - Localized to Indian Standard Time (IST).
 * - Multi-category breakdown (Used, Earned, Parent) in Daily Summary.
 * - Branded styling using #AC1D58.
 * - Auto-scaling layout for app lists.
 */
@Singleton
class ExportManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val analyticsRepository: AnalyticsRepository,
    private val monitoredAppRepository: MonitoredAppRepository,
    private val childProfileRepository: ChildProfileRepository
) {
    private val indianZone = ZoneId.of("Asia/Kolkata")
    private val brandColor = 0xFFAC1D58.toInt()

    private val displayFormat = SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).apply {
        timeZone = TimeZone.getTimeZone(indianZone)
    }
    private val timestampFormat = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).apply {
        timeZone = TimeZone.getTimeZone(indianZone)
    }

    suspend fun exportPdf(): Uri? = withContext(Dispatchers.IO) {
        try {
            val today = LocalDate.now(indianZone)
            val weekStart = today.with(TemporalAdjusters.previousOrSame(java.time.DayOfWeek.MONDAY))
            val weekStartMs = weekStart.atStartOfDay(indianZone).toInstant().toEpochMilli()
            val weekStartEpoch = weekStart.toEpochDay()

            val apps = monitoredAppRepository.getAllApps().associateBy { it.packageName }
            val records = analyticsRepository.observeRecordsSince(weekStartEpoch).first()
            val stats = analyticsRepository.getChallengeStats(weekStartMs)
            val overrides = analyticsRepository.observeOverridesSince(weekStartMs).first()
            val profile = childProfileRepository.getProfile()

            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4
            var page = pdfDocument.startPage(pageInfo)
            var canvas = page.canvas
            val paint = Paint()

            var y = 60f
            val xOffset = 50f
            val pageWidth = 595f

            // ─── 1. BRANDED HEADER ───
            paint.color = brandColor
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textSize = 24f
            canvas.drawText("KidTime Guard", xOffset, y, paint)
            
            paint.color = Color.DKGRAY
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            paint.textSize = 10f
            canvas.drawText("Smart Parental Controls & Learning Insights", xOffset, y + 15f, paint)
            
            paint.color = brandColor
            paint.strokeWidth = 2f
            canvas.drawLine(xOffset, y + 25f, pageWidth - xOffset, y + 25f, paint)
            y += 60f

            // ─── 2. REPORT METADATA ───
            paint.color = Color.BLACK
            paint.textSize = 12f
            canvas.drawText("Weekly Report: ${displayFormat.format(Date(weekStartMs))} - ${displayFormat.format(Date())}", xOffset, y, paint)
            y += 20f
            canvas.drawText("Child Profile: ${profile?.name ?: "User"} (Level ${profile?.level ?: 1})", xOffset, y, paint)
            y += 40f

            // ─── 3. DAILY USAGE SUMMARY TABLE (With Split Details) ───
            drawSectionHeader(canvas, "DAILY USAGE SUMMARY (IST)", xOffset, y, paint)
            y += 25f
            
            // Table Header
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textSize = 10f
            canvas.drawText("Day", xOffset, y, paint)
            canvas.drawText("Used", 150f, y, paint)
            canvas.drawText("Earned", 230f, y, paint)
            canvas.drawText("Parent", 310f, y, paint)
            canvas.drawText("Total Active", 400f, y, paint)
            y += 10f
            paint.strokeWidth = 1f
            canvas.drawLine(xOffset, y, pageWidth - xOffset, y, paint)
            y += 20f

            val days = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")
            val dailyUsed = LongArray(7) { 0L }
            val dailyBonus = LongArray(7) { 0L }
            val dailyParent = LongArray(7) { 0L }

            records.forEach { r ->
                val idx = (r.dateEpoch - weekStartEpoch).toInt()
                if (idx in 0..6) {
                    dailyUsed[idx] += r.usageMs
                    dailyBonus[idx] += r.bonusMs
                }
            }
            overrides.forEach { o ->
                val oDate = Instant.ofEpochMilli(o.overriddenAt).atZone(indianZone).toLocalDate()
                val idx = (oDate.toEpochDay() - weekStartEpoch).toInt()
                if (idx in 0..6) dailyParent[idx] += (o.bonusMinutes * 60_000L)
            }

            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            for (i in 0..6) {
                val u = (dailyUsed[i] / 60_000).toInt()
                val p = (dailyParent[i] / 60_000).toInt()
                val e = ((dailyBonus[i] / 60_000).toInt() - p).coerceAtLeast(0)
                val t = u + e + p

                canvas.drawText(days[i], xOffset, y, paint)
                canvas.drawText("${u}m", 150f, y, paint)
                canvas.drawText("${e}m", 230f, y, paint)
                canvas.drawText("${p}m", 310f, y, paint)
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                canvas.drawText("${t}m", 400f, y, paint)
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                y += 18f
            }
            y += 35f

            // ─── 4. APP BREAKDOWN ───
            drawSectionHeader(canvas, "APP-WISE WEEKLY TOTALS", xOffset, y, paint)
            y += 25f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("App Name", xOffset, y, paint)
            canvas.drawText("Used", 220f, y, paint)
            canvas.drawText("Earned", 300f, y, paint)
            canvas.drawText("Parent", 380f, y, paint)
            canvas.drawText("Total", 470f, y, paint)
            y += 10f
            canvas.drawLine(xOffset, y, pageWidth - xOffset, y, paint)
            y += 20f

            val appData = records.groupBy { it.packageName }
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            appData.forEach { (pkg, recs) ->
                if (y > 780f) {
                    pdfDocument.finishPage(page)
                    page = pdfDocument.startPage(pageInfo)
                    canvas = page.canvas
                    y = 50f
                }

                val name = apps[pkg]?.appName ?: pkg.split(".").last()
                val u = (recs.sumOf { it.usageMs } / 60_000).toInt()
                val bMs = recs.sumOf { it.bonusMs }
                val p = overrides.filter { it.packageName == pkg }.sumOf { it.bonusMinutes }
                val e = ((bMs / 60_000).toInt() - p).coerceAtLeast(0)
                val t = u + e + p

                canvas.drawText(name.take(28), xOffset, y, paint)
                canvas.drawText("${u}m", 220f, y, paint)
                canvas.drawText("${e}m", 300f, y, paint)
                canvas.drawText("${p}m", 380f, y, paint)
                canvas.drawText("${t}m", 470f, y, paint)
                y += 18f
            }
            y += 40f

            // ─── 5. LEARNING PERFORMANCE ───
            if (y > 700f) {
                pdfDocument.finishPage(page)
                page = pdfDocument.startPage(pageInfo)
                canvas = page.canvas
                y = 50f
            }
            drawSectionHeader(canvas, "LEARNING PERFORMANCE", xOffset, y, paint)
            y += 25f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            canvas.drawText("Challenge Success Rate: ${if (stats.total > 0) (stats.correct * 100) / stats.total else 0}%", xOffset, y, paint)
            y += 18f
            canvas.drawText("Total Stars Earned: ${stats.totalStars}", xOffset, y, paint)
            y += 40f

            // ─── FOOTER ───
            paint.color = Color.GRAY
            paint.textSize = 8f
            canvas.drawText("Generated by KidTime Guard. All data is processed locally on-device.", xOffset, 810f, paint)

            pdfDocument.finishPage(page)
            val fileName = "KidTimeGuard_Full_Report_${SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())}.pdf"
            val file = File(context.cacheDir, fileName)
            pdfDocument.writeTo(FileOutputStream(file))
            pdfDocument.close()

            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        } catch (e: Exception) {
            Log.e("ExportManager", "PDF Error: ${e.message}", e)
            null
        }
    }

    private fun drawSectionHeader(canvas: Canvas, title: String, x: Float, y: Float, paint: Paint) {
        paint.color = brandColor
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 14f
        canvas.drawText(title, x, y, paint)
        paint.color = Color.BLACK
    }

    fun shareReport(uri: Uri): Intent {
        return Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "KidTime Guard — Weekly Analytics Report")
            putExtra(Intent.EXTRA_TEXT, "Professional weekly report generated by KidTime Guard.")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }
}
