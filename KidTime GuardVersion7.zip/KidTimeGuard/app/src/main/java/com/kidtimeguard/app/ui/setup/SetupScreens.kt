package com.kidtimeguard.app.ui.setup

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

// ──────────────────────────────────────────────────────────────────
// SetupScreens.kt — PIN, Child Profile screens only.
//
// App selection → SelectAppsScreen.kt
// Time limits   → SetTimeLimitsScreen.kt
//
// Both of those receive the viewModel as a parameter from MainActivity
// so they share the same SetupViewModel instance scoped to SETUP_GRAPH.
// ──────────────────────────────────────────────────────────────────

// ─────────────────────────────────────────────────────────────────
// 1. PIN Screen
// ─────────────────────────────────────────────────────────────────
@Composable
fun SetupPinScreen(
    viewModel   : SetupViewModel,
    onPinCreated: () -> Unit
) {
    var pin        by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var error      by remember { mutableStateOf<String?>(null) }

    SetupScaffold(1, 5, "Create Parent PIN",
        "This PIN protects your settings and allows manual time overrides.") {

        OutlinedTextField(
            value                = pin,
            onValueChange        = { if (it.length <= 6) pin = it },
            label                = { Text("PIN (4–6 digits)") },
            modifier             = Modifier.fillMaxWidth(),
            keyboardOptions      = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            visualTransformation = PasswordVisualTransformation(),
            singleLine           = true
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value                = confirmPin,
            onValueChange        = { if (it.length <= 6) confirmPin = it },
            label                = { Text("Confirm PIN") },
            modifier             = Modifier.fillMaxWidth(),
            keyboardOptions      = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            visualTransformation = PasswordVisualTransformation(),
            singleLine           = true,
            isError              = error != null,
            supportingText       = error?.let { msg -> { Text(msg) } }
        )
        Spacer(Modifier.height(24.dp))
        Button(
            onClick = {
                when {
                    pin.length < 4    -> error = "PIN must be at least 4 digits"
                    pin != confirmPin -> error = "PINs do not match"
                    else              -> { viewModel.setPin(pin); onPinCreated() }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            enabled  = pin.isNotEmpty() && confirmPin.isNotEmpty()
        ) { Text("Continue") }
    }
}

// ─────────────────────────────────────────────────────────────────
// 2. Child Profile Screen
// ─────────────────────────────────────────────────────────────────
@Composable
fun SetupChildProfileScreen(
    viewModel: SetupViewModel,
    onNext   : () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var age  by remember { mutableIntStateOf(10) }

    SetupScaffold(2, 5, "Child's Profile",
        "We'll use this to set age-appropriate challenge difficulty.") {

        OutlinedTextField(
            value         = name,
            onValueChange = { name = it },
            label         = { Text("Child's name") },
            modifier      = Modifier.fillMaxWidth(),
            singleLine    = true,
            leadingIcon   = { Icon(Icons.Filled.Person, null) }
        )
        Spacer(Modifier.height(24.dp))
        Text("Age: $age", style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(8.dp))
        Slider(value = age.toFloat(), onValueChange = { age = it.toInt() },
            valueRange = 6f..16f, steps = 9)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("6",  style = MaterialTheme.typography.labelSmall)
            Text("16", style = MaterialTheme.typography.labelSmall)
        }
        Spacer(Modifier.height(12.dp))
        Surface(shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.secondaryContainer) {
            Text(
                "Difficulty: " + when (age) {
                    in 6..9   -> "Easy — single-digit math, basic trivia"
                    in 10..13 -> "Medium — multi-digit, percentages"
                    else      -> "Hard — algebra, fractions, advanced"
                },
                modifier = Modifier.padding(12.dp),
                style    = MaterialTheme.typography.bodySmall,
                color    = MaterialTheme.colorScheme.onSecondaryContainer
            )
        }
        Spacer(Modifier.height(24.dp))
        Button(
            onClick  = { viewModel.saveChildProfile(name.trim(), age); onNext() },
            modifier = Modifier.fillMaxWidth(),
            enabled  = name.isNotBlank()
        ) { Text("Continue") }
    }
}

// ─────────────────────────────────────────────────────────────────
// Shared setup scaffold — progress bar + title + content
// ─────────────────────────────────────────────────────────────────
@Composable
fun SetupScaffold(
    step    : Int,
    total   : Int,
    title   : String,
    subtitle: String,
    content : @Composable ColumnScope.() -> Unit
) {
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        // Progress bar
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(total) { i ->
                Box(
                    Modifier.height(4.dp).weight(1f).background(
                        color = if (i < step) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f),
                        shape = RoundedCornerShape(2.dp)
                    )
                )
            }
        }
        Spacer(Modifier.height(32.dp))
        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(subtitle, style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onBackground.copy(0.6f))
        Spacer(Modifier.height(24.dp))
        content()
    }
}

// ── Legacy aliases so any existing call sites still compile ───────
// These delegate to the new dedicated screen files.
@Composable
fun SetupAppSelectionScreen(
    viewModel: SetupViewModel,
    onNext   : () -> Unit
) = SelectAppsScreen(viewModel = viewModel, onNext = onNext)

@Composable
fun SetupTimeLimitsScreen(
    viewModel      : SetupViewModel,
    onSetupComplete: () -> Unit
) = SetTimeLimitsScreen(viewModel = viewModel, onSetupComplete = onSetupComplete)