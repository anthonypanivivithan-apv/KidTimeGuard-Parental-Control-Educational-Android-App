package com.kidtimeguard.app.ui.parent

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import java.util.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.window.Dialog

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel = hiltViewModel(),
    onBack: () -> Unit
) {
    val uiState  by viewModel.uiState.collectAsState()
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    val context  = LocalContext.current
    var showChangePinDialog  by remember { mutableStateOf(false) }
    var showAboutDialog      by remember { mutableStateOf(false) }
    var showExportLoading    by remember { mutableStateOf(false) }
    var exportError          by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier            = Modifier.fillMaxSize().padding(padding),
            contentPadding      = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {

            // ── Appearance (Theme) ──
            item {
                SettingsSectionCard(title = "Appearance") {
                    SettingsListItem(
                        icon     = if (isDarkTheme) Icons.Filled.DarkMode else Icons.Filled.LightMode,
                        title    = "Dark Theme",
                        subtitle = "Switch between light and dark modes",
                        onClick  = { viewModel.toggleTheme(!isDarkTheme) },
                        trailing = {
                            Switch(
                                checked = isDarkTheme,
                                onCheckedChange = { viewModel.toggleTheme(it) }
                            )
                        }
                    )
                }
            }

            // ── Security ──
            item {
                SettingsSectionCard(title = "Security") {
                    SettingsListItem(
                        icon     = Icons.Filled.Lock,
                        title    = "Change Parent PIN",
                        subtitle = "Update your 4–6 digit PIN",
                        onClick  = { showChangePinDialog = true }
                    )
                }
            }

            // ── Reports ──
            item {
                SettingsSectionCard(title = "Reports") {
                    SettingsListItem(
                        icon     = Icons.Filled.FileDownload,
                        title = "Export Weekly Report",
                        subtitle = "Download PDF",
                        onClick  = {
                            showExportLoading = true
                            viewModel.exportReport(
                                onSuccess = { uri ->
                                    showExportLoading = false
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "application/pdf"
                                        putExtra(Intent.EXTRA_STREAM, uri)
                                        putExtra(Intent.EXTRA_SUBJECT, "KidTime Guard Weekly Report")
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(
                                        Intent.createChooser(shareIntent, "Share Report")
                                    )
                                },
                                onError = { err ->
                                    showExportLoading = false
                                    exportError = err
                                }
                            )
                        },
                        trailing = {
                            if (showExportLoading) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.Filled.ChevronRight, contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurface.copy(0.4f))
                            }
                        }
                    )
                }
            }

            // ── Monitoring ──
            item {
                SettingsSectionCard(title = "Monitoring") {
                    SettingsListItem(
                        icon     = Icons.Filled.RestartAlt,
                        title    = "Restart Monitoring Service",
                        subtitle = "Force-restart the background tracking service",
                        onClick  = { viewModel.restartService() }
                    )
                }
            }

            // ── About ──
            item {
                SettingsSectionCard(title = "About") {
                    SettingsListItem(
                        icon     = Icons.Filled.Info,
                        title    = "About KidTime Guard",
                        subtitle = "Why and how to use this app",
                        onClick  = { showAboutDialog = true }
                    )
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                    SettingsListItem(
                        icon     = Icons.Filled.PrivacyTip,
                        title    = "Privacy & Security",
                        subtitle = "Local data · No tracking · Secure",
                        onClick  = { showAboutDialog = true }
                    )
                }
            }

            // Export error snackbar placeholder
            if (exportError != null) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier          = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Error, null,
                                tint = MaterialTheme.colorScheme.error)
                            Spacer(Modifier.width(12.dp))
                            Text(exportError ?: "", style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.weight(1f))
                            TextButton(onClick = { exportError = null }) { Text("Dismiss") }
                        }
                    }
                }
            }
        }
    }

    // Change PIN dialog
    if (showChangePinDialog) {
        ChangePinDialog(
            error     = uiState.pinError,
            onSubmit  = { current, newPin ->
                viewModel.changePin(current, newPin)
                if (uiState.pinError == null) showChangePinDialog = false
            },
            onDismiss = { showChangePinDialog = false; viewModel.clearPinError() }
        )
    }

    // Detailed About App Dialog
    if (showAboutDialog) {
        AboutAppDialog(onDismiss = { showAboutDialog = false })
    }
}

@Composable
private fun AboutAppDialog(onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.fillMaxWidth().fillMaxHeight(0.85f)
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Text(
                    "About KidTime Guard",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    "Smart Parental Controls & Learning",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.secondary
                )
                Spacer(Modifier.height(24.dp))

                // 1. What is this app?
                AboutSection(
                    title = "What is KidTime Guard?",
                    content = "KidTime Guard is a professional parental control tool designed to turn mindless screen time into a productive learning experience. It monitors app usage and intelligently interrupts when limits are reached."
                )

                // 2. Why we built this?
                AboutSection(
                    title = "Why we built this?",
                    content = "We believe in discipline without friction. Instead of a hard 'No', KidTime Guard gives children a path to 'Earn' their entertainment through educational effort. It builds patience and value for digital time."
                )

                // 3. How to use?
                AboutSection(
                    title = "How to use (Quick Steps):",
                    content = "1. Permissions: Enable Accessibility & Usage Stats (Mandatory for tracking).\n" +
                              "2. Monitor: Go to the Dashboard and add the apps you want to track (YouTube, Instagram, Games, etc.).\n" +
                              "3. Limits: Set a daily time limit (Defaults to 30 mins every morning).\n" +
                              "4. Automatic Lock: Once the limit hits, the app will instantly block access.\n" +
                              "5. Earn Time: Your child can solve Math, Logic, or Trivia challenges to unlock a few extra minutes.\n" +
                              "6. Parent Control: Use your secure PIN to grant extra time or 'Take a Rest' for bonus stars."
                )

                // 4. Privacy
                AboutSection(
                    title = "Privacy & Security",
                    content = "• Offline First: All usage data is stored locally on this device.\n" +
                              "• No Tracking: We do not monitor your personal content, only app foreground time.\n" +
                              "• Zero Ads: A clean experience focused entirely on your child's growth."
                )

                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Got it!")
                }
            }
        }
    }
}

@Composable
private fun AboutSection(title: String, content: String) {
    Column(modifier = Modifier.padding(bottom = 20.dp)) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = content,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Start
        )
    }
}

@Composable
private fun SettingsSectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column {
        Text(
            text     = title,
            style    = MaterialTheme.typography.labelMedium,
            color    = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp)
        )
        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column { content() }
        }
    }
}

@Composable
private fun SettingsListItem(
    icon     : androidx.compose.ui.graphics.vector.ImageVector,
    title    : String,
    subtitle : String,
    onClick  : () -> Unit,
    trailing : @Composable (() -> Unit)? = null
) {
    ListItem(
        headlineContent  = { Text(title, fontWeight = FontWeight.Medium) },
        supportingContent = { Text(subtitle, style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(0.6f)) },
        leadingContent   = { Icon(icon, contentDescription = null,
            tint = MaterialTheme.colorScheme.primary) },
        trailingContent  = trailing ?: {
            Icon(Icons.Filled.ChevronRight, contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurface.copy(0.4f))
        },
        modifier = Modifier.clickable { onClick() }
    )
}

@Composable
private fun ChangePinDialog(
    error: String?, onSubmit: (String, String) -> Unit, onDismiss: () -> Unit
) {
    var current by remember { mutableStateOf("") }
    var newPin  by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title   = { Text("Change PIN", fontWeight = FontWeight.Bold) },
        text    = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(value = current, onValueChange = { current = it },
                    label = { Text("Current PIN") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    visualTransformation = PasswordVisualTransformation(), singleLine = true)
                OutlinedTextField(value = newPin, onValueChange = { newPin = it },
                    label = { Text("New PIN") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    visualTransformation = PasswordVisualTransformation(), singleLine = true)
                OutlinedTextField(value = confirm, onValueChange = { confirm = it },
                    label = { Text("Confirm New PIN") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    visualTransformation = PasswordVisualTransformation(), singleLine = true,
                    isError = error != null,
                    supportingText = error?.let { msg -> { Text(msg) } })
            }
        },
        confirmButton = {
            Button(
                onClick  = { onSubmit(current, newPin) },
                enabled  = newPin == confirm && newPin.length >= 4
            ) { Text("Change") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
