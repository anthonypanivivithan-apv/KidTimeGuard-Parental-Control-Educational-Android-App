package com.kidtimeguard.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.kidtimeguard.app.service.UsageTrackingService

/**
 * Receives a broadcast when UsageTrackingService is killed by the OS
 * and immediately restarts it.
 *
 * Registered dynamically from UsageTrackingService.onTaskRemoved()
 * using a PendingIntent alarm, not in the manifest — so it only fires
 * when our service has actually been running and then stopped.
 */
class ServiceRestartReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_RESTART_SERVICE) {
            UsageTrackingService.start(context)
        }
    }

    companion object {
        const val ACTION_RESTART_SERVICE = "com.kidtimeguard.app.RESTART_SERVICE"
    }
}
