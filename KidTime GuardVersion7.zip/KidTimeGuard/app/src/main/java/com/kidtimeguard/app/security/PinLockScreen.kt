package com.kidtimeguard.app.security

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PinLockScreen(
    viewModel: PinLockViewModel,
    appName: String = "KidTime Guard"
) {
    val uiState by viewModel.uiState.collectAsState()
    var pinText by remember { mutableStateOf("") }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Lock,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(40.dp)
                )
            }

            Spacer(Modifier.height(24.dp))

            Text(
                text = appName,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "Parental Security",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )

            Spacer(Modifier.height(48.dp))

            Text(
                text = "Enter Parent PIN",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(Modifier.height(16.dp))

            OutlinedTextField(
                value = pinText,
                onValueChange = {
                    if (it.length <= 6) {
                        pinText = it
                        // Clear error state in VM when user resumes typing
                        if (uiState.error != null) {
                            viewModel.clearError()
                        }
                    }
                },
                modifier = Modifier.width(220.dp),
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.NumberPassword,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(
                    onDone = {
                        if (pinText.length >= 4) {
                            viewModel.onPinAttempt(pinText)
                        }
                    }
                ),
                textStyle = LocalTextStyle.current.copy(textAlign = TextAlign.Center),
                singleLine = true,
                isError = uiState.error != null,
                supportingText = uiState.error?.let { msg -> { Text(text = msg) } }
            )

            if (uiState.error != null && pinText.length >= 4) {
                LaunchedEffect(uiState.error) {
                    pinText = ""
                }
            }

            Spacer(Modifier.height(24.dp))

            Button(
                onClick = { viewModel.onPinAttempt(pinText) },
                enabled = pinText.length >= 4 && !uiState.isUnlocked,
                modifier = Modifier.width(220.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Unlock App")
            }

            Spacer(Modifier.height(32.dp))
            
            Text(
                text = "This app is protected to prevent unauthorized changes to child limits.",
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                modifier = Modifier.padding(horizontal = 32.dp)
            )
        }
    }
}
