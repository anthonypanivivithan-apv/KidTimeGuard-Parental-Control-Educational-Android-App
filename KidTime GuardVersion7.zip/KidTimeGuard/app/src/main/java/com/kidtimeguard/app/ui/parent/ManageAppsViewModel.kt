package com.kidtimeguard.app.ui.parent

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kidtimeguard.app.data.local.entity.MonitoredAppEntity
import com.kidtimeguard.app.data.repository.MonitoredAppRepository
import com.kidtimeguard.app.service.UsageTrackingService
import com.kidtimeguard.app.ui.setup.InstalledAppInfo
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

data class ManageAppsUiState(
    val installedApps         : List<InstalledAppInfo>      = emptyList(),
    val selectedPackages      : Set<String>                 = emptySet(),
    val selectedAppsForLimits : List<InstalledAppInfo>      = emptyList(),
    val timeLimits            : Map<String, Pair<Int, Int>> = emptyMap(),
    val isLoading             : Boolean                     = true,
    val searchQuery           : String                      = "",
    val isSaving              : Boolean                     = false,
    val saveSuccess           : Boolean                     = false
)

@HiltViewModel
class ManageAppsViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val monitoredAppRepository: MonitoredAppRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ManageAppsUiState())
    val uiState: StateFlow<ManageAppsUiState> = _uiState.asStateFlow()

    init {
        loadData()
    }

    private fun loadData() {
        viewModelScope.launch {
            val monitoredApps = monitoredAppRepository.getAllApps().associateBy { it.packageName }
            
            val allApps = withContext(Dispatchers.IO) {
                val pm = context.packageManager
                val intent = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_LAUNCHER)
                }
                pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
                    .filter { ri ->
                        val pkg = ri.activityInfo.packageName
                        pkg != context.packageName &&
                                !pkg.startsWith("com.android.launcher") &&
                                !pkg.startsWith("com.google.android.apps.nexuslauncher")
                    }
                    .map { ri ->
                        InstalledAppInfo(
                            packageName = ri.activityInfo.packageName,
                            appName     = ri.loadLabel(pm).toString(),
                            category    = categorize(ri.activityInfo.packageName, ri.loadLabel(pm).toString())
                        )
                    }
                    .distinctBy { it.packageName }
                    .sortedBy { it.appName.lowercase() }
            }

            val selected = monitoredApps.keys
            val limits = monitoredApps.mapValues { (_, entity) ->
                Pair(entity.limitWeekdayMinutes, entity.limitWeekendMinutes)
            }.toMutableMap()

            // Fill defaults for non-monitored apps
            allApps.forEach { app ->
                if (!limits.containsKey(app.packageName)) {
                    limits[app.packageName] = defaultLimit(app.category)
                }
            }

            _uiState.update {
                it.copy(
                    installedApps = allApps,
                    selectedPackages = selected,
                    timeLimits = limits,
                    isLoading = false
                )
            }
        }
    }

    fun onSearchQueryChanged(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun getFilteredApps(): List<InstalledAppInfo> {
        val q = _uiState.value.searchQuery.trim().lowercase()
        if (q.isEmpty()) return _uiState.value.installedApps
        return _uiState.value.installedApps.filter {
            it.appName.lowercase().contains(q) || it.packageName.lowercase().contains(q)
        }
    }

    fun toggleAppSelection(packageName: String) {
        _uiState.update {
            val next = it.selectedPackages.toMutableSet()
            if (packageName in next) next.remove(packageName) else next.add(packageName)
            it.copy(selectedPackages = next)
        }
    }

    fun prepareLimits() {
        val state = _uiState.value
        val appMap = state.installedApps.associateBy { it.packageName }
        _uiState.update {
            it.copy(
                selectedAppsForLimits = it.selectedPackages.mapNotNull { pkg -> appMap[pkg] }
            )
        }
    }

    fun setTimeLimit(packageName: String, weekday: Int, weekend: Int) {
        _uiState.update {
            it.copy(timeLimits = it.timeLimits + (packageName to Pair(weekday, weekend)))
        }
    }

    fun saveChanges() {
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true) }
            
            val state = _uiState.value
            val appMap = state.installedApps.associateBy { it.packageName }
            
            // 1. Get current monitored apps to identify what to delete
            val currentMonitored = monitoredAppRepository.getAllApps()
            val toDelete = currentMonitored.filter { it.packageName !in state.selectedPackages }
            
            // 2. Prepare new entities
            val entities = state.selectedPackages.mapNotNull { pkg ->
                val info = appMap[pkg] ?: return@mapNotNull null
                val (weekday, weekend) = state.timeLimits[pkg] ?: defaultLimit(info.category)
                MonitoredAppEntity(
                    packageName = pkg,
                    appName = info.appName,
                    category = info.category,
                    limitWeekdayMinutes = weekday,
                    limitWeekendMinutes = weekend,
                    isActive = true
                )
            }

            // 3. Update DB
            toDelete.forEach { monitoredAppRepository.deleteApp(it) }
            monitoredAppRepository.upsertApps(entities)
            
            // 4. Refresh Service
            UsageTrackingService.start(context)
            
            _uiState.update { it.copy(isSaving = false, saveSuccess = true) }
        }
    }

    private fun defaultLimit(category: String): Pair<Int, Int> = when (category) {
        "SOCIAL_MEDIA" -> Pair(30, 60)
        "GAMES"        -> Pair(30, 60)
        "VIDEO"        -> Pair(45, 90)
        else           -> Pair(60, 90)
    }

    private fun categorize(pkg: String, appName: String): String {
        val p = pkg.lowercase()
        val n = appName.lowercase()
        return when {
            p.contains("instagram") || p.contains("facebook") || p.contains("tiktok") -> "SOCIAL_MEDIA"
            p.contains("youtube") || p.contains("netflix") -> "VIDEO"
            p.contains("game") || n.contains("game") -> "GAMES"
            else -> "OTHER"
        }
    }
}
