package com.kidtimeguard.app.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.MessageDigest
import java.security.SecureRandom
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Manages the parent PIN with:
 * - SHA-256 + random salt hashing (never stored in plaintext)
 * - EncryptedSharedPreferences for storage (AES-256-GCM)
 * - Lockout after 3 consecutive failed attempts (5-minute cooldown)
 */
@Singleton
class ParentPinManager @Inject constructor(
    private val context: Context
) {
    private val prefs: SharedPreferences by lazy {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        EncryptedSharedPreferences.create(
            context,
            PREFS_FILE_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    // ── Public API ────────────────────────────────────────────────

    /** Returns true if a PIN has been configured */
    val isPinSet: Boolean
        get() = prefs.getString(KEY_PIN_HASH, null) != null

    /**
     * Set or change the parent PIN.
     * Generates a fresh salt each time.
     */
    fun setPin(pin: String) {
        require(pin.length in 4..6) { "PIN must be 4–6 digits" }
        require(pin.all { it.isDigit() }) { "PIN must be numeric" }

        val salt = generateSalt()
        val hash = hashPin(pin, salt)

        prefs.edit()
            .putString(KEY_PIN_HASH, hash)
            .putString(KEY_SALT, salt)
            .putInt(KEY_FAILED_ATTEMPTS, 0)
            .putLong(KEY_LOCKOUT_UNTIL, 0L)
            .apply()
    }

    /**
     * Verify a PIN attempt.
     * @return [PinResult] indicating success, failure, or lockout state.
     */
    fun verifyPin(attempt: String): PinResult {
        if (!isPinSet) return PinResult.NotSet

        // Check lockout
        val lockoutUntil = prefs.getLong(KEY_LOCKOUT_UNTIL, 0L)
        val now = System.currentTimeMillis()
        if (now < lockoutUntil) {
            val remainingSeconds = ((lockoutUntil - now) / 1000).toInt()
            return PinResult.LockedOut(remainingSeconds)
        }

        val storedHash = prefs.getString(KEY_PIN_HASH, null) ?: return PinResult.NotSet
        val salt = prefs.getString(KEY_SALT, null) ?: return PinResult.NotSet

        val attemptHash = hashPin(attempt, salt)

        return if (attemptHash == storedHash) {
            // Success — reset failure counter
            prefs.edit()
                .putInt(KEY_FAILED_ATTEMPTS, 0)
                .putLong(KEY_LOCKOUT_UNTIL, 0L)
                .apply()
            PinResult.Correct
        } else {
            val failedAttempts = prefs.getInt(KEY_FAILED_ATTEMPTS, 0) + 1
            if (failedAttempts >= MAX_ATTEMPTS) {
                // Trigger lockout
                prefs.edit()
                    .putInt(KEY_FAILED_ATTEMPTS, 0)
                    .putLong(KEY_LOCKOUT_UNTIL, now + LOCKOUT_DURATION_MS)
                    .apply()
                PinResult.LockedOut(LOCKOUT_DURATION_MS.toInt() / 1000)
            } else {
                prefs.edit().putInt(KEY_FAILED_ATTEMPTS, failedAttempts).apply()
                PinResult.Incorrect(attemptsRemaining = MAX_ATTEMPTS - failedAttempts)
            }
        }
    }

    /**
     * Clear the PIN (used during app reset / uninstall flow).
     * Requires current PIN to be verified before calling.
     */
    fun clearPin() {
        prefs.edit()
            .remove(KEY_PIN_HASH)
            .remove(KEY_SALT)
            .remove(KEY_FAILED_ATTEMPTS)
            .remove(KEY_LOCKOUT_UNTIL)
            .apply()
    }

    // ── Private helpers ───────────────────────────────────────────

    private fun generateSalt(): String {
        val bytes = ByteArray(16)
        SecureRandom().nextBytes(bytes)
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun hashPin(pin: String, salt: String): String {
        val input = "$salt:$pin"
        val digest = MessageDigest.getInstance("SHA-256")
        val hashBytes = digest.digest(input.toByteArray(Charsets.UTF_8))
        return hashBytes.joinToString("") { "%02x".format(it) }
    }

    // ── Result sealed class ───────────────────────────────────────

    sealed class PinResult {
        /** PIN matched successfully */
        object Correct : PinResult()
        /** PIN did not match — [attemptsRemaining] before lockout */
        data class Incorrect(val attemptsRemaining: Int) : PinResult()
        /** Too many failures — locked out for [secondsRemaining] seconds */
        data class LockedOut(val secondsRemaining: Int) : PinResult()
        /** No PIN has been configured yet */
        object NotSet : PinResult()
    }

    companion object {
        private const val PREFS_FILE_NAME    = "ktg_parent_prefs"
        private const val KEY_PIN_HASH       = "pin_hash"
        private const val KEY_SALT           = "pin_salt"
        private const val KEY_FAILED_ATTEMPTS = "failed_attempts"
        private const val KEY_LOCKOUT_UNTIL  = "lockout_until"
        private const val MAX_ATTEMPTS       = 3
        private const val LOCKOUT_DURATION_MS = 5 * 60 * 1000L // 5 minutes
    }
}
