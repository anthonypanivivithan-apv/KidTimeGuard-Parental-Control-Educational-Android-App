package com.kidtimeguard.app.ui.parent

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kidtimeguard.app.data.repository.AnalyticsRepository
import com.kidtimeguard.app.data.repository.MonitoredAppRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters
import javax.inject.Inject

// ─────────────────────────────────────────────────────────────────
// AppManagementViewModel
// ─────────────────────────────────────────────────────────────────

data class AppManagementItem(
    val packageName    : String,
    val appName        : String,
    val weekdayMinutes : Int,
    val weekendMinutes : Int,
    val isActive       : Boolean
)

data class AppManagementUiState(
    val apps: List<AppManagementItem> = emptyList()
)

@HiltViewModel
class AppManagementViewModel @Inject constructor(
    private val monitoredAppRepository: MonitoredAppRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(AppManagementUiState())
    val uiState: StateFlow<AppManagementUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            monitoredAppRepository.observeActiveApps().collect { apps ->
                _uiState.update {
                    it.copy(
                        apps = apps.map { a ->
                            AppManagementItem(
                                packageName    = a.packageName,
                                appName        = a.appName,
                                weekdayMinutes = a.limitWeekdayMinutes,
                                weekendMinutes = a.limitWeekendMinutes,
                                isActive       = a.isActive
                            )
                        }
                    )
                }
            }
        }
    }

    fun toggleApp(packageName: String, active: Boolean) {
        viewModelScope.launch {
            monitoredAppRepository.setActive(packageName, active)
        }
    }

    fun updateLimits(packageName: String, weekdayMinutes: Int, weekendMinutes: Int) {
        viewModelScope.launch {
            monitoredAppRepository.updateLimits(packageName, weekdayMinutes, weekendMinutes)
        }
    }
}

// ─────────────────────────────────────────────────────────────────
// OverrideLogViewModel
// ─────────────────────────────────────────────────────────────────

@HiltViewModel
class OverrideLogViewModel @Inject constructor(
    private val analyticsRepository: AnalyticsRepository,
    private val monitoredAppRepository: MonitoredAppRepository
) : ViewModel() {

    val overrides: StateFlow<List<OverrideLogItem>> = combine(
        analyticsRepository.observeOverridesSince(weekStartMs()),
        monitoredAppRepository.observeActiveApps()
    ) { overrides, apps ->
        val appNames = apps.associateBy({ it.packageName }, { it.appName })
        overrides.map { o ->
            OverrideLogItem(
                appName = appNames[o.packageName] ?: o.packageName.split(".").last(),
                packageName = o.packageName,
                bonusMinutes = o.bonusMinutes,
                overriddenAt = o.overriddenAt
            )
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private fun weekStartMs(): Long = LocalDate.now()
        .with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        .atStartOfDay(java.time.ZoneId.systemDefault())
        .toInstant()
        .toEpochMilli()
}

data class OverrideLogItem(
    val appName: String,
    val packageName: String,
    val bonusMinutes: Int,
    val overriddenAt: Long
)
