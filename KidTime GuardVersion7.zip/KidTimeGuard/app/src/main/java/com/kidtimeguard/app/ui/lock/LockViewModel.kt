package com.kidtimeguard.app.ui.lock

import android.util.Log
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kidtimeguard.app.data.local.entity.ChallengeAttemptEntity
import com.kidtimeguard.app.data.local.entity.ChallengeEntity
import com.kidtimeguard.app.data.repository.AppUsageRepository
import com.kidtimeguard.app.data.repository.ChildProfileRepository
import com.kidtimeguard.app.data.repository.ChallengeRepository
import com.kidtimeguard.app.reward.RewardManager
import com.kidtimeguard.app.reward.RewardResult
import com.kidtimeguard.app.security.ParentPinManager
import com.kidtimeguard.app.service.AppLockManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.LocalDate
import javax.inject.Inject
import kotlin.random.Random


// ── UI State ──────────────────────────────────────────────────────

data class LockUiState(
    val appName     : String          = "",
    val packageName : String          = "",
    val lockEventId : Long            = -1L,
    val screen      : LockScreen      = LockScreen.Options,
    val isEnforcedLock : Boolean      = false,

    // Challenge state
    val challenge                 : ChallengeEntity? = null,
    val selectedAnswerIndex       : Int?             = null,
    val timerExpired              : Boolean          = false,
    val answerSubmitted           : Boolean          = false,
    val isCorrect                 : Boolean          = false,
    val starsEarned               : Int              = 0,
    val bonusMinutesEarned        : Int              = 0,
    val sessionChallengesCompleted: Int              = 0,
    val sessionBonusMinutesTotal  : Int              = 0,
    val startTimeMs               : Long             = 0L,

    // Reward state — from RewardManager
    val rewardResult              : RewardResult?    = null,
    val showLevelUpDialog         : Boolean          = false,

    // PIN state
    val pinError                  : String?          = null,
    val parentBonusMinutesSelected: Int              = 15,

    val isLoading : Boolean = false
)

enum class LockScreen {
    Options,           // Take Break / Earn Time / Ask Parent
    Challenge,         // Showing a challenge question
    ChallengeResult,   // Correct/incorrect feedback + stars
    AllChallengesDone, // Session complete
    ParentPin,         // Parent PIN overlay
    TakeBreakConfirmation
}

// ── ViewModel ────────────────────────────────────────────────────

@HiltViewModel
class LockViewModel @Inject constructor(
    savedStateHandle              : SavedStateHandle,
    private val appUsageRepository    : AppUsageRepository,
    private val challengeRepository   : ChallengeRepository,
    private val childProfileRepository: ChildProfileRepository,
    private val rewardManager         : RewardManager,
    private val parentPinManager      : ParentPinManager,
    private val appLockManager        : AppLockManager,
    private val sessionManager        : ChallengeSessionManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(LockUiState())
    val uiState: StateFlow<LockUiState> = _uiState.asStateFlow()

    private val sessionChallengeIds = mutableListOf<Long>()

    init {
        val packageName = savedStateHandle.get<String>(LockOverlayActivity.EXTRA_PACKAGE_NAME) ?: ""
        val appName     = savedStateHandle.get<String>(LockOverlayActivity.EXTRA_APP_NAME)     ?: "App"
        val lockEventId = savedStateHandle.get<Long>(LockOverlayActivity.EXTRA_LOCK_EVENT_ID)  ?: -1L
        
        loadInitialState(packageName, appName, lockEventId)
    }

    /**
     * ✅ PUBLIC: Allows [LockOverlayActivity] to reset the VM when a new intent arrives
     * due to singleInstance mode.
     */
    fun onNewLockIntent(packageName: String, appName: String, lockEventId: Long) {
        loadInitialState(packageName, appName, lockEventId)
    }

    private fun loadInitialState(packageName: String, appName: String, lockEventId: Long) {
        val isEnforced = appLockManager.isEnforcedLocked(packageName)
        
        _uiState.update {
            it.copy(
                appName = appName, 
                packageName = packageName, 
                lockEventId = lockEventId,
                isEnforcedLock = isEnforced,
                screen = if (isEnforced) LockScreen.ParentPin else LockScreen.Options,
                isLoading = false,
                answerSubmitted = false,
                selectedAnswerIndex = null,
                sessionChallengesCompleted = 0,
                sessionBonusMinutesTotal = 0
            )
        }
        sessionChallengeIds.clear()
        sessionManager.startSession(MAX_CHALLENGES_PER_SESSION)
    }

    // ── Options screen ────────────────────────────────────────────

    fun onTakeBreakClicked(onFinish: () -> Unit) {
        viewModelScope.launch {
            appLockManager.startEnforcedLock(_uiState.value.packageName)
            rewardManager.awardReward(stars = 5)
            _uiState.update { it.copy(screen = LockScreen.TakeBreakConfirmation) }
            kotlinx.coroutines.delay(2000)
            onFinish()
        }
    }

    fun onEarnTimeClicked() {
        viewModelScope.launch {
            try {
                // Reset session state for a fresh start
                sessionChallengeIds.clear()
                sessionManager.startSession(MAX_CHALLENGES_PER_SESSION)
                
                _uiState.update {
                    it.copy(
                        sessionChallengesCompleted = 0,
                        sessionBonusMinutesTotal = 0,
                        isLoading = true
                    ) 
                }

                val startOfDay = LocalDate.now()
                    .atStartOfDay(java.time.ZoneId.systemDefault())
                    .toInstant().toEpochMilli()
                
                val attemptsToday = try {
                    challengeRepository.countAttemptsToday(startOfDay)
                } catch (e: Exception) { 0 }

                if (attemptsToday >= MAX_DAILY_CHALLENGES) {
                    _uiState.update { it.copy(screen = LockScreen.AllChallengesDone, isLoading = false) }
                    return@launch
                }
                loadNextChallenge()
            } catch (e: Exception) {
                Log.e("LockViewModel", "Error in onEarnTimeClicked", e)
                _uiState.update { it.copy(isLoading = false) }
            }
        }
    }

    fun onAskParentClicked() {
        _uiState.update { it.copy(screen = LockScreen.ParentPin, pinError = null) }
    }

    // ── Challenge actions ─────────────────────────────────────────

    fun onAnswerSelected(index: Int) {
        val state     = _uiState.value
        val challenge = state.challenge ?: return
        if (state.answerSubmitted) return

        val timerExpired = index == -1
        val answerTimeMs = System.currentTimeMillis() - state.startTimeMs
        val isCorrect    = !timerExpired && index == challenge.correctIndex

        val starsEarned = when {
            isCorrect && answerTimeMs <= challenge.fastThresholdMs -> 3
            isCorrect                                               -> 2
            else                                                    -> 1
        }

        val bonusMinutes = if (isCorrect) BONUS_MINUTES_CORRECT else BONUS_MINUTES_WRONG

        // Update session manager
        sessionManager.recordChallengeResult(isCorrect, starsEarned, bonusMinutes)

        // Show immediate feedback
        _uiState.update {
            it.copy(
                selectedAnswerIndex = index,
                timerExpired        = timerExpired,
                answerSubmitted     = true,
                isCorrect           = isCorrect,
                starsEarned         = starsEarned,
                bonusMinutesEarned  = bonusMinutes
            )
        }

        viewModelScope.launch {
            try {
                // ✅ ROBUSTNESS: Critical for "Challenge Performance" analytics.
                // If lockEventId is missing, attempt to find a pending one to satisfy FK constraint.
                val finalLockId = if (state.lockEventId <= 0) {
                    appUsageRepository.getPendingLock(state.packageName)?.id ?: 
                    appUsageRepository.recordLockEvent(state.packageName)
                } else {
                    state.lockEventId
                }

                challengeRepository.recordAttempt(
                    ChallengeAttemptEntity(
                        lockEventId   = finalLockId,
                        challengeId   = challenge.id,
                        attemptNumber = sessionManager.getProgress(),
                        isCorrect     = isCorrect,
                        starsEarned   = starsEarned,
                        bonusMinutes  = bonusMinutes,
                        answerTimeMs  = answerTimeMs
                    )
                )

                if (bonusMinutes > 0) {
                    // ✅ This correctly updates the bonus time in the dashboard/analytics
                    appUsageRepository.addBonusTime(
                        state.packageName,
                        LocalDate.now().toEpochDay(),
                        bonusMinutes * 60_000L
                    )
                }

                val reward = rewardManager.awardReward(starsEarned)

                _uiState.update {
                    it.copy(
                        lockEventId       = finalLockId,
                        screen            = LockScreen.ChallengeResult,
                        rewardResult      = reward,
                        showLevelUpDialog = reward.leveledUp
                    )
                }
            } catch (e: Exception) {
                Log.e("LockViewModel", "Error in onAnswerSelected", e)
                _uiState.update {
                    it.copy(
                        screen = LockScreen.ChallengeResult,
                        rewardResult = RewardResult(starsEarned = starsEarned)
                    )
                }
            }
        }
    }

    fun onNextChallengeClicked() {
        val nextProgress = sessionManager.getProgress()
        
        _uiState.update {
            it.copy(
                sessionChallengesCompleted = nextProgress,
                sessionBonusMinutesTotal   = sessionManager.getTotalBonus(),
                answerSubmitted            = false,
                selectedAnswerIndex        = null,
                timerExpired               = false,
                showLevelUpDialog          = false,
                isLoading                  = true
            )
        }

        if (nextProgress >= MAX_CHALLENGES_PER_SESSION) {
            _uiState.update { it.copy(screen = LockScreen.AllChallengesDone, isLoading = false) }
        } else {
            viewModelScope.launch { loadNextChallenge() }
        }
    }

    /**
     * ✅ Handle session completion by resolving the lock event and clearing the state.
     */
    fun onChallengesDone(onFinish: () -> Unit) {
        viewModelScope.launch {
            try {
                val state = _uiState.value
                val totalBonus = sessionManager.getTotalBonus()
                
                if (state.lockEventId > 0) {
                    appUsageRepository.resolveLockEvent(
                        lockEventId = state.lockEventId,
                        reason      = "CHALLENGE_SOLVED",
                        bonusMinutes = totalBonus
                    )
                }
            } catch (e: Exception) {
                Log.e("LockViewModel", "Error resolving lock session", e)
            } finally {
                onFinish()
            }
        }
    }

    fun onLevelUpDialogDismissed() {
        _uiState.update { it.copy(showLevelUpDialog = false) }
    }

    // ── Parent PIN actions ────────────────────────────────────────

    fun onParentPinSubmitted(pin: String, onFinish: () -> Unit) {
        when (val result = parentPinManager.verifyPin(pin)) {
            is ParentPinManager.PinResult.Correct -> {
                viewModelScope.launch {
                    val bonusMinutes = _uiState.value.parentBonusMinutesSelected
                    appLockManager.extendUsageTime(_uiState.value.packageName, bonusMinutes)
                    appLockManager.clearEnforcedLock(_uiState.value.packageName)
                    onFinish()
                }
            }
            is ParentPinManager.PinResult.Incorrect ->
                _uiState.update {
                    it.copy(pinError = "Incorrect PIN. ${result.attemptsRemaining} attempt(s) remaining.")
                }
            is ParentPinManager.PinResult.LockedOut ->
                _uiState.update {
                    it.copy(pinError = "Too many attempts. Try again in ${result.secondsRemaining / 60} min.")
                }
            is ParentPinManager.PinResult.NotSet ->
                _uiState.update { it.copy(pinError = "No PIN set.") }
        }
    }

    fun onPinDialogDismissed() {
        if (_uiState.value.isEnforcedLock) {
            // Cannot dismiss if enforced
        } else {
            _uiState.update { it.copy(screen = LockScreen.Options, pinError = null) }
        }
    }

    fun onParentBonusSelected(minutes: Int) {
        _uiState.update { it.copy(parentBonusMinutesSelected = minutes) }
    }

    fun clearError() {
        _uiState.update { it.copy(pinError = null) }
    }

    // ── Private helpers ───────────────────────────────────────────

    private suspend fun loadNextChallenge() {
        _uiState.update { it.copy(isLoading = true) }

        val profile   = childProfileRepository.getProfile()
        val age       = profile?.age ?: 10
        
        val historyIds = try {
            challengeRepository.getRecentChallengeIds(
                System.currentTimeMillis() - 24 * 60 * 60 * 1000L
            )
        } catch (e: Exception) { emptyList<Long>() }
        
        val combinedExcludeIds = (historyIds + sessionChallengeIds).distinct()
        
        var challenge = try {
            challengeRepository.getWeightedChallenge(age, combinedExcludeIds)
        } catch (e: Exception) {
            Log.e("LockViewModel", "Error loading challenge", e)
            null
        }

        if (challenge == null) {
            challenge = if (Random.nextBoolean()) {
                ChallengeGenerator.generateMathChallenge(age)
            } else {
                ChallengeGenerator.generateLogicChallenge()
            }
        } else {
            sessionChallengeIds.add(challenge.id)
        }

        _uiState.update {
            it.copy(
                challenge           = challenge,
                screen              = LockScreen.Challenge,
                isLoading           = false,
                startTimeMs         = System.currentTimeMillis(),
                answerSubmitted     = false,
                selectedAnswerIndex = null,
                timerExpired        = false,
                rewardResult        = null
            )
        }
    }

    companion object {
        const val MAX_CHALLENGES_PER_SESSION  = 5
        const val MAX_DAILY_CHALLENGES        = 100
        const val BONUS_MINUTES_CORRECT       = 3
        const val BONUS_MINUTES_WRONG         = 1
    }
}
