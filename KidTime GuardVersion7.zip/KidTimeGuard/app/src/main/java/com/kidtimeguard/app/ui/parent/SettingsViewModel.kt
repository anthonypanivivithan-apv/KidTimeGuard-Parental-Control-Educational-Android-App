package com.kidtimeguard.app.ui.parent

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.datastore.preferences.core.edit
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kidtimeguard.app.export.ExportManager
import com.kidtimeguard.app.security.ParentPinManager
import com.kidtimeguard.app.service.UsageTrackingService
import com.kidtimeguard.app.ui.main.DARK_THEME_KEY
import com.kidtimeguard.app.ui.main.dataStore
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SettingsUiState(
    val pinError      : String?  = null,
    val pinChanged    : Boolean  = false,
    val isExporting   : Boolean  = false,
    val isRestarting  : Boolean  = false
)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val pinManager    : ParentPinManager,
    private val exportManager : ExportManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    // ✅ Theme State
    val isDarkTheme: StateFlow<Boolean> = context.dataStore.data
        .map { it[DARK_THEME_KEY] ?: false }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = false
        )

    fun toggleTheme(enabled: Boolean) {
        viewModelScope.launch {
            context.dataStore.edit {
                it[DARK_THEME_KEY] = enabled
            }
        }
    }

    fun changePin(currentPin: String, newPin: String) {
        when (pinManager.verifyPin(currentPin)) {
            is ParentPinManager.PinResult.Correct -> {
                pinManager.setPin(newPin)
                _uiState.update { it.copy(pinError = null, pinChanged = true) }
            }
            is ParentPinManager.PinResult.Incorrect ->
                _uiState.update { it.copy(pinError = "Current PIN is incorrect") }
            is ParentPinManager.PinResult.LockedOut ->
                _uiState.update { it.copy(pinError = "Too many attempts. Wait before trying again.") }
            else ->
                _uiState.update { it.copy(pinError = "No PIN configured") }
        }
    }

    fun restartService() {
        viewModelScope.launch {
            _uiState.update { it.copy(isRestarting = true) }
            UsageTrackingService.stop(context)
            delay(1000) 
            UsageTrackingService.start(context)
            _uiState.update { it.copy(isRestarting = false) }
            Toast.makeText(context, "Monitoring service restarted successfully", Toast.LENGTH_SHORT).show()
        }
    }

    fun exportReport(onSuccess: (Uri) -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            _uiState.update { it.copy(isExporting = true) }
            try {
                val uri = exportManager.exportPdf()
                if (uri != null) {
                    onSuccess(uri)
                } else {
                    onError("Failed to generate PDF report. Please try again.")
                }
            } catch (e: Exception) {
                onError(e.message ?: "Export failed")
            } finally {
                _uiState.update { it.copy(isExporting = false) }
            }
        }
    }

    fun clearPinError() {
        _uiState.update { it.copy(pinError = null, pinChanged = false) }
    }
}
