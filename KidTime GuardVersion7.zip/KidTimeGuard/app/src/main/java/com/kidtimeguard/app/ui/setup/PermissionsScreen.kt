package com.kidtimeguard.app.ui.setup

import android.Manifest
import android.app.AppOpsManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Process
import android.provider.Settings
import android.os.PowerManager
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.PermissionStatus
import com.google.accompanist.permissions.rememberPermissionState
import com.kidtimeguard.app.ui.theme.*



@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun SetupPermissionsScreen(onPermissionsGranted: () -> Unit) {
    val context = LocalContext.current

    // Notification permission (Android 13+)
    val notifPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
        rememberPermissionState(Manifest.permission.POST_NOTIFICATIONS)
    else null

    // Permission states — re-checked on every resume
    var usageGranted   by remember { mutableStateOf(false) }
    var overlayGranted by remember { mutableStateOf(false) }
    var notifGranted   by remember { mutableStateOf(true) }
    var batteryGranted by remember { mutableStateOf(false) }

    // Re-check permissions every time user comes back from Settings
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                // Check Usage Stats via AppOpsManager (works API 19+)
                val appOps = context.getSystemService(AppOpsManager::class.java)
                val mode   = appOps.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(),
                    context.packageName
                )
                usageGranted   = mode == AppOpsManager.MODE_ALLOWED
                overlayGranted = Settings.canDrawOverlays(context)
                notifGranted   = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    notifPermission?.status is PermissionStatus.Granted
                } else true
                val pm = context.getSystemService(PowerManager::class.java)
                batteryGranted = pm.isIgnoringBatteryOptimizations(context.packageName)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val allGranted = usageGranted && overlayGranted && notifGranted

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {
        // ── Header ─────────────────────────────────────────────
        Spacer(Modifier.height(12.dp))
        Text(
            "Required Permissions",
            style      = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "These 3 permissions allow KidTime Guard to monitor ALL apps on this phone — " +
                    "Instagram, YouTube, Free Fire, Ludo King and every other app you select.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onBackground.copy(0.65f)
        )

        Spacer(Modifier.height(24.dp))

        // ── Permission 1: Usage Access ─────────────────────────
        PermissionCard(
            number      = 1,
            icon        = Icons.Filled.QueryStats,
            title       = "Usage Access",
            description = "Lets KidTime Guard read how long Instagram, YouTube, Free Fire, " +
                    "Ludo King and ALL other apps are used daily. This is the core " +
                    "monitoring permission — without it no app can be tracked.",
            howToGrant  = "Tap the button below → find KidTime Guard in the list → toggle it ON",
            granted     = usageGranted,
            onGrant     = {
                context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
                    // Open directly to our app on Android 10+
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        data = Uri.parse("package:${context.packageName}")
                    }
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
            }
        )

        Spacer(Modifier.height(16.dp))

        // ── Permission 2: Display Over Apps ────────────────────
        PermissionCard(
            number      = 2,
            icon        = Icons.Filled.Layers,
            title       = "Display Over Apps",
            description = "Lets the lock screen appear ON TOP of Instagram, YouTube, games etc. " +
                    "when time runs out. Without this, the child can just ignore the lock " +
                    "and keep using the app.",
            howToGrant  = "Tap the button below → find KidTime Guard → toggle Allow ON",
            granted     = overlayGranted,
            onGrant     = {
                context.startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:${context.packageName}")
                    ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                )
            }
        )

        Spacer(Modifier.height(16.dp))

        // ── Permission 3: Notifications ────────────────────────
        PermissionCard(
            number      = 3,
            icon        = Icons.Filled.Notifications,
            title       = "Notifications",
            description = "Shows a silent notification that keeps the monitoring service " +
                    "running in the background. Required on Android 13 and above. " +
                    "The notification is minimal and quiet.",
            howToGrant  = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                "Tap Allow in the dialog that appears"
            else "Not required on your Android version",
            granted     = notifGranted,
            onGrant     = {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    notifPermission?.launchPermissionRequest()
                }
            },
            optional    = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU
        )

        Spacer(Modifier.height(24.dp))

        // ── Permission 4: Battery Optimization Exemption ─────────
        PermissionCard(
            number      = 4,
            icon        = Icons.Filled.BatteryChargingFull,
            title       = "Battery Optimization",
            description = "Prevents Android from killing the monitoring service on " +
                    "Xiaomi, Realme, Samsung and other phones. Without this, " +
                    "monitoring may stop working after a few hours.",
            howToGrant  = "Tap below → find KidTime Guard → select 'Don't optimize'",
            granted     = batteryGranted,
            onGrant     = {
                context.startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                        data = Uri.parse("package:${context.packageName}")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                )
            },
            optional    = true
        )

        Spacer(Modifier.height(24.dp))

        // ── Overall status banner ──────────────────────────────
        AnimatedContent(
            targetState = allGranted,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "status_banner"
        ) { granted ->
            if (granted) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = SuccessGreen.copy(alpha = 0.12f)
                ) {
                    Row(
                        modifier          = Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(Icons.Filled.CheckCircle, null, tint = SuccessGreen,
                            modifier = Modifier.size(28.dp))
                        Column {
                            Text("All permissions granted!",
                                fontWeight = FontWeight.Bold,
                                color      = SuccessGreen)
                            Text("KidTime Guard can now monitor all selected apps.",
                                style = MaterialTheme.typography.bodySmall,
                                color = SuccessGreen.copy(0.8f))
                        }
                    }
                }
            } else {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = WarningAmber.copy(alpha = 0.1f)
                ) {
                    Row(
                        modifier          = Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(Icons.Filled.Info, null, tint = WarningAmber,
                            modifier = Modifier.size(24.dp))
                        Text(
                            "Grant the permissions above to continue. " +
                                    "Ticks appear automatically when each one is enabled.",
                            style = MaterialTheme.typography.bodySmall,
                            color = WarningAmber
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // ── Xiaomi / MIUI / Samsung extra help ────────────────
        BrandSpecificHelp()

        Spacer(Modifier.height(24.dp))

        // ── Continue button ────────────────────────────────────
        Button(
            onClick  = onPermissionsGranted,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            enabled  = usageGranted && overlayGranted,
            shape    = RoundedCornerShape(14.dp)
        ) {
            if (allGranted) {
                Icon(Icons.Filled.CheckCircle, null)
                Spacer(Modifier.width(8.dp))
                Text("All Set — Continue", fontWeight = FontWeight.SemiBold)
            } else {
                Icon(Icons.Filled.Lock, null)
                Spacer(Modifier.width(8.dp))
                val missing = buildList {
                    if (!usageGranted)   add("Usage Access")
                    if (!overlayGranted) add("Display Over Apps")
                }.joinToString(", ")
                Text("Still need: $missing", fontWeight = FontWeight.Medium)
            }
        }

        Spacer(Modifier.height(8.dp))
        Text(
            "After granting each permission, come back here. The tick appears automatically.",
            style     = MaterialTheme.typography.labelSmall,
            color     = MaterialTheme.colorScheme.onBackground.copy(0.45f),
            textAlign = TextAlign.Center,
            modifier  = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(24.dp))
    }
}

// ─────────────────────────────────────────────────────────────────
// Individual permission card
// ─────────────────────────────────────────────────────────────────
@Composable
private fun PermissionCard(
    number      : Int,
    icon        : ImageVector,
    title       : String,
    description : String,
    howToGrant  : String,
    granted     : Boolean,
    onGrant     : () -> Unit,
    optional    : Boolean = false
) {
    val borderColor = when {
        granted  -> SuccessGreen
        optional -> MaterialTheme.colorScheme.outline.copy(0.3f)
        else     -> LimitReachedRed.copy(alpha = 0.4f)
    }
    val bgColor = when {
        granted  -> SuccessGreen.copy(alpha = 0.06f)
        else     -> MaterialTheme.colorScheme.surface
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(16.dp),
        colors   = CardDefaults.cardColors(containerColor = bgColor),
        border   = androidx.compose.foundation.BorderStroke(1.5.dp, borderColor)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Card header row
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Number circle
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(
                            if (granted) SuccessGreen.copy(0.15f)
                            else MaterialTheme.colorScheme.primaryContainer
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (granted) {
                        Icon(Icons.Filled.Check, null,
                            tint     = SuccessGreen,
                            modifier = Modifier.size(20.dp))
                    } else {
                        Text("$number",
                            style      = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color      = MaterialTheme.colorScheme.primary)
                    }
                }
                Spacer(Modifier.width(12.dp))

                // Title + icon
                Icon(icon, null,
                    modifier = Modifier.size(22.dp),
                    tint     = if (granted) SuccessGreen else MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text(title,
                    style      = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier   = Modifier.weight(1f))

                // Status badge
                Surface(
                    shape = RoundedCornerShape(50),
                    color = if (granted) SuccessGreen.copy(0.15f)
                    else LimitReachedRed.copy(0.1f)
                ) {
                    Text(
                        if (granted) "Granted" else if (optional) "Optional" else "Required",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        style    = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color    = if (granted) SuccessGreen else LimitReachedRed
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            // Description
            Text(description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(0.7f))

            Spacer(Modifier.height(10.dp))

            // How to grant
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(0.6f)
            ) {
                Row(
                    modifier          = Modifier.fillMaxWidth().padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Info, null,
                        modifier = Modifier.size(14.dp),
                        tint     = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.6f))
                    Spacer(Modifier.width(6.dp))
                    Text(howToGrant,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.8f))
                }
            }

            if (!granted && !optional) {
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick  = onGrant,
                    modifier = Modifier.fillMaxWidth(),
                    shape    = RoundedCornerShape(10.dp),
                    colors   = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Icon(Icons.Filled.OpenInNew, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Open Settings to grant", fontWeight = FontWeight.Medium)
                }
            }

            if (!granted && optional) {
                Spacer(Modifier.height(12.dp))
                OutlinedButton(
                    onClick  = onGrant,
                    modifier = Modifier.fillMaxWidth(),
                    shape    = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Filled.Notifications, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Allow Notifications", fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────
// Phone-brand specific help instructions
// ─────────────────────────────────────────────────────────────────
@Composable
private fun BrandSpecificHelp() {
    var expanded by remember { mutableStateOf(false) }

    Card(
        onClick  = { expanded = !expanded },
        modifier = Modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(12.dp),
        colors   = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(0.5f)
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.PhoneAndroid, null,
                    modifier = Modifier.size(18.dp),
                    tint     = MaterialTheme.colorScheme.secondary)
                Spacer(Modifier.width(8.dp))
                Text("Trouble finding permissions? Tap for phone-specific help",
                    style    = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.weight(1f),
                    color    = MaterialTheme.colorScheme.onSecondaryContainer)
                Icon(
                    if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, null,
                    tint = MaterialTheme.colorScheme.secondary)
            }

            AnimatedVisibility(visible = expanded) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    HelpRow("Samsung (One UI)",
                        "Settings → Apps → 3-dot menu → Special Access → Usage Access → KidTime Guard ON\n" +
                                "Settings → Apps → 3-dot menu → Special Access → Appear on top → KidTime Guard ON")
                    Spacer(Modifier.height(8.dp))
                    HelpRow("Xiaomi / MIUI / Redmi",
                        "Settings → Apps → Manage apps → KidTime Guard → Other permissions → Display over other apps ON\n" +
                                "Settings → Privacy → Special app access → Usage access → KidTime Guard ON\n" +
                                "Also go to: Settings → Battery → Battery saver → KidTime Guard → No restrictions")
                    Spacer(Modifier.height(8.dp))
                    HelpRow("OnePlus / OxygenOS",
                        "Settings → Apps → App management → KidTime Guard → Special app access → Usage access ON\n" +
                                "Settings → Apps → App management → KidTime Guard → Special app access → Display over other apps ON")
                    Spacer(Modifier.height(8.dp))
                    HelpRow("Realme / ColorOS",
                        "Settings → Privacy → Special app access → Usage access → KidTime Guard ON\n" +
                                "Settings → Other permissions → Display over other apps → KidTime Guard ON")
                    Spacer(Modifier.height(8.dp))
                    HelpRow("Vivo / FuntouchOS",
                        "Settings → Privacy → Permission manager → Usage access → KidTime Guard ON\n" +
                                "Settings → Accessibility → KidTime Guard → Enable all")
                    Spacer(Modifier.height(8.dp))
                    HelpRow("Stock Android / Pixel",
                        "Settings → Apps → Special app access → Usage access → KidTime Guard ON\n" +
                                "Settings → Apps → Special app access → Display over other apps → KidTime Guard ON")
                }
            }
        }
    }
}

@Composable
private fun HelpRow(brand: String, steps: String) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(brand,
            style      = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color      = MaterialTheme.colorScheme.onSecondaryContainer)
        Spacer(Modifier.height(2.dp))
        Text(steps,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSecondaryContainer.copy(0.75f))
    }
}
