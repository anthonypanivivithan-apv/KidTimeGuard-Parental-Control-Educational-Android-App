package com.kidtimeguard.app.ui.lock

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import dagger.hilt.android.AndroidEntryPoint


/**
 * Full-screen, non-dismissible lock overlay shown when a monitored app
 * reaches its daily time limit.
 */
@AndroidEntryPoint
class LockOverlayActivity : ComponentActivity() {

    private val viewModel: LockViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 🛡️ SECURITY: Register modern callback to block back button
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Intentionally blocked to prevent dismissal
            }
        })

        handleIntent(intent)

        setContent {
            val uiState by viewModel.uiState.collectAsState()

            LockOverlayScreen(
                uiState           = uiState,
                onEarnTime        = { viewModel.onEarnTimeClicked() },
                onTakeBreak       = { viewModel.onTakeBreakClicked { finish() } },
                onAskParent       = { viewModel.onAskParentClicked() },
                onPinSubmit       = { pin -> viewModel.onParentPinSubmitted(pin) { finish() } },
                onPinDismiss      = { viewModel.onPinDialogDismissed() },
                onParentBonusSelected = { mins -> viewModel.onParentBonusSelected(mins) },
                onAnswerChallenge = { index -> viewModel.onAnswerSelected(index) },
                onNextChallenge   = { viewModel.onNextChallengeClicked() },
                onChallengesDone  = { 
                    viewModel.onChallengesDone { finish() } 
                },
                onLevelUpDismiss  = { viewModel.onLevelUpDialogDismissed() }
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        val packageName = intent?.getStringExtra(EXTRA_PACKAGE_NAME) ?: return
        val appName     = intent.getStringExtra(EXTRA_APP_NAME) ?: "App"
        val lockEventId = intent.getLongExtra(EXTRA_LOCK_EVENT_ID, -1L)
        
        Log.d("LockOverlayActivity", "Handling lock intent for: $packageName")
        viewModel.onNewLockIntent(packageName, appName, lockEventId)
    }

    /** 
     * Consume the hardware back key for redundancy.
     */
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) return true
        return super.onKeyDown(keyCode, event)
    }

    companion object {
        const val EXTRA_PACKAGE_NAME  = "extra_package_name"
        const val EXTRA_APP_NAME      = "extra_app_name"
        const val EXTRA_LOCK_EVENT_ID = "extra_lock_event_id"

        /**
         * Creates a secure, single-instance intent for the lock overlay.
         * Added FLAG_ACTIVITY_NEW_TASK and FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS for better coverage.
         */
        fun createIntent(
            context: Context,
            packageName: String,
            appName: String,
            lockEventId: Long
        ): Intent = Intent(context, LockOverlayActivity::class.java).apply {
            putExtra(EXTRA_PACKAGE_NAME,  packageName)
            putExtra(EXTRA_APP_NAME,      appName)
            putExtra(EXTRA_LOCK_EVENT_ID, lockEventId)
            
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or
                    Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
        }
    }
}
