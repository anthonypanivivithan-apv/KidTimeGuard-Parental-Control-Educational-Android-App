package com.kidtimeguard.app.ui.parent

import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyticsScreen(
    viewModel: AnalyticsViewModel = hiltViewModel(),
    onBack: () -> Unit,
    onNavigateToOverrideLog: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Weekly Analytics") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = onNavigateToOverrideLog) {
                        Icon(Icons.Filled.History, contentDescription = "Override log")
                    }
                }
            )
        }
    ) { padding ->
        if (uiState.appBreakdown.isEmpty() && uiState.dailyUsageMinutes.all { it == 0 }) {
            Box(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Filled.BarChart,
                        null,
                        modifier = Modifier.size(72.dp),
                        tint = MaterialTheme.colorScheme.onSurface.copy(0.3f)
                    )
                    Spacer(Modifier.height(16.dp))
                    Text(
                        "No data yet",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface.copy(0.5f)
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Come back after your child uses monitored apps today.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface.copy(0.4f),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 32.dp)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier            = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding      = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // ── Summary cards row ──
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        SummaryStatCard(
                            modifier   = Modifier.weight(1f),
                            value      = "${uiState.weekTotalMinutes}m",
                            label      = "This week",
                            delta      = uiState.weekOverWeekDeltaPercent,
                            icon       = Icons.Filled.Schedule
                        )
                        SummaryStatCard(
                            modifier   = Modifier.weight(1f),
                            value      = "${uiState.challengeSuccessRate}%",
                            label      = "Challenge rate",
                            delta      = null,
                            icon       = Icons.Filled.School
                        )
                    }
                }

                // ── Weekly Stacked Bar Chart ──
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(), 
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Usage Stacked View", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                // Simple legend
                                LegendItem("Used", MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(8.dp))
                                LegendItem("Earned", MaterialTheme.colorScheme.secondary)
                                Spacer(Modifier.width(8.dp))
                                LegendItem("Parent", MaterialTheme.colorScheme.tertiary)
                            }
                            Spacer(Modifier.height(16.dp))

                            if (uiState.dailyBreakdowns.isNotEmpty()) {
                                WeeklyStackedBarChart(breakdowns = uiState.dailyBreakdowns)
                            } else {
                                Box(
                                    modifier = Modifier.fillMaxWidth().height(160.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("No data yet", style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurface.copy(0.4f))
                                }
                            }
                        }
                    }
                }

                // ── App breakdown ──
                item {
                    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Text("App Breakdown", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(16.dp))
                            uiState.appBreakdown.forEach { item ->
                                AppBreakdownRow(item = item, totalWeekMinutes = (uiState.weekTotalMinutes * 60_000).toLong())
                                Spacer(Modifier.height(12.dp))
                            }
                            if (uiState.appBreakdown.isEmpty()) {
                                Text("No data yet", style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface.copy(0.4f))
                            }
                        }
                    }
                }

                // ── Challenge performance ──
                item {
                    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Text("Challenge Performance", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(16.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                                ChallengeStatItem("${uiState.totalChallenges}", "Total")
                                ChallengeStatItem("${uiState.correctChallenges}", "Correct")
                                ChallengeStatItem("${uiState.totalStarsEarned}⭐", "Stars")
                                ChallengeStatItem("${uiState.parentOverrides}", "Overrides")
                            }
                        }
                    }
                }

                // ── AI Insight ──
                if (uiState.aiInsight.isNotBlank()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape    = RoundedCornerShape(20.dp),
                            colors   = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                        ) {
                            Row(modifier = Modifier.padding(20.dp)) {
                                Icon(Icons.Filled.Lightbulb, contentDescription = null,
                                    tint = MaterialTheme.colorScheme.secondary)
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    Text("Insight", style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer.copy(0.7f))
                                    Spacer(Modifier.height(4.dp))
                                    Text(uiState.aiInsight, style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LegendItem(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(4.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(0.6f))
    }
}

@Composable
private fun WeeklyStackedBarChart(breakdowns: List<DailyBreakdown>) {
    val usedColor = MaterialTheme.colorScheme.primary
    val challengeColor = MaterialTheme.colorScheme.secondary
    val parentColor = MaterialTheme.colorScheme.tertiary
    val selectedOverlayColor = Color.White.copy(alpha = 0.2f)
    
    val labelColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
    val days = listOf("M", "T", "W", "T", "F", "S", "S")
    val fullDayNames = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")
    
    // Calculate sums for max value
    val dailySums = breakdowns.map { it.usedMs + it.challengeMs + it.parentMs }
    val maxValue = dailySums.maxOrNull()?.takeIf { it > 0 } ?: 1L
    
    var selectedIndex by remember { mutableStateOf<Int?>(null) }

    Column(modifier = Modifier.fillMaxWidth()) {
        
        // ── Selection Detail Header ──
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .animateContentSize(),
            contentAlignment = Alignment.Center
        ) {
            if (selectedIndex != null && selectedIndex!! < breakdowns.size) {
                val breakdown = breakdowns[selectedIndex!!]
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.padding(bottom = 16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = fullDayNames[selectedIndex!!],
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "Total Active Time: ${breakdown.totalMinutes}m",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.7f)
                        )
                        Spacer(Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            SplitDetailItem(label = "Used", value = "${breakdown.usedMinutes}m", color = usedColor)
                            SplitDetailItem(label = "Challenge", value = "${breakdown.challengeMinutes}m", color = challengeColor)
                            SplitDetailItem(label = "Parent", value = "${breakdown.parentMinutes}m", color = parentColor)
                        }
                    }
                }
            } else {
                Text(
                    text = "Tap a bar for detailed split",
                    style = MaterialTheme.typography.labelSmall,
                    color = labelColor,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }
        }

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .padding(horizontal = 8.dp)
                .pointerInput(breakdowns) {
                    detectTapGestures { offset ->
                        val barCount = breakdowns.size
                        if (barCount == 0) return@detectTapGestures
                        val bucketWidth = size.width / barCount
                        val index = (offset.x / bucketWidth).toInt().coerceIn(0, barCount - 1)
                        selectedIndex = if (selectedIndex == index) null else index
                    }
                }
        ) {
            val barCount   = breakdowns.size
            val totalWidth = size.width
            val bucketWidth = totalWidth / barCount
            val barWidth   = bucketWidth * 0.6f
            val maxHeight  = size.height

            // Grid lines
            val gridColor = labelColor.copy(alpha = 0.15f)
            drawLine(gridColor, Offset(0f, 0f), Offset(size.width, 0f))
            drawLine(gridColor, Offset(0f, maxHeight * 0.5f), Offset(size.width, maxHeight * 0.5f))
            drawLine(gridColor, Offset(0f, maxHeight), Offset(size.width, maxHeight))

            breakdowns.forEachIndexed { index, breakdown ->
                val usedH = (breakdown.usedMs.toFloat() / maxValue) * maxHeight
                val challengeH = (breakdown.challengeMs.toFloat() / maxValue) * maxHeight
                val parentH = (breakdown.parentMs.toFloat() / maxValue) * maxHeight
                
                val x = index * bucketWidth + (bucketWidth - barWidth) / 2f
                
                // Draw Parent (Top)
                var currentY = maxHeight - (usedH + challengeH + parentH)
                if (parentH > 0) {
                    drawRoundRect(
                        color = parentColor,
                        topLeft = Offset(x, currentY),
                        size = Size(barWidth, parentH),
                        cornerRadius = CornerRadius(4f, 4f)
                    )
                }
                
                // Draw Challenge (Middle)
                currentY += parentH
                if (challengeH > 0) {
                    drawRoundRect(
                        color = challengeColor,
                        topLeft = Offset(x, currentY),
                        size = Size(barWidth, challengeH),
                        cornerRadius = CornerRadius(0f, 0f)
                    )
                }
                
                // Draw Used (Bottom)
                currentY += challengeH
                if (usedH > 0) {
                    drawRoundRect(
                        color = usedColor,
                        topLeft = Offset(x, currentY),
                        size = Size(barWidth, usedH),
                        cornerRadius = CornerRadius(4f, 4f)
                    )
                }

                // Selection Highlight Overlay
                if (index == selectedIndex) {
                    val totalH = usedH + challengeH + parentH
                    drawRoundRect(
                        color = selectedOverlayColor,
                        topLeft = Offset(x, maxHeight - totalH),
                        size = Size(barWidth, totalH),
                        cornerRadius = CornerRadius(4f, 4f)
                    )
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        // Day labels
        Row(
            modifier            = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            days.forEachIndexed { index, day ->
                Text(
                    text  = day,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (index == selectedIndex) MaterialTheme.colorScheme.secondary else labelColor,
                    fontWeight = if (index == selectedIndex) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
    }
}

@Composable
private fun SplitDetailItem(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(color))
            Spacer(Modifier.width(4.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(0.6f))
        }
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = color)
    }
}

@Composable
private fun SummaryStatCard(
    modifier: Modifier, value: String, label: String,
    delta: Int?, icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Card(
        modifier = modifier, 
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp),
                tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp))
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(0.6f))
            if (delta != null) {
                Spacer(Modifier.height(4.dp))
                val isPositive = delta > 0
                Text(
                    text  = "${if (isPositive) "+" else ""}$delta% vs last week",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isPositive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
private fun AppBreakdownRow(item: AppBreakdownItem, totalWeekMinutes: Long) {
    val fraction = if (totalWeekMinutes > 0) item.usedMs.toFloat() / totalWeekMinutes.toFloat() else 0f
    var expanded by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxWidth().animateContentSize()) {
        Row(
            modifier          = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .clickable { expanded = !expanded }
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text     = item.appName,
                style    = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.width(110.dp),
                maxLines = 1
            )
            Spacer(Modifier.width(12.dp))
            LinearProgressIndicator(
                progress      = { fraction },
                modifier      = Modifier
                    .weight(1f)
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color         = MaterialTheme.colorScheme.primary,
                trackColor    = MaterialTheme.colorScheme.surfaceVariant
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text     = "${item.usedMinutes}m",
                style    = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.width(40.dp)
            )
            Icon(
                imageVector = if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
            )
        }

        if (expanded) {
            Surface(
                modifier = Modifier.padding(start = 12.dp, top = 4.dp, bottom = 8.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    val total = item.totalActiveMinutes
                    Text(
                        text = "Weekly Total Active Time: ${total}m",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MiniSplitDetail("Used", "${item.usedMinutes}m", MaterialTheme.colorScheme.primary)
                        MiniSplitDetail("Earned", "${item.challengeMinutes}m", MaterialTheme.colorScheme.secondary)
                        MiniSplitDetail("Parent", "${item.parentMinutes}m", MaterialTheme.colorScheme.tertiary)
                    }
                }
            }
        }
    }
}

@Composable
private fun MiniSplitDetail(label: String, value: String, color: Color) {
    Column {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(0.6f))
        Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = color)
    }
}

@Composable
private fun ChallengeStatItem(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(label, style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurface.copy(0.6f))
    }
}
