package com.kidtimeguard.app.security

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import javax.inject.Inject

@HiltViewModel
class PinLockViewModel @Inject constructor(
    private val pinManager: ParentPinManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(PinLockUiState())
    val uiState: StateFlow<PinLockUiState> = _uiState.asStateFlow()

    fun onPinAttempt(pin: String) {
        when (val result = pinManager.verifyPin(pin)) {
            is ParentPinManager.PinResult.Correct -> {
                _uiState.update { it.copy(isUnlocked = true, error = null) }
            }
            is ParentPinManager.PinResult.Incorrect -> {
                _uiState.update { it.copy(error = "Incorrect PIN. ${result.attemptsRemaining} attempts remaining.") }
            }
            is ParentPinManager.PinResult.LockedOut -> {
                _uiState.update { it.copy(error = "Locked out. Try again in ${result.secondsRemaining} seconds.") }
            }
            is ParentPinManager.PinResult.NotSet -> {
                // Should not happen if we check isPinSet before showing lock
                _uiState.update { it.copy(isUnlocked = true) }
            }
        }
    }

    fun lock() {
        _uiState.update { it.copy(isUnlocked = false, error = null) }
    }

    fun clearError() {
        _uiState.update { it.copy(error = null) }
    }

    fun resetUnlockState() {
        _uiState.update { it.copy(isUnlocked = false) }
    }
}

data class PinLockUiState(
    val isUnlocked: Boolean = false,
    val error: String? = null
)
