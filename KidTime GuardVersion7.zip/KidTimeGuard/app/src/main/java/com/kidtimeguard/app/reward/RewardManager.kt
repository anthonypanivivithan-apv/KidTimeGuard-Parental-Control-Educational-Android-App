package com.kidtimeguard.app.reward

import com.kidtimeguard.app.data.repository.ChildProfileRepository
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Central reward engine.
 * Calculates stars, XP, and level-ups after each challenge attempt.
 *
 * Level thresholds (XP required to reach each level):
 *   Level 1 →  0 XP  (start)
 *   Level 2 →  100 XP
 *   Level 3 →  250 XP
 *   Level 4 →  500 XP
 *   Level 5 →  800 XP
 *   Level 6+ →  800 + (level-5) * 400 XP
 */
@Singleton
class RewardManager @Inject constructor(
    private val childProfileRepository: ChildProfileRepository
) {
    /**
     * Award stars + XP to the child profile and handle level-up.
     * Returns [RewardResult] containing new totals and whether a level-up occurred.
     */
    suspend fun awardReward(stars: Int): RewardResult {
        val profile = childProfileRepository.getProfile() ?: return RewardResult()

        val xpEarned  = stars * XP_PER_STAR
        val newXp     = profile.totalXp + xpEarned
        val newStars  = profile.totalStars + stars
        val newLevel  = calculateLevel(newXp)
        val leveledUp = newLevel > profile.level

        childProfileRepository.addReward(profile.id, stars, xpEarned)
        if (leveledUp) {
            childProfileRepository.updateLevel(profile.id, newLevel)
        }

        return RewardResult(
            starsEarned  = stars,
            xpEarned     = xpEarned,
            totalStars   = newStars,
            totalXp      = newXp,
            newLevel     = newLevel,
            leveledUp    = leveledUp,
            xpForNext    = xpForNextLevel(newLevel),
            xpProgress   = xpProgressInCurrentLevel(newXp, newLevel)
        )
    }

    fun calculateLevel(totalXp: Int): Int {
        var level = 1
        while (totalXp >= xpRequiredForLevel(level + 1)) level++
        return level
    }

    fun xpRequiredForLevel(level: Int): Int = when {
        level <= 1 -> 0
        level == 2 -> 100
        level == 3 -> 250
        level == 4 -> 500
        level == 5 -> 800
        else       -> 800 + (level - 5) * 400
    }

    fun xpForNextLevel(currentLevel: Int): Int =
        xpRequiredForLevel(currentLevel + 1) - xpRequiredForLevel(currentLevel)

    fun xpProgressInCurrentLevel(totalXp: Int, currentLevel: Int): Int =
        totalXp - xpRequiredForLevel(currentLevel)

    companion object {
        const val XP_PER_STAR = 10
    }
}

data class RewardResult(
    val starsEarned : Int     = 0,
    val xpEarned    : Int     = 0,
    val totalStars  : Int     = 0,
    val totalXp     : Int     = 0,
    val newLevel    : Int     = 1,
    val leveledUp   : Boolean = false,
    val xpForNext   : Int     = 100,
    val xpProgress  : Int     = 0
)
