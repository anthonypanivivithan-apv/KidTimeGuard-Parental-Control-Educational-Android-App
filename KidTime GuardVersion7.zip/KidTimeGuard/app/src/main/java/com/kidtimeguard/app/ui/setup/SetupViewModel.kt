package com.kidtimeguard.app.ui.setup

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import androidx.datastore.preferences.core.edit
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kidtimeguard.app.data.local.entity.ChildProfileEntity
import com.kidtimeguard.app.data.local.entity.MonitoredAppEntity
import com.kidtimeguard.app.data.repository.ChildProfileRepository
import com.kidtimeguard.app.data.repository.MonitoredAppRepository
import com.kidtimeguard.app.security.ParentPinManager
import com.kidtimeguard.app.service.UsageTrackingService
import com.kidtimeguard.app.ui.main.SETUP_COMPLETE
import com.kidtimeguard.app.ui.main.dataStore
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

// ─────────────────────────────────────────────────────────────────
// Represents one installed app discovered on the device
// ─────────────────────────────────────────────────────────────────
data class InstalledAppInfo(
    val packageName : String,
    val appName     : String,
    val category    : String   // SOCIAL_MEDIA | GAMES | VIDEO | EDUCATION | OTHER
)

// ─────────────────────────────────────────────────────────────────
// Complete setup UI state — single source of truth for BOTH screens
//
// selectedPackages      → set of package names the user has ticked
// selectedAppsForLimits → ordered list of InstalledAppInfo for step 5
// timeLimits            → map of packageName → (weekdayMins, weekendMins)
// setupSaved            → true after completeSetup() finishes → triggers nav
// isSaving              → shows spinner on "Start Monitoring" button
// ─────────────────────────────────────────────────────────────────
data class SetupUiState(
    val installedApps         : List<InstalledAppInfo>      = emptyList(),
    val selectedPackages      : Set<String>                 = emptySet(),
    val selectedAppsForLimits : List<InstalledAppInfo>      = emptyList(),
    val timeLimits            : Map<String, Pair<Int, Int>> = emptyMap(),
    val isLoadingApps         : Boolean                     = true,
    val searchQuery           : String                      = "",
    val setupSaved            : Boolean                     = false,
    val isSaving              : Boolean                     = false
)

@HiltViewModel
class SetupViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val pinManager             : ParentPinManager,
    private val childProfileRepository : ChildProfileRepository,
    private val monitoredAppRepository : MonitoredAppRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(SetupUiState())
    val uiState: StateFlow<SetupUiState> = _uiState.asStateFlow()

    init { loadInstalledApps() }

    // ── PIN ───────────────────────────────────────────────────────
    fun setPin(pin: String) { pinManager.setPin(pin) }

    // ── Child Profile ─────────────────────────────────────────────
    fun saveChildProfile(name: String, age: Int) {
        viewModelScope.launch {
            childProfileRepository.upsertProfile(ChildProfileEntity(name = name, age = age))
        }
    }

    // ── App Loading ───────────────────────────────────────────────
    // Uses Intent-based query (works on Android 11+) to get every
    // launchable user app. Runs on IO dispatcher to avoid blocking UI.
    private fun loadInstalledApps() {
        viewModelScope.launch {
            val allApps = withContext(Dispatchers.IO) {
                val pm = context.packageManager
                val intent = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_LAUNCHER)
                }
                pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
                    .filter { ri ->
                        val pkg = ri.activityInfo.packageName
                        pkg != context.packageName &&
                                !pkg.startsWith("com.android.launcher") &&
                                !pkg.startsWith("com.google.android.apps.nexuslauncher") &&
                                !pkg.startsWith("com.miui.home") &&
                                !pkg.startsWith("com.samsung.android.app.spage")
                    }
                    .map { ri ->
                        InstalledAppInfo(
                            packageName = ri.activityInfo.packageName,
                            appName     = ri.loadLabel(pm).toString(),
                            category    = categorize(
                                ri.activityInfo.packageName,
                                ri.loadLabel(pm).toString()
                            )
                        )
                    }
                    .distinctBy { it.packageName }
                    .sortedWith(
                        compareBy({ categoryOrder(it.category) }, { it.appName.lowercase() })
                    )
            }

            // Pre-select social, games, video by default
            val preSelected = allApps
                .filter { it.category in listOf("SOCIAL_MEDIA", "GAMES", "VIDEO") }
                .map { it.packageName }
                .toSet()

            // ✅ FIX 1: Pre-fill ALL default limits at load time.
            // This ensures timeLimits is never empty when arriving at step 5,
            // regardless of whether the user changed defaults or not.
            val defaultLimits: Map<String, Pair<Int, Int>> = allApps.associate { app ->
                app.packageName to defaultLimit(app.category)
            }

            _uiState.update {
                it.copy(
                    installedApps    = allApps,
                    selectedPackages = preSelected,
                    timeLimits       = defaultLimits,   // populated for ALL apps upfront
                    isLoadingApps    = false
                )
            }
        }
    }

    // ── Search ────────────────────────────────────────────────────
    fun onSearchQueryChanged(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun getFilteredApps(): List<InstalledAppInfo> {
        val q = _uiState.value.searchQuery.trim().lowercase()
        if (q.isEmpty()) return _uiState.value.installedApps
        return _uiState.value.installedApps.filter {
            it.appName.lowercase().contains(q) ||
                    it.packageName.lowercase().contains(q)
        }
    }

    // ── Selection ─────────────────────────────────────────────────
    fun toggleAppSelection(packageName: String) {
        _uiState.update {
            val next = it.selectedPackages.toMutableSet()
            if (packageName in next) next.remove(packageName) else next.add(packageName)
            it.copy(selectedPackages = next)
        }
    }

    fun selectAll() {
        _uiState.update {
            it.copy(selectedPackages = it.installedApps.map { a -> a.packageName }.toSet())
        }
    }

    fun deselectAll() {
        _uiState.update { it.copy(selectedPackages = emptySet()) }
    }

    fun selectAllInCategory(category: String) {
        _uiState.update {
            val toAdd = it.installedApps
                .filter { a -> a.category == category }.map { a -> a.packageName }
            it.copy(selectedPackages = it.selectedPackages + toAdd)
        }
    }

    fun deselectAllInCategory(category: String) {
        _uiState.update {
            val toRemove = it.installedApps
                .filter { a -> a.category == category }
                .map { a -> a.packageName }.toSet()
            it.copy(selectedPackages = it.selectedPackages - toRemove)
        }
    }

    // ── FIX 2: saveSelectedApps() ─────────────────────────────────
    // Builds selectedAppsForLimits from selectedPackages.
    // Called ONCE from SelectAppsScreen's "Continue" button.
    // NOT called from MainActivity — that was the double-call bug.
    //
    // Also ensures every selected app has a limit in the map —
    // uses existing value if present, creates default if not.
    fun saveSelectedApps() {
        val state  = _uiState.value
        val appMap = state.installedApps.associateBy { it.packageName }

        // Ensure every selected package has a limit entry
        val updatedLimits = state.timeLimits.toMutableMap()
        state.selectedPackages.forEach { pkg ->
            if (!updatedLimits.containsKey(pkg)) {
                val cat = appMap[pkg]?.category ?: "OTHER"
                updatedLimits[pkg] = defaultLimit(cat)
            }
        }

        _uiState.update {
            it.copy(
                selectedAppsForLimits = it.selectedPackages
                    .mapNotNull { pkg -> appMap[pkg] }
                    .sortedWith(compareBy({ categoryOrder(it.category) }, { it.appName })),
                timeLimits = updatedLimits
            )
        }
    }

    // ── Time Limits ───────────────────────────────────────────────
    // ✅ FIX 3: Updates the SHARED StateFlow immediately.
    // Because SetTimeLimitsScreen reads from uiState.timeLimits via collectAsState(),
    // every slider move is reflected in the card's displayed value instantly
    // without any local state duplication.
    fun setTimeLimit(packageName: String, weekdayMinutes: Int, weekendMinutes: Int) {
        _uiState.update {
            it.copy(
                timeLimits = it.timeLimits +
                        (packageName to Pair(
                            weekdayMinutes.coerceAtLeast(5),
                            weekendMinutes.coerceAtLeast(5)
                        ))
            )
        }
    }

    fun setTimeLimitForAll(weekdayMinutes: Int, weekendMinutes: Int) {
        val weekday = weekdayMinutes.coerceAtLeast(5)
        val weekend = weekendMinutes.coerceAtLeast(5)
        _uiState.update {
            it.copy(timeLimits = it.timeLimits.mapValues { Pair(weekday, weekend) })
        }
    }

    // ── Complete Setup ────────────────────────────────────────────
    // Persists ALL selected apps with their final limits to Room DB,
    // starts the service, marks DataStore flag, then sets setupSaved = true
    // which triggers navigation forward via LaunchedEffect in the screen.
    fun completeSetup() {
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true) }

            val state  = _uiState.value
            val appMap = state.installedApps.associateBy { it.packageName }

            // Always use selectedPackages as the final authority — in case user
            // navigated back and changed their selection after visiting step 5
            val entities = state.selectedPackages.mapNotNull { pkg ->
                val info = appMap[pkg] ?: return@mapNotNull null
                val (weekday, weekend) = state.timeLimits[pkg] ?: defaultLimit(info.category)
                MonitoredAppEntity(
                    packageName         = pkg,
                    appName             = info.appName,
                    category            = info.category,
                    limitWeekdayMinutes = weekday.coerceAtLeast(5),
                    limitWeekendMinutes = weekend.coerceAtLeast(5),
                    isActive            = true
                )
            }

            monitoredAppRepository.upsertApps(entities)
            context.dataStore.edit { prefs -> prefs[SETUP_COMPLETE] = true }
            UsageTrackingService.start(context)

            _uiState.update { it.copy(isSaving = false, setupSaved = true) }
        }
    }

    // ── Post-setup: add / update / remove from dashboard ─────────
    fun addAppToMonitoring(packageName: String, weekdayMinutes: Int, weekendMinutes: Int) {
        viewModelScope.launch {
            val pm      = context.packageManager
            val appName = try {
                pm.getApplicationLabel(pm.getApplicationInfo(packageName, 0)).toString()
            } catch (_: Exception) { packageName }
            monitoredAppRepository.upsertApp(
                MonitoredAppEntity(
                    packageName         = packageName,
                    appName             = appName,
                    category            = categorize(packageName, appName),
                    limitWeekdayMinutes = weekdayMinutes.coerceAtLeast(5),
                    limitWeekendMinutes = weekendMinutes.coerceAtLeast(5),
                    isActive            = true
                )
            )
        }
    }

    fun updateAppLimit(packageName: String, weekdayMinutes: Int, weekendMinutes: Int) {
        viewModelScope.launch {
            monitoredAppRepository.updateLimits(
                packageName,
                weekdayMinutes.coerceAtLeast(5),
                weekendMinutes.coerceAtLeast(5)
            )
        }
    }

    fun removeAppFromMonitoring(packageName: String) {
        viewModelScope.launch {
            monitoredAppRepository.setActive(packageName, false)
        }
    }

    // ── Helpers ───────────────────────────────────────────────────
    private fun defaultLimit(category: String): Pair<Int, Int> = when (category) {
        "SOCIAL_MEDIA" -> Pair(30, 60)
        "GAMES"        -> Pair(30, 60)
        "VIDEO"        -> Pair(45, 90)
        else           -> Pair(60, 90)
    }

    private fun categorize(pkg: String, appName: String): String {
        val p = pkg.lowercase()
        val n = appName.lowercase()
        return when {
            p.contains("instagram") || p.contains("facebook") || p.contains("tiktok") ||
                    p.contains("snapchat") || p.contains("twitter") || p.contains("whatsapp") ||
                    p.contains("telegram") || p.contains("discord") || p.contains("sharechat") ||
                    p.contains("moj") || p.contains("josh") || p.contains("roposo") ||
                    n.contains("instagram") || n.contains("facebook") || n.contains("whatsapp") -> "SOCIAL_MEDIA"

            p.contains("youtube") || p.contains("netflix") || p.contains("hotstar") ||
                    p.contains("primevideo") || p.contains("sonyliv") || p.contains("zee5") ||
                    p.contains("mxplayer") || p.contains("vlc") || p.contains("jiotv") ||
                    n.contains("youtube") || n.contains("netflix") || n.contains("hotstar") -> "VIDEO"

            p.contains("freefire") || p.contains("garena") || p.contains("com.dts.") ||
                    p.contains("pubg") || p.contains("battlegrounds") || p.contains("ludo") ||
                    p.contains("clash") || p.contains("candycrush") || p.contains("subway") ||
                    p.contains("minecraft") || p.contains("roblox") || p.contains("asphalt") ||
                    p.contains("8ball") || p.contains("mobilelegends") || p.contains("freefireth") ||
                    p.contains("game") || p.contains("games") ||
                    n.contains("free fire") || n.contains("pubg") || n.contains("ludo") ||
                    n.contains("clash") || n.contains("game") -> "GAMES"

            p.contains("duolingo") || p.contains("byjus") || p.contains("khan") ||
                    p.contains("unacademy") || p.contains("coursera") || p.contains("udemy") ||
                    p.contains("vedantu") || p.contains("toppr") -> "EDUCATION"

            else -> "OTHER"
        }
    }

    private fun categoryOrder(cat: String): Int = when (cat) {
        "SOCIAL_MEDIA" -> 0; "GAMES" -> 1; "VIDEO" -> 2; "EDUCATION" -> 3; else -> 4
    }
}