package com.kidtimeguard.app.di

import android.content.Context
import androidx.room.Room
import com.kidtimeguard.app.data.local.KidTimeGuardDatabase
import com.kidtimeguard.app.data.local.dao.*
import com.kidtimeguard.app.data.repository.*
import com.kidtimeguard.app.data.repository.impl.*
import com.kidtimeguard.app.security.ParentPinManager
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import java.time.ZoneId
import javax.inject.Qualifier
import javax.inject.Singleton

// ✅ Custom Qualifier for TimeZone
@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class AppTimeZone

// ─────────────────────────────────────────────────────────────────
// DatabaseModule — provides Room DB and all DAOs
// ─────────────────────────────────────────────────────────────────
@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): KidTimeGuardDatabase =
        KidTimeGuardDatabase.getInstance(context)

    @Provides
    fun provideChildProfileDao(db: KidTimeGuardDatabase): ChildProfileDao =
        db.childProfileDao()

    @Provides
    fun provideMonitoredAppDao(db: KidTimeGuardDatabase): MonitoredAppDao =
        db.monitoredAppDao()

    @Provides
    fun provideUsageRecordDao(db: KidTimeGuardDatabase): UsageRecordDao =
        db.usageRecordDao()

    @Provides
    fun provideAppLockEventDao(db: KidTimeGuardDatabase): AppLockEventDao =
        db.appLockEventDao()

    @Provides
    fun provideChallengeAttemptDao(db: KidTimeGuardDatabase): ChallengeAttemptDao =
        db.challengeAttemptDao()

    @Provides
    fun provideChallengeDao(db: KidTimeGuardDatabase): ChallengeDao =
        db.challengeDao()

    @Provides
    fun provideParentOverrideDao(db: KidTimeGuardDatabase): ParentOverrideDao =
        db.parentOverrideDao()
}

// ─────────────────────────────────────────────────────────────────
// SecurityModule — provides PIN manager
// ─────────────────────────────────────────────────────────────────
@Module
@InstallIn(SingletonComponent::class)
object SecurityModule {

    @Provides
    @Singleton
    fun provideParentPinManager(@ApplicationContext context: Context): ParentPinManager =
        ParentPinManager(context)
}

// ─────────────────────────────────────────────────────────────────
// RepositoryModule — binds interfaces to implementations
// ─────────────────────────────────────────────────────────────────
@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindAppUsageRepository(
        impl: AppUsageRepositoryImpl
    ): AppUsageRepository

    @Binds
    @Singleton
    abstract fun bindChallengeRepository(
        impl: ChallengeRepositoryImpl
    ): ChallengeRepository

    @Binds
    @Singleton
    abstract fun bindChildProfileRepository(
        impl: ChildProfileRepositoryImpl
    ): ChildProfileRepository

    @Binds
    @Singleton
    abstract fun bindMonitoredAppRepository(
        impl: MonitoredAppRepositoryImpl
    ): MonitoredAppRepository

    @Binds
    @Singleton
    abstract fun bindAnalyticsRepository(
        impl: AnalyticsRepositoryImpl
    ): AnalyticsRepository
}

// ─────────────────────────────────────────────────────────────────
// TimeModule — centralizes Indian TimeZone configuration
// ─────────────────────────────────────────────────────────────────
@Module
@InstallIn(SingletonComponent::class)
object TimeModule {
    
    @Provides
    @Singleton
    @AppTimeZone
    fun provideAppTimeZone(): ZoneId = ZoneId.of("Asia/Kolkata")
}
