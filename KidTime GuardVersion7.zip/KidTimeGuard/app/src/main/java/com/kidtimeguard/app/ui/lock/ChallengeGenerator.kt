package com.kidtimeguard.app.ui.lock

import com.kidtimeguard.app.data.local.entity.ChallengeEntity
import org.json.JSONArray
import kotlin.random.Random

/**
 * Generates dynamic challenges for the child if the database doesn't have enough variety.
 */
object ChallengeGenerator {

    fun generateMathChallenge(age: Int): ChallengeEntity {
        val range = if (age < 8) 1..10 else 1..25
        val a = range.random()
        val b = range.random()
        val op = if (age < 10) listOf("+", "-").random() else listOf("+", "-", "*").random()
        
        val result = when (op) {
            "+" -> a + b
            "-" -> a - b
            "*" -> a * b
            else -> a + b
        }

        val question = "What is $a $op $b?"
        val options = mutableListOf(result)
        while (options.size < 4) {
            val wrong = (result - 5..result + 10).random()
            if (wrong != result && !options.contains(wrong)) options.add(wrong)
        }
        options.shuffle()

        return ChallengeEntity(
            id = Random.nextLong(),
            type = "MATH",
            question = question,
            optionsJson = JSONArray(options).toString(),
            correctIndex = options.indexOf(result),
            explanation = "Calculating numbers helps your brain get stronger!",
            minAge = age,
            maxAge = age + 2,
            fastThresholdMs = 10000
        )
    }

    fun generateLogicChallenge(): ChallengeEntity {
        val logicPuzzles = listOf(
            Triple("Which is heaviest?", listOf("1kg lead", "1kg feathers", "1kg air", "They are same"), 3),
            Triple("What comes next: 2, 4, 6, 8, ...?", listOf("9", "10", "11", "12"), 1),
            Triple("If you turn a left-hand glove inside out, it becomes...", listOf("Still left", "Right-hand", "Upside down", "A sock"), 1)
        ).random()

        return ChallengeEntity(
            id = Random.nextLong(),
            type = "LOGIC",
            question = logicPuzzles.first,
            optionsJson = JSONArray(logicPuzzles.second).toString(),
            correctIndex = logicPuzzles.third,
            explanation = "Logic is like a puzzle for your mind.",
            minAge = 5,
            maxAge = 18,
            fastThresholdMs = 15000
        )
    }
}
