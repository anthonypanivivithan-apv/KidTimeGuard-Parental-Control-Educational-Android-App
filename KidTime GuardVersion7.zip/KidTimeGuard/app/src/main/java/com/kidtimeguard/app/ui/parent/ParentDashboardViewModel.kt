package com.kidtimeguard.app.ui.parent

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kidtimeguard.app.data.repository.AppUsageRepository
import com.kidtimeguard.app.data.repository.ChildProfileRepository
import com.kidtimeguard.app.data.repository.MonitoredAppRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZoneId
import javax.inject.Inject

data class AppUsageItem(
    val packageName: String,
    val appName: String,
    val usageMinutes: Int,
    val limitMinutes: Int,
    val isLocked: Boolean = false
)

data class ParentDashboardUiState(
    val childName: String       = "",
    val childLevel: Int         = 1,
    val totalStars: Int         = 0,
    val totalXp: Int            = 0,
    val xpForNextLevel: Int     = 100,
    val todayTotalUsageMinutes: Int = 0,
    val activeAppsCount: Int    = 0,
    val appUsageItems: List<AppUsageItem> = emptyList(),
    val isLoading: Boolean      = true
)

@HiltViewModel
class ParentDashboardViewModel @Inject constructor(
    private val childProfileRepository: ChildProfileRepository,
    private val monitoredAppRepository: MonitoredAppRepository,
    private val appUsageRepository: AppUsageRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ParentDashboardUiState())
    val uiState: StateFlow<ParentDashboardUiState> = _uiState.asStateFlow()

    private val indianZone = ZoneId.of("Asia/Kolkata")

    /** 
     * ✅ DATE-REACTIVE FLOW: Emits current date and triggers a refresh on date change.
     * Hardcoded to Indian Time Zone (Asia/Kolkata) for absolute 12 AM IST reset.
     */
    private val currentDateFlow = flow {
        while (true) {
            emit(LocalDate.now(indianZone))
            delay(30_000) // Poll every 30 seconds for date crossovers
        }
    }.distinctUntilChanged()

    init {
        viewModelScope.launch {
            // ✅ Observe date changes and profile/app updates together
            currentDateFlow.collectLatest { today ->
                val dateEpoch = today.toEpochDay()
                val isWeekend = today.dayOfWeek.value >= 6

                combine(
                    childProfileRepository.observeProfile(),
                    monitoredAppRepository.observeActiveApps(),
                    appUsageRepository.observeUsageRecordsForDate(dateEpoch)
                ) { profile, apps, records ->
                    Triple(profile, apps, records.associateBy { it.packageName })
                }
                .flowOn(Dispatchers.IO)
                .collect { (profile, apps, recordsMap) ->
                    val usageItems = apps.map { app ->
                        val record = recordsMap[app.packageName]
                        
                        // Baseline from DB (Corrected for IST)
                        val usageMs  = record?.usageMs ?: 0L
                        val bonusMs  = record?.bonusMs ?: 0L
                        
                        val baseLimitMin = if (isWeekend) app.limitWeekendMinutes else app.limitWeekdayMinutes
                        val effectiveLimitMin = baseLimitMin + (bonusMs / 60_000).toInt()
                        
                        AppUsageItem(
                            packageName  = app.packageName,
                            appName      = app.appName,
                            usageMinutes = (usageMs / 60_000).toInt(),
                            limitMinutes = effectiveLimitMin,
                            isLocked     = usageMs >= (effectiveLimitMin * 60_000L)
                        )
                    }

                    _uiState.update {
                        it.copy(
                            childName              = profile?.name ?: "Child",
                            childLevel             = profile?.level ?: 1,
                            totalStars             = profile?.totalStars ?: 0,
                            totalXp                = profile?.totalXp ?: 0,
                            xpForNextLevel         = 100,
                            todayTotalUsageMinutes = usageItems.sumOf { a -> a.usageMinutes },
                            activeAppsCount        = apps.size,
                            appUsageItems          = usageItems.sortedByDescending { a -> a.usageMinutes },
                            isLoading              = false
                        )
                    }
                }
            }
        }
    }
}
