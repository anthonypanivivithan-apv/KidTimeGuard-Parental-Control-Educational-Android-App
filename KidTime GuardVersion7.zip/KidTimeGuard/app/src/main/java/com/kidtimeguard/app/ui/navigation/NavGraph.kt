//package com.kidtimeguard.app.ui.navigation

//object NavGraph {
 //   const val SETUP_GRAPH = "setup_graph"
 //   const val PARENT_GRAPH = "parent_graph"
//}