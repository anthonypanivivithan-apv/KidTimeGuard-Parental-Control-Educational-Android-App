package com.kidtimeguard.app.ui.lock

import com.kidtimeguard.app.data.local.entity.ChallengeEntity
import javax.inject.Inject

/**
 * Manages the state of a single challenge session (e.g. 5 questions).
 */
class ChallengeSessionManager @Inject constructor() {

    private var currentSessionChallenges = mutableListOf<ChallengeEntity>()
    private var completedCount = 0
    private var totalBonusMinutes = 0
    private var totalStars = 0

    fun startSession(targetCount: Int = 5) {
        currentSessionChallenges.clear()
        completedCount = 0
        totalBonusMinutes = 0
        totalStars = 0
    }

    fun recordChallengeResult(isCorrect: Boolean, stars: Int, bonusMinutes: Int) {
        completedCount++
        totalStars += stars
        totalBonusMinutes += bonusMinutes
    }

    fun isSessionComplete(targetCount: Int = 5): Boolean = completedCount >= targetCount

    fun getProgress(): Int = completedCount
    fun getTotalBonus(): Int = totalBonusMinutes
    fun getTotalStars(): Int = totalStars
}
