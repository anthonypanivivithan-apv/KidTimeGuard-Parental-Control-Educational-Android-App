package com.kidtimeguard.app.data.repository.impl

import com.kidtimeguard.app.data.local.dao.*
import com.kidtimeguard.app.data.local.entity.*
import com.kidtimeguard.app.data.repository.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import javax.inject.Inject

class AppUsageRepositoryImpl @Inject constructor(
    private val usageRecordDao: UsageRecordDao,
    private val appLockEventDao: AppLockEventDao,
    private val parentOverrideDao: ParentOverrideDao
) : AppUsageRepository {

    override fun observeUsageRecord(packageName: String, dateEpoch: Long): Flow<UsageRecordEntity?> =
        usageRecordDao.observeRecord(packageName, dateEpoch)

    override suspend fun getUsageRecord(packageName: String, dateEpoch: Long): UsageRecordEntity? =
        withContext(Dispatchers.IO) { usageRecordDao.getRecord(packageName, dateEpoch) }

    override suspend fun getRecordsForDate(dateEpoch: Long): List<UsageRecordEntity> =
        withContext(Dispatchers.IO) { usageRecordDao.getRecordsForDate(dateEpoch) }

    override suspend fun getUsageRecordsForDate(dateEpoch: Long): List<UsageRecordEntity> =
        getRecordsForDate(dateEpoch)

    override fun observeUsageRecordsForDate(dateEpoch: Long): Flow<List<UsageRecordEntity>> =
        usageRecordDao.observeRecordsForDate(dateEpoch)

    override suspend fun upsertUsageRecord(record: UsageRecordEntity) =
        withContext(Dispatchers.IO) { usageRecordDao.upsertRecord(record) }

    override suspend fun updateUsageMs(packageName: String, dateEpoch: Long, usageMs: Long) =
        withContext(Dispatchers.IO) { usageRecordDao.updateUsage(packageName, dateEpoch, usageMs) }

    /**
     * Uses [addBonusTimeSafe] to ensure a usage record exists before updating.
     * This guarantees that bonus time from challenges or parent PINs is always 
     * reflected in the UI, even if the app hasn't been used yet today.
     */
    override suspend fun addBonusTime(packageName: String, dateEpoch: Long, bonusMs: Long) =
        withContext(Dispatchers.IO) { usageRecordDao.addBonusTimeSafe(packageName, dateEpoch, bonusMs) }

    override suspend fun addBonusAndLogOverride(
        packageName: String,
        dateEpoch: Long,
        bonusMs: Long,
        bonusMinutes: Int,
        timestamp: Long
    ) = withContext(Dispatchers.IO) {
        usageRecordDao.addBonusAndLogOverride(packageName, dateEpoch, bonusMs, bonusMinutes, timestamp)
    }

    override suspend fun deleteOldRecords(beforeEpoch: Long) = withContext(Dispatchers.IO) {
        usageRecordDao.deleteOldRecordsBefore(beforeEpoch)
    }

    override suspend fun recordLockEvent(packageName: String): Long =
        withContext(Dispatchers.IO) {
            appLockEventDao.insertLockEvent(AppLockEventEntity(packageName = packageName))
        }

    override suspend fun resolveLockEvent(lockEventId: Long, reason: String, bonusMinutes: Int) =
        withContext(Dispatchers.IO) {
            appLockEventDao.resolveLockEvent(lockEventId, reason = reason, bonusMinutes = bonusMinutes)
        }

    override suspend fun getPendingLock(packageName: String): AppLockEventEntity? =
        withContext(Dispatchers.IO) { appLockEventDao.getPendingLock(packageName) }

    override fun observeLockEventsSince(fromMs: Long): Flow<List<AppLockEventEntity>> =
        appLockEventDao.observeLockEventsSince(fromMs)

    override suspend fun logParentOverride(packageName: String, bonusMinutes: Int) {
        withContext(Dispatchers.IO) {
            parentOverrideDao.logOverride(
                ParentOverrideEntity(packageName = packageName, bonusMinutes = bonusMinutes)
            )
        }
    }
}

class ChallengeRepositoryImpl @Inject constructor(
    private val challengeDao: ChallengeDao,
    private val challengeAttemptDao: ChallengeAttemptDao
) : ChallengeRepository {

    /** Weighted random: 40% MATH, 25% LOGIC, 20% TRIVIA, 10% WORD, 5% MEMORY */
    private val typeWeights = listOf(
        "MATH"   to 40,
        "LOGIC"  to 25,
        "TRIVIA" to 20,
        "WORD"   to 10,
        "MEMORY" to 5
    )

    override suspend fun getNextChallenge(age: Int, recentIds: List<Long>): ChallengeEntity? =
        withContext(Dispatchers.IO) { challengeDao.getRandomChallenge(age, recentIds) }

    override suspend fun getWeightedChallenge(age: Int, recentIds: List<Long>): ChallengeEntity? {
        val roll = (1..100).random()
        var cumulative = 0
        val type = typeWeights.firstOrNull { (_, weight) ->
            cumulative += weight
            roll <= cumulative
        }?.first ?: "MATH"

        return withContext(Dispatchers.IO) {
            challengeDao.getRandomChallengeByType(age, type, recentIds)
                ?: challengeDao.getRandomChallenge(age, recentIds)
        }
    }

    override suspend fun recordAttempt(attempt: ChallengeAttemptEntity): Long =
        withContext(Dispatchers.IO) { challengeAttemptDao.insertAttempt(attempt) }

    override suspend fun countAttemptsToday(startOfDayMs: Long): Int =
        withContext(Dispatchers.IO) { challengeAttemptDao.countAttemptsToday(startOfDayMs) }

    override suspend fun getAttemptsForSession(lockEventId: Long): List<ChallengeAttemptEntity> =
        withContext(Dispatchers.IO) { challengeAttemptDao.getAttemptsForSession(lockEventId) }

    override suspend fun getRecentChallengeIds(sinceMs: Long): List<Long> =
        withContext(Dispatchers.IO) { challengeAttemptDao.getRecentChallengeIds(sinceMs) }

    override suspend fun getChallengeStats(fromMs: Long): ChallengeStats =
        withContext(Dispatchers.IO) { challengeAttemptDao.getSuccessStats(fromMs) }

    override fun observeAttemptsSince(fromMs: Long): Flow<List<ChallengeAttemptEntity>> =
        challengeAttemptDao.observeAttemptsSince(fromMs)
}

class ChildProfileRepositoryImpl @Inject constructor(
    private val dao: ChildProfileDao
) : ChildProfileRepository {

    override fun observeProfile(): Flow<ChildProfileEntity?> = dao.observeProfile()
    override suspend fun getProfile(): ChildProfileEntity? = withContext(Dispatchers.IO) { dao.getProfile() }
    override suspend fun upsertProfile(profile: ChildProfileEntity): Long = withContext(Dispatchers.IO) { dao.upsertProfile(profile) }
    override suspend fun addReward(profileId: Long, stars: Int, xp: Int) = withContext(Dispatchers.IO) { dao.addStarsAndXp(profileId, stars, xp) }
    override suspend fun updateLevel(profileId: Long, level: Int) = withContext(Dispatchers.IO) { dao.updateLevel(profileId, level) }
}

class MonitoredAppRepositoryImpl @Inject constructor(
    private val dao: MonitoredAppDao
) : MonitoredAppRepository {

    override fun observeActiveApps(): Flow<List<MonitoredAppEntity>> = dao.observeActiveApps()
    override suspend fun getAllApps(): List<MonitoredAppEntity> = withContext(Dispatchers.IO) { dao.getAllApps() }
    override suspend fun getAppByPackage(packageName: String): MonitoredAppEntity? = withContext(Dispatchers.IO) { dao.getAppByPackage(packageName) }
    override suspend fun upsertApp(app: MonitoredAppEntity): Long = withContext(Dispatchers.IO) { dao.upsertApp(app) }
    override suspend fun upsertApps(apps: List<MonitoredAppEntity>) = withContext(Dispatchers.IO) { dao.upsertApps(apps) }
    override suspend fun updateLimits(packageName: String, weekdayMinutes: Int, weekendMinutes: Int) =
        withContext(Dispatchers.IO) { dao.updateLimits(packageName, weekdayMinutes, weekendMinutes) }
    override suspend fun setActive(packageName: String, active: Boolean) = withContext(Dispatchers.IO) { dao.setActive(packageName, active) }
    override suspend fun deleteApp(app: MonitoredAppEntity) = withContext(Dispatchers.IO) { dao.deleteApp(app) }
}

class AnalyticsRepositoryImpl @Inject constructor(
    private val usageRecordDao: UsageRecordDao,
    private val parentOverrideDao: ParentOverrideDao,
    private val challengeAttemptDao: ChallengeAttemptDao
) : AnalyticsRepository {

    override fun observeRecordsSince(fromEpoch: Long): Flow<List<UsageRecordEntity>> =
        usageRecordDao.observeRecordsSince(fromEpoch)

    override suspend fun getWeeklySummary(fromEpoch: Long, toEpoch: Long): List<AppUsageSummary> =
        withContext(Dispatchers.IO) { usageRecordDao.getWeeklySummary(fromEpoch, toEpoch) }

    override fun observeOverridesSince(fromMs: Long): Flow<List<ParentOverrideEntity>> =
        parentOverrideDao.observeOverridesSince(fromMs)

    override suspend fun getChallengeStats(fromMs: Long): ChallengeStats =
        withContext(Dispatchers.IO) { challengeAttemptDao.getSuccessStats(fromMs) }

    override suspend fun countOverridesSince(fromMs: Long): Int =
        withContext(Dispatchers.IO) { parentOverrideDao.countOverridesSince(fromMs) }

    override fun observeAttemptsSince(fromMs: Long): Flow<List<ChallengeAttemptEntity>> =
        challengeAttemptDao.observeAttemptsSince(fromMs)
}
