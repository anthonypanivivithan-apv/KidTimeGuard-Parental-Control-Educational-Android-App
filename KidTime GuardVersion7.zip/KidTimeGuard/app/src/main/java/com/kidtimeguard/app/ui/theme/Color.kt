package com.kidtimeguard.app.ui.theme

import androidx.compose.ui.graphics.Color

// 🎨 Requested Light Theme Colors
val LightPrimary = Color(0xFFAC1D58)
val LightSecondary = Color(0xFFFF5F7E)
val LightAccent = Color(0xFFFFB4A2)
val LightBackground = Color(0xFFFFFFFF)
val LightSurface = Color(0xFFFFF1F5)
val LightText = Color(0xFF281D2E)

// 🌙 Requested Dark Theme Colors
val DarkPrimary = Color(0xFFFF5F7E)
val DarkSecondary = Color(0xFFAC1D58)
val DarkAccent = Color(0xFFFFB4A2)
val DarkBackground = Color(0xFF281D2E)
val DarkSurface = Color(0xFF1F1624)
val DarkText = Color(0xFFFFFFFF)

// Legacy / Utility Colors
val StarGold = Color(0xFFFFD700)
val SuccessGreen = Color(0xFF4CAF50)
val LimitReachedRed = Color(0xFFE53935)
val WarningAmber = Color(0xFFFF9800)
