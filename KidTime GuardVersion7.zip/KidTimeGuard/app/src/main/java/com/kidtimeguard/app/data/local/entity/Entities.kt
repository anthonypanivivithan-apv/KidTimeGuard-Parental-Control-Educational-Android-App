package com.kidtimeguard.app.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

// ─────────────────────────────────────────────────────────────────
// 1. ChildProfile — one row per child (v1.0 supports single child)
// ─────────────────────────────────────────────────────────────────
@Entity(tableName = "child_profiles")
data class ChildProfileEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "name")
    val name: String,

    /** Age used to bucket challenge difficulty: 6-9 / 10-13 / 14-16 */
    @ColumnInfo(name = "age")
    val age: Int,

    /** Resource name of chosen avatar drawable */
    @ColumnInfo(name = "avatar_res")
    val avatarRes: String = "avatar_default",

    @ColumnInfo(name = "total_stars")
    val totalStars: Int = 0,

    @ColumnInfo(name = "total_xp")
    val totalXp: Int = 0,

    /** Level derived from XP — stored for fast display */
    @ColumnInfo(name = "level")
    val level: Int = 1,

    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis()
)

// ─────────────────────────────────────────────────────────────────
// 2. MonitoredApp — apps selected by parent for time tracking
// ─────────────────────────────────────────────────────────────────
@Entity(
    tableName = "monitored_apps",
    indices = [Index(value = ["package_name"], unique = true)]
)
data class MonitoredAppEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "package_name")
    val packageName: String,

    @ColumnInfo(name = "app_name")
    val appName: String,

    /** Category: SOCIAL_MEDIA | GAMES | VIDEO | EDUCATION | OTHER */
    @ColumnInfo(name = "category")
    val category: String = "OTHER",

    /** Daily limit in minutes — weekdays (Mon–Fri) ✅ Reset to 30 min per requirement */
    @ColumnInfo(name = "limit_weekday_minutes")
    val limitWeekdayMinutes: Int = 30,

    /** Daily limit in minutes — weekends (Sat–Sun) ✅ Reset to 30 min per requirement */
    @ColumnInfo(name = "limit_weekend_minutes")
    val limitWeekendMinutes: Int = 30,

    @ColumnInfo(name = "is_active")
    val isActive: Boolean = true,

    /** Icon cached as Base64 string (small, 48dp) */
    @ColumnInfo(name = "icon_base64")
    val iconBase64: String? = null,

    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis()
)

// ─────────────────────────────────────────────────────────────────
// 3. UsageRecord — daily cumulative usage per monitored app
// ─────────────────────────────────────────────────────────────────
@Entity(
    tableName = "usage_records",
    indices = [
        Index(value = ["package_name", "date_epoch"], unique = true),
        Index(value = ["date_epoch"])
    ]
)
data class UsageRecordEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "package_name")
    val packageName: String,

    /** Date as epoch day (LocalDate.toEpochDay()) — one row per app per day */
    @ColumnInfo(name = "date_epoch")
    val dateEpoch: Long,

    /** Total foreground usage in milliseconds for this day */
    @ColumnInfo(name = "usage_ms")
    val usageMs: Long = 0L,

    /** Bonus milliseconds earned through challenges */
    @ColumnInfo(name = "bonus_ms")
    val bonusMs: Long = 0L,

    @ColumnInfo(name = "updated_at")
    val updatedAt: Long = System.currentTimeMillis()
)

// ─────────────────────────────────────────────────────────────────
// 4. AppLockEvent — history of lock/unlock events
// ─────────────────────────────────────────────────────────────────
@Entity(
    tableName = "app_lock_events",
    indices = [Index(value = ["package_name"]), Index(value = ["locked_at"])]
)
data class AppLockEventEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "package_name")
    val packageName: String,

    @ColumnInfo(name = "locked_at")
    val lockedAt: Long = System.currentTimeMillis(),

    @ColumnInfo(name = "unlocked_at")
    val unlockedAt: Long? = null,

    /**
     * How the lock was resolved:
     * CHALLENGE_SOLVED | PARENT_OVERRIDE | TOOK_BREAK | MIDNIGHT_RESET | PENDING
     */
    @ColumnInfo(name = "unlock_reason")
    val unlockReason: String = "PENDING",

    /** Bonus minutes granted when unlocked */
    @ColumnInfo(name = "bonus_minutes_granted")
    val bonusMinutesGranted: Int = 0
)

// ─────────────────────────────────────────────────────────────────
// 5. ChallengeAttempt — per-challenge performance log
// ─────────────────────────────────────────────────────────────────
@Entity(
    tableName = "challenge_attempts",
    foreignKeys = [
        ForeignKey(
            entity = AppLockEventEntity::class,
            parentColumns = ["id"],
            childColumns = ["lock_event_id"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["lock_event_id"]), Index(value = ["attempted_at"])]
)
data class ChallengeAttemptEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "lock_event_id")
    val lockEventId: Long,

    @ColumnInfo(name = "challenge_id")
    val challengeId: Long,

    /** Which attempt in the session (1, 2, or 3) */
    @ColumnInfo(name = "attempt_number")
    val attemptNumber: Int,

    @ColumnInfo(name = "is_correct")
    val isCorrect: Boolean,

    /** Stars earned: 3 (fast correct), 2 (slow correct), 1 (partial/failed) */
    @ColumnInfo(name = "stars_earned")
    val starsEarned: Int,

    @ColumnInfo(name = "bonus_minutes")
    val bonusMinutes: Int,

    /** Time taken to answer in milliseconds */
    @ColumnInfo(name = "answer_time_ms")
    val answerTimeMs: Long,

    @ColumnInfo(name = "attempted_at")
    val attemptedAt: Long = System.currentTimeMillis()
)

// ─────────────────────────────────────────────────────────────────
// 6. Challenge — pre-loaded question bank (seeded at install)
// ─────────────────────────────────────────────────────────────────
@Entity(
    tableName = "challenges",
    indices = [
        Index(value = ["type"]),
        Index(value = ["min_age", "max_age"])
    ]
)
data class ChallengeEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    /** MATH | LOGIC | TRIVIA | WORD | MEMORY */
    @ColumnInfo(name = "type")
    val type: String,

    @ColumnInfo(name = "question")
    val question: String,

    /** JSON array of 4 option strings: ["10","12","13","11"] */
    @ColumnInfo(name = "options_json")
    val optionsJson: String,

    /** 0-based index of the correct option */
    @ColumnInfo(name = "correct_index")
    val correctIndex: Int,

    @ColumnInfo(name = "explanation")
    val explanation: String,

    @ColumnInfo(name = "min_age")
    val minAge: Int,

    @ColumnInfo(name = "max_age")
    val maxAge: Int,

    /** Threshold in milliseconds for "fast" answer (earns 3 stars) */
    @ColumnInfo(name = "fast_threshold_ms")
    val fastThresholdMs: Long = 20_000L
)

// ─────────────────────────────────────────────────────────────────
// 7. ParentOverride — audit log for manual parent unlocks
// ─────────────────────────────────────────────────────────────────
@Entity(
    tableName = "parent_overrides",
    indices = [Index(value = ["package_name"]), Index(value = ["overridden_at"])]
)
data class ParentOverrideEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "package_name")
    val packageName: String,

    @ColumnInfo(name = "bonus_minutes")
    val bonusMinutes: Int,

    @ColumnInfo(name = "overridden_at")
    val overriddenAt: Long = System.currentTimeMillis()
)
