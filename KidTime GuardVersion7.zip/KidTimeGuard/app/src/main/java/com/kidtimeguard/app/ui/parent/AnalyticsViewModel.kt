package com.kidtimeguard.app.ui.parent

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kidtimeguard.app.data.repository.AnalyticsRepository
import com.kidtimeguard.app.data.repository.MonitoredAppRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters
import javax.inject.Inject

/** ✅ High-precision breakdown for live UI */
data class AppBreakdownItem(
    val packageName: String,
    val appName: String,
    val usedMs: Long,
    val challengeMs: Long,
    val parentMs: Long
) {
    val totalActiveMinutes: Int get() = ((usedMs + challengeMs + parentMs) / 60_000).toInt()
    val usedMinutes: Int get() = (usedMs / 60_000).toInt()
    val challengeMinutes: Int get() = (challengeMs / 60_000).toInt()
    val parentMinutes: Int get() = (parentMs / 60_000).toInt()
}

/** ✅ Granular breakdown for specific day */
data class DailyBreakdown(
    val usedMs: Long = 0,
    val challengeMs: Long = 0,
    val parentMs: Long = 0
) {
    val totalMinutes: Int get() = ((usedMs + challengeMs + parentMs) / 60_000).toInt()
    val usedMinutes: Int get() = (usedMs / 60_000).toInt()
    val challengeMinutes: Int get() = (challengeMs / 60_000).toInt()
    val parentMinutes: Int get() = (parentMs / 60_000).toInt()
}

data class AnalyticsUiState(
    val weekTotalMinutes: Int          = 0,
    val weekOverWeekDeltaPercent: Int  = 0,
    val dailyUsageMinutes: List<Int>   = emptyList(),
    val dailyBreakdowns: List<DailyBreakdown> = emptyList(),
    val appBreakdown: List<AppBreakdownItem> = emptyList(),
    val challengeSuccessRate: Int      = 0,
    val totalChallenges: Int           = 0,
    val correctChallenges: Int         = 0,
    val totalStarsEarned: Int          = 0,
    val parentOverrides: Int           = 0,
    val aiInsight: String              = "",
    val isLoading: Boolean             = true
)

@HiltViewModel
class AnalyticsViewModel @Inject constructor(
    private val analyticsRepository: AnalyticsRepository,
    private val monitoredAppRepository: MonitoredAppRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(AnalyticsUiState())
    val uiState: StateFlow<AnalyticsUiState> = _uiState.asStateFlow()

    private val indianZone = ZoneId.of("Asia/Kolkata")

    /** 
     * ✅ DATE-REACTIVE: Ensures the graph and breakdown reset exactly at local midnight IST.
     */
    private val currentDateFlow = flow {
        while (true) {
            emit(LocalDate.now(indianZone))
            delay(30_000) 
        }
    }.distinctUntilChanged()

    init {
        viewModelScope.launch {
            currentDateFlow.collectLatest { today ->
                loadAnalytics(today)
            }
        }
    }

    private suspend fun loadAnalytics(today: LocalDate) {
        val weekStart  = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val weekStartEpoch = weekStart.toEpochDay()
        val weekStartMs    = weekStart.atStartOfDay(indianZone).toInstant().toEpochMilli()

        val prevWeekStart  = weekStart.minusWeeks(1)
        val prevWeekStartEpoch = prevWeekStart.toEpochDay()

        val apps = monitoredAppRepository.getAllApps().associateBy { it.packageName }

        combine(
            analyticsRepository.observeRecordsSince(weekStartEpoch),
            analyticsRepository.observeOverridesSince(weekStartMs)
        ) { records, overrides ->
            // Daily maps
            val usedMap = mutableMapOf<Int, Long>()
            val bonusMap = mutableMapOf<Int, Long>()
            val parentMap = mutableMapOf<Int, Long>()

            // App maps (Weekly totals)
            val appUsedMap = mutableMapOf<String, Long>()
            val appBonusMap = mutableMapOf<String, Long>()
            val appParentMap = mutableMapOf<String, Long>()

            records.forEach { r ->
                val dayIndex = (r.dateEpoch - weekStartEpoch).toInt()
                if (dayIndex in 0..6) {
                    usedMap[dayIndex] = (usedMap[dayIndex] ?: 0L) + r.usageMs
                    bonusMap[dayIndex] = (bonusMap[dayIndex] ?: 0L) + r.bonusMs

                    appUsedMap[r.packageName] = (appUsedMap[r.packageName] ?: 0L) + r.usageMs
                    appBonusMap[r.packageName] = (appBonusMap[r.packageName] ?: 0L) + r.bonusMs
                }
            }

            overrides.forEach { o ->
                val overrideDate = Instant.ofEpochMilli(o.overriddenAt).atZone(indianZone).toLocalDate()
                val dayIndex = (overrideDate.toEpochDay() - weekStartEpoch).toInt()
                if (dayIndex in 0..6) {
                    parentMap[dayIndex] = (parentMap[dayIndex] ?: 0L) + (o.bonusMinutes * 60_000L)
                    appParentMap[o.packageName] = (appParentMap[o.packageName] ?: 0L) + (o.bonusMinutes * 60_000L)
                }
            }

            val dailyBreakdowns = (0..6).map { i ->
                val used = usedMap[i] ?: 0L
                val bonus = bonusMap[i] ?: 0L
                val parent = parentMap[i] ?: 0L
                val challenge = (bonus - parent).coerceAtLeast(0L)

                DailyBreakdown(usedMs = used, challengeMs = challenge, parentMs = parent)
            }

            val appBreakdownItems = appUsedMap.keys.union(appParentMap.keys).map { pkg ->
                val usedMs = appUsedMap[pkg] ?: 0L
                val bonusMs = appBonusMap[pkg] ?: 0L
                val parentMs = appParentMap[pkg] ?: 0L
                val challengeMs = (bonusMs - parentMs).coerceAtLeast(0L)

                AppBreakdownItem(
                    packageName = pkg,
                    appName = apps[pkg]?.appName ?: pkg.split(".").last(),
                    usedMs = usedMs,
                    challengeMs = challengeMs,
                    parentMs = parentMs
                )
            }.sortedByDescending { it.usedMs }

            val weekTotalMins = (dailyBreakdowns.sumOf { it.usedMs } / 60_000).toInt()
            val stats = analyticsRepository.getChallengeStats(weekStartMs)
            val rate  = if (stats.total > 0) (stats.correct * 100) / stats.total else 0

            _uiState.update {
                it.copy(
                    weekTotalMinutes         = weekTotalMins,
                    dailyUsageMinutes        = dailyBreakdowns.map { it.usedMinutes },
                    dailyBreakdowns          = dailyBreakdowns,
                    appBreakdown             = appBreakdownItems,
                    challengeSuccessRate     = rate,
                    totalChallenges          = stats.total,
                    correctChallenges        = stats.correct,
                    totalStarsEarned         = stats.totalStars,
                    parentOverrides          = overrides.size,
                    isLoading                = false
                )
            }
        }.flowOn(Dispatchers.IO).collect()
    }

    private fun buildInsight(weekMinutes: Int, successRate: Int, overrides: Int): String {
        val hours = weekMinutes / 60
        return when {
            overrides > 5  -> "Parent overrides happened $overrides times this week. Consider adjusting time limits."
            successRate >= 80 -> "Excellent! ${successRate}% challenge success rate — great learning habit! 🎉"
            weekMinutes > 600 -> "Screen time reached ${hours}h this week. Consider reducing limits slightly."
            successRate < 50 -> "Challenge success rate is at $successRate%. Try easier settings for younger children."
            else -> "Screen time looks balanced this week. Keep it up! ✅"
        }
    }
}
