package com.kidtimeguard.app.service

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.kidtimeguard.app.KidTimeGuardApp
import com.kidtimeguard.app.R
import com.kidtimeguard.app.data.local.entity.UsageRecordEntity
import com.kidtimeguard.app.data.repository.AppUsageRepository
import com.kidtimeguard.app.data.repository.MonitoredAppRepository
import com.kidtimeguard.app.receiver.ServiceRestartReceiver
import com.kidtimeguard.app.ui.main.MainActivity
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import java.time.LocalDate
import java.time.ZoneId
import javax.inject.Inject

@AndroidEntryPoint
class UsageTrackingService : LifecycleService() {

    @Inject lateinit var monitoredAppRepository: MonitoredAppRepository
    @Inject lateinit var appUsageRepository: AppUsageRepository
    @Inject lateinit var appLockManager: AppLockManager

    private val usageStatsManager: UsageStatsManager by lazy {
        getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
    }

    private var pollingJob: Job? = null
    
    // ✅ Hardcoded IST for absolute consistency
    private val indianZone = ZoneId.of("Asia/Kolkata")

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        startForeground(KidTimeGuardApp.NOTIF_ID_TRACKING, createNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_STOP -> { 
                stopPolling()
                isRunning = false
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf() 
            }
            else -> startPolling()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent): IBinder? {
        super.onBind(intent)
        return null
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        if (!isRunning) return

        val restartIntent = Intent(this, ServiceRestartReceiver::class.java).apply {
            action = ServiceRestartReceiver.ACTION_RESTART_SERVICE
            setPackage(packageName)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            this, 1, restartIntent,
            PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarmManager = getSystemService(ALARM_SERVICE) as AlarmManager
        alarmManager.set(
            AlarmManager.ELAPSED_REALTIME,
            android.os.SystemClock.elapsedRealtime() + 1000L,
            pendingIntent
        )
    }

    override fun onDestroy() {
        stopPolling()
        isRunning = false
        super.onDestroy()
    }

    private fun startPolling() {
        if (pollingJob?.isActive == true) return
        isRunning = true
        pollingJob = lifecycleScope.launch {
            while (isActive) {
                try { checkUsage() } catch (e: Exception) {
                    android.util.Log.e(TAG, "Usage check error", e)
                }
                delay(POLL_INTERVAL_MS)
            }
        }
    }

    private fun stopPolling() {
        pollingJob?.cancel()
        pollingJob = null
    }

    private suspend fun checkUsage() {
        val monitoredApps = monitoredAppRepository.observeActiveApps().first()
        if (monitoredApps.isEmpty()) return

        // ✅ Strictly use Indian Standard Time (IST)
        val today      = LocalDate.now(indianZone)
        val dateEpoch  = today.toEpochDay()
        val isWeekend  = today.dayOfWeek.value >= 6
        val startOfDay = today.atStartOfDay(indianZone).toInstant().toEpochMilli()
        val now        = System.currentTimeMillis()

        val foregroundPkg = getForegroundPackage(now)

        val usageStats = usageStatsManager.queryUsageStats(
            UsageStatsManager.INTERVAL_DAILY, startOfDay, now
        ).associateBy { it.packageName }

        for (app in monitoredApps) {
            val isEnforced = appLockManager.isEnforcedLocked(app.packageName)
            
            val osUsageMs = usageStats[app.packageName]?.totalTimeInForeground ?: 0L
            val existing  = appUsageRepository.getUsageRecord(app.packageName, dateEpoch)

            if (existing == null) {
                appUsageRepository.upsertUsageRecord(
                    UsageRecordEntity(packageName = app.packageName, dateEpoch = dateEpoch, usageMs = osUsageMs)
                )
            } else {
                appUsageRepository.updateUsageMs(app.packageName, dateEpoch, osUsageMs)
            }

            val limitMs        = (if (isWeekend) app.limitWeekendMinutes else app.limitWeekdayMinutes) * 60_000L
            val bonusMs        = existing?.bonusMs ?: 0L
            val effectiveLimit = limitMs + bonusMs
            val isOverLimit    = osUsageMs >= effectiveLimit

            if ((isOverLimit || isEnforced) && foregroundPkg == app.packageName) {
                appLockManager.onLimitReached(app.packageName, app.appName)
            }
        }
    }

    private fun getForegroundPackage(now: Long): String? {
        val events = usageStatsManager.queryEvents(now - 5000, now)
        val event = UsageEvents.Event()
        var lastResumedPackage: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {
                lastResumedPackage = event.packageName
            }
        }
        return lastResumedPackage
    }

    private fun createNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, KidTimeGuardApp.CHANNEL_TRACKING)
            .setContentTitle("KidTimeGuard Active")
            .setContentText("Monitoring app usage (IST)")
            .setSmallIcon(R.drawable.ic_shield)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val TAG              = "UsageTrackingService"
        private const val POLL_INTERVAL_MS = 1000L
        const val ACTION_STOP              = "com.kidtimeguard.app.STOP_TRACKING"
        @Volatile private var isRunning    = false

        fun start(context: Context) {
            if (!isRunning) {
                context.startForegroundService(Intent(context, UsageTrackingService::class.java))
            }
        }

        fun stop(context: Context) {
            isRunning = false
            context.stopService(Intent(context, UsageTrackingService::class.java).apply {
                action = ACTION_STOP
            })
        }
    }
}
