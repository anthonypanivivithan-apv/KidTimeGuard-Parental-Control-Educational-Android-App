package com.kidtimeguard.app.worker

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.kidtimeguard.app.data.local.dao.UsageRecordDao
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.time.Duration
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.concurrent.TimeUnit

@HiltWorker
class MidnightResetWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted workerParams: WorkerParameters,
    private val usageRecordDao: UsageRecordDao
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        return try {
            // ✅ Hardcoded Indian Time Zone for absolute consistency
            val indianZone = ZoneId.of("Asia/Kolkata")
            val today = LocalDate.now(indianZone)
            
            // Cleanup records older than 30 days
            val cutoff = today.minusDays(30).toEpochDay()
            usageRecordDao.deleteOldRecords(cutoff)
            
            // Reschedule for the next midnight IST
            schedule(applicationContext)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        private const val WORK_NAME = "midnight_reset_worker"

        /**
         * Schedules the worker to run at exactly 12:00 AM Indian Standard Time (IST).
         */
        fun schedule(context: Context) {
            val workManager = try {
                WorkManager.getInstance(context)
            } catch (e: IllegalStateException) {
                return
            }

            val indianZone = ZoneId.of("Asia/Kolkata")
            val now = ZonedDateTime.now(indianZone)
            
            // Calculate next 12:00 AM in IST
            val nextMidnight = now.toLocalDate().plusDays(1).atStartOfDay(indianZone)
            val delayMs = Duration.between(now, nextMidnight).toMillis()

            val request = OneTimeWorkRequestBuilder<MidnightResetWorker>()
                .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
                .setConstraints(
                    Constraints.Builder()
                        .setRequiresBatteryNotLow(false)
                        .build()
                )
                .addTag(WORK_NAME)
                .build()

            workManager.enqueueUniqueWork(
                WORK_NAME,
                ExistingWorkPolicy.REPLACE,
                request
            )
        }
    }
}
