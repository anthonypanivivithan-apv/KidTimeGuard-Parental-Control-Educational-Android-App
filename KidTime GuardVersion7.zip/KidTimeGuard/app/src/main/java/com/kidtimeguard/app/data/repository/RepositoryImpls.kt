// Duplicate file removed. Implementation is in the 'impl' subpackage.
