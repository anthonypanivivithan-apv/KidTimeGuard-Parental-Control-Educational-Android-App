package com.kidtimeguard.app.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.kidtimeguard.app.ui.theme.*

// ─────────────────────────────────────────────────────────────────
// Level-up dialog shown after a challenge when the child levels up
// ─────────────────────────────────────────────────────────────────
@Composable
fun LevelUpDialog(newLevel: Int, onDismiss: () -> Unit) {
    val scale by animateFloatAsState(
        targetValue  = 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness    = Spring.StiffnessLow
        ),
        label = "level_up_scale"
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .scale(scale),
            shape  = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer
            )
        ) {
            Column(
                modifier            = Modifier.padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Trophy icon with pulsing background
                val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
                    initialValue  = 0.9f,
                    targetValue   = 1.1f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(800, easing = FastOutSlowInEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "pulse_scale"
                )
                Box(
                    modifier = Modifier
                        .size(88.dp)
                        .scale(pulse)
                        .clip(CircleShape)
                        .background(StarGold.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Filled.EmojiEvents,
                        contentDescription = null,
                        tint               = StarGold,
                        modifier           = Modifier.size(52.dp)
                    )
                }

                Spacer(Modifier.height(20.dp))

                Text(
                    "LEVEL UP!",
                    style      = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color      = MaterialTheme.colorScheme.primary
                )

                Spacer(Modifier.height(8.dp))

                Text(
                    "You reached",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(0.7f)
                )

                Text(
                    "Level $newLevel",
                    style      = MaterialTheme.typography.displaySmall,
                    fontWeight = FontWeight.Bold,
                    color      = MaterialTheme.colorScheme.primary
                )

                Spacer(Modifier.height(8.dp))

                // Stars row
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    repeat(minOf(newLevel, 5)) {
                        Icon(
                            Icons.Filled.Star,
                            contentDescription = null,
                            tint     = StarGold,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                Spacer(Modifier.height(24.dp))

                Text(
                    "Keep answering challenges\nto reach the next level!",
                    style     = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center,
                    color     = MaterialTheme.colorScheme.onPrimaryContainer.copy(0.7f)
                )

                Spacer(Modifier.height(24.dp))

                Button(
                    onClick  = onDismiss,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Awesome!")
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────
// Animated star row — shows stars earned with pop-in animation
// ─────────────────────────────────────────────────────────────────
@Composable
fun AnimatedStarRow(starsEarned: Int, totalStars: Int = 3) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment     = Alignment.CenterVertically
    ) {
        repeat(totalStars) { index ->
            val filled = index < starsEarned
            val delay  = index * 150

            val scale by animateFloatAsState(
                targetValue   = if (filled) 1f else 0.7f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness    = Spring.StiffnessLow
                ),
                label = "star_scale_$index"
            )

            Icon(
                imageVector        = Icons.Filled.Star,
                contentDescription = null,
                tint               = if (filled) StarGold else StarGold.copy(alpha = 0.25f),
                modifier           = Modifier
                    .size(40.dp)
                    .scale(scale)
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────
// XP progress bar with animated fill
// ─────────────────────────────────────────────────────────────────
@Composable
fun XpProgressBar(
    currentXp : Int,
    xpForNext : Int,
    level     : Int,
    modifier  : Modifier = Modifier
) {
    val fraction = if (xpForNext > 0) (currentXp.toFloat() / xpForNext).coerceIn(0f, 1f) else 0f
    val animatedFraction by animateFloatAsState(
        targetValue   = fraction,
        animationSpec = tween(durationMillis = 800, easing = FastOutSlowInEasing),
        label         = "xp_progress"
    )

    Column(modifier = modifier) {
        Row(
            modifier              = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                "Level $level",
                style      = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color      = MaterialTheme.colorScheme.primary
            )
            Text(
                "$currentXp / $xpForNext XP",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurface.copy(0.5f)
            )
        }
        Spacer(Modifier.height(4.dp))
        LinearProgressIndicator(
            progress   = { animatedFraction },
            modifier   = Modifier
                .fillMaxWidth()
                .height(10.dp)
                .clip(RoundedCornerShape(5.dp)),
            color      = MaterialTheme.colorScheme.primary,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
        )
    }
}

// ─────────────────────────────────────────────────────────────────
// Bonus time badge — animated slide-in
// ─────────────────────────────────────────────────────────────────
@Composable
fun BonusTimeBadge(minutes: Int, visible: Boolean) {
    AnimatedVisibility(
        visible = visible,
        enter   = slideInVertically(initialOffsetY = { it }) + fadeIn(),
        exit    = slideOutVertically() + fadeOut()
    ) {
        Surface(
            shape = RoundedCornerShape(50),
            color = SuccessGreen.copy(alpha = 0.15f)
        ) {
            Row(
                modifier          = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text("+$minutes minutes", style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold, color = SuccessGreen)
                Text("unlocked!", style = MaterialTheme.typography.bodyMedium, color = SuccessGreen)
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────
// Countdown timer composable — shown during challenge
// ─────────────────────────────────────────────────────────────────
@Composable
fun ChallengeTimer(
    totalSeconds  : Int = 20,
    onTimeExpired : () -> Unit
) {
    var secondsLeft by remember { mutableIntStateOf(totalSeconds) }

    LaunchedEffect(Unit) {
        while (secondsLeft > 0) {
            kotlinx.coroutines.delay(1000)
            secondsLeft--
        }
        onTimeExpired()
    }

    val fraction      = secondsLeft.toFloat() / totalSeconds
    val timerColor    = when {
        fraction > 0.5f -> SuccessGreen
        fraction > 0.25f -> Color(0xFFFF9800)
        else             -> Color(0xFFE24B4A)
    }

    Box(contentAlignment = Alignment.Center) {
        CircularProgressIndicator(
            progress           = { fraction },
            modifier           = Modifier.size(52.dp),
            color              = timerColor,
            trackColor         = timerColor.copy(alpha = 0.15f),
            strokeWidth        = 4.dp
        )
        Text(
            text       = "$secondsLeft",
            style      = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color      = timerColor
        )
    }
}
