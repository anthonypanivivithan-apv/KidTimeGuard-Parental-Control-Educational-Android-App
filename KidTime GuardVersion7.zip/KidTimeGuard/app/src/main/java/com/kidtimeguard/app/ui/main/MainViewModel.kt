package com.kidtimeguard.app.ui.main

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kidtimeguard.app.service.UsageTrackingService
import com.kidtimeguard.app.ui.navigation.NavGraph
import com.kidtimeguard.app.ui.navigation.Screen
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

val Context.dataStore by preferencesDataStore(name = "app_prefs")
val SETUP_COMPLETE = booleanPreferencesKey("setup_complete")
val DARK_THEME_KEY = booleanPreferencesKey("dark_theme")

@HiltViewModel
class MainViewModel @Inject constructor(
    @ApplicationContext private val context: Context
) : ViewModel() {

    private val _isLoadingStartDestination = MutableStateFlow(true)
    val isLoadingStartDestination: StateFlow<Boolean> = _isLoadingStartDestination.asStateFlow()

    private val _startDestination = MutableStateFlow<String?>(null)
    val startDestination: StateFlow<String?> = _startDestination.asStateFlow()

    // ✅ Theme State
    val isDarkTheme: StateFlow<Boolean> = context.dataStore.data
        .map { it[DARK_THEME_KEY] ?: false }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = false
        )

    init {
        viewModelScope.launch {
            val isSetupComplete = context.dataStore.data
                .map { it[SETUP_COMPLETE] ?: false }
                .first()

            _startDestination.value = if (isSetupComplete) {
                UsageTrackingService.start(context)
                Screen.ParentDashboard.route
            } else {
                NavGraph.SETUP_GRAPH
            }

            _isLoadingStartDestination.value = false
        }
    }
}
