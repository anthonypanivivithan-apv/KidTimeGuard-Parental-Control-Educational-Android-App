# ── KidTimeGuard ProGuard / R8 Rules ──────────────────────────────

# ── Keep Room entities and DAOs ──
-keep class com.kidtimeguard.app.data.local.entity.** { *; }
-keep class com.kidtimeguard.app.data.local.dao.** { *; }
-keepclassmembers class * {
    @androidx.room.* <methods>;
}

# ── Keep Hilt ──
-keep class dagger.hilt.** { *; }
-keep @dagger.hilt.android.lifecycle.HiltViewModel class * { *; }
-keepclassmembers class * {
    @dagger.hilt.android.lifecycle.HiltViewModel <init>(...);
}

# ── Keep Hilt worker factory ──
-keep class * extends androidx.hilt.work.HiltWorker { *; }
-keepclassmembers class * extends androidx.work.Worker {
    public <init>(android.content.Context, androidx.work.WorkerParameters);
}

# ── Keep Coroutines ──
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembers class kotlinx.coroutines.** {
    volatile <fields>;
}

# ── Keep DataStore ──
-keep class androidx.datastore.** { *; }

# ── Keep EncryptedSharedPreferences ──
-keep class androidx.security.crypto.** { *; }

# ── Keep Compose ──
-keep class androidx.compose.** { *; }
-keep class kotlin.Metadata { *; }

# ── Keep UsageStatsManager ──
-keep class android.app.usage.** { *; }
-keep class android.app.AppOpsManager { *; }

# ── Keep FileProvider ──
-keep class androidx.core.content.FileProvider { *; }

# ── Keep our service, receiver, and worker classes ──
-keep class com.kidtimeguard.app.service.** { *; }
-keep class com.kidtimeguard.app.receiver.** { *; }
-keep class com.kidtimeguard.app.worker.** { *; }
-keep class com.kidtimeguard.app.KidTimeGuardApp { *; }
-keep class com.kidtimeguard.app.reward.** { *; }
-keep class com.kidtimeguard.app.export.** { *; }
-keep class com.kidtimeguard.app.security.** { *; }

# Firebase Crashlytics
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
-keep public class * extends java.lang.Exception
-keep class com.google.firebase.** { *; }
-dontwarn com.google.firebase.**

# ── General Kotlin rules ──
-keepattributes *Annotation*
-keepattributes Signature
-keepattributes SourceFile,LineNumberTable
-dontwarn kotlin.**
-dontwarn kotlinx.coroutines.**

# ── Remove debug logging in release builds ──
-assumenosideeffects class android.util.Log {
    public static int d(...);
    public static int v(...);
}

# ── Keep enum classes ──
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}
